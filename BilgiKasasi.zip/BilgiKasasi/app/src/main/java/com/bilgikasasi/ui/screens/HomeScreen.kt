package com.bilgikasasi.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bilgikasasi.data.entity.Category
import com.bilgikasasi.data.entity.VaultItem
import com.bilgikasasi.ui.theme.VaultPurple

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    categories: List<Category>,
    recentItems: List<VaultItem>,
    favorites: List<VaultItem>,
    getCategoryItemCount: @Composable (Long) -> Int,
    decryptTitle: (VaultItem) -> String,
    onCategoryClick: (Long) -> Unit,
    onItemClick: (Long) -> Unit,
    onSearchClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onLock: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, null, tint = VaultPurple, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("Bilgi Kasası", fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    IconButton(onClick = onSearchClick) { Icon(Icons.Default.Search, "Ara") }
                    IconButton(onClick = onSettingsClick) { Icon(Icons.Default.Settings, "Ayarlar") }
                    IconButton(onClick = onLock) { Icon(Icons.Default.LockOutline, "Kilitle") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            // ── Categories Grid ──
            item {
                Text("Kategoriler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.height(((categories.size + 1) / 2 * 100).coerceAtMost(420).dp)
                ) {
                    items(categories, key = { it.id }) { cat ->
                        val count by remember(cat.id) { mutableIntStateOf(0) }
                        CategoryCard(cat, getCategoryItemCount, onClick = { onCategoryClick(cat.id) })
                    }
                }
            }

            // ── Favorites ──
            if (favorites.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(4.dp))
                    Text("Favoriler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                items(favorites.take(5), key = { "fav_${it.id}" }) { item ->
                    QuickItemCard(item, decryptTitle, categories) { onItemClick(item.id) }
                }
            }

            // ── Recent ──
            if (recentItems.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(4.dp))
                    Text("Son Eklenenler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                items(recentItems.take(5), key = { "rec_${it.id}" }) { item ->
                    QuickItemCard(item, decryptTitle, categories) { onItemClick(item.id) }
                }
            }

            // Empty state
            if (categories.isEmpty()) {
                item {
                    Card(modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.fillMaxWidth().padding(48.dp),
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Shield, null, modifier = Modifier.size(56.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(12.dp))
                            Text("Kasanız hazır", style = MaterialTheme.typography.titleMedium)
                            Text("Bilgilerinizi güvenle saklamaya başlayın",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryCard(
    cat: Category,
    getCategoryItemCount: @Composable (Long) -> Int,
    onClick: () -> Unit
) {
    val count = getCategoryItemCount(cat.id)
    val color = try { Color(android.graphics.Color.parseColor(cat.colorHex)) } catch (_: Exception) { VaultPurple }

    Card(
        modifier = Modifier.fillMaxWidth().height(88.dp).clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier.size(36.dp).clip(CircleShape).background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Folder, null, tint = color, modifier = Modifier.size(20.dp))
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(cat.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text("$count", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun QuickItemCard(
    item: VaultItem,
    decryptTitle: (VaultItem) -> String,
    categories: List<Category>,
    onClick: () -> Unit
) {
    val title = remember(item.id, item.updatedAt) { decryptTitle(item) }
    val cat = categories.find { it.id == item.categoryId }
    val color = cat?.colorHex?.let {
        try { Color(android.graphics.Color.parseColor(it)) } catch (_: Exception) { null }
    } ?: VaultPurple

    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(10.dp).clip(CircleShape).background(color)
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1)
                Text(cat?.name ?: "", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (item.isFavorite) {
                Icon(Icons.Default.Star, null, tint = Color(0xFFFFB300), modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(4.dp))
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp))
        }
    }
}
