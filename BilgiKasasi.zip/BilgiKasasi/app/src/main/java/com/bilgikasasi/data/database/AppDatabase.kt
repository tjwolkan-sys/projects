package com.bilgikasasi.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.bilgikasasi.data.dao.CategoryDao
import com.bilgikasasi.data.dao.VaultItemDao
import com.bilgikasasi.data.entity.Category
import com.bilgikasasi.data.entity.VaultItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Category::class, VaultItem::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun categoryDao(): CategoryDao
    abstract fun vaultItemDao(): VaultItemDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "bilgi_kasasi_db")
                .addCallback(SeedCallback())
                .build().also { INSTANCE = it }
        }
    }

    private class SeedCallback : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                CoroutineScope(Dispatchers.IO).launch {
                    val dao = database.categoryDao()
                    val cats = listOf(
                        Category(name="Finans", icon="AccountBalance", colorHex="#6C63FF", sortOrder=0,
                            fieldTemplate="""[{"label":"Banka","isSensitive":false},{"label":"IBAN","isSensitive":true},{"label":"Hesap No","isSensitive":true},{"label":"Kart No","isSensitive":true},{"label":"Son Kullanma","isSensitive":true},{"label":"CVV","isSensitive":true}]"""),
                        Category(name="Kimlikler", icon="Badge", colorHex="#00BFA5", sortOrder=1,
                            fieldTemplate="""[{"label":"TC Kimlik No","isSensitive":true},{"label":"Seri No","isSensitive":true},{"label":"Veriliş Tarihi","isSensitive":false},{"label":"Geçerlilik","isSensitive":false}]"""),
                        Category(name="Dijital Hesaplar", icon="Language", colorHex="#FF6D00", sortOrder=2,
                            fieldTemplate="""[{"label":"Kullanıcı Adı","isSensitive":false},{"label":"E-posta","isSensitive":false},{"label":"Şifre","isSensitive":true},{"label":"2FA Kodu","isSensitive":true},{"label":"Kurtarma Kodu","isSensitive":true}]"""),
                        Category(name="Araç", icon="DirectionsCar", colorHex="#D50000", sortOrder=3,
                            fieldTemplate="""[{"label":"Plaka","isSensitive":false},{"label":"Ruhsat No","isSensitive":true},{"label":"Motor No","isSensitive":true},{"label":"Şase No","isSensitive":true},{"label":"Sigorta Poliçe No","isSensitive":true}]"""),
                        Category(name="Sağlık", icon="LocalHospital", colorHex="#E91E63", sortOrder=4,
                            fieldTemplate="""[{"label":"Kan Grubu","isSensitive":false},{"label":"Sigorta No","isSensitive":true},{"label":"Hasta No","isSensitive":true},{"label":"Alerji","isSensitive":false},{"label":"İlaçlar","isSensitive":false}]"""),
                        Category(name="Ev / Konut", icon="Home", colorHex="#00897B", sortOrder=5,
                            fieldTemplate="""[{"label":"Adres","isSensitive":false},{"label":"WiFi Ağ Adı","isSensitive":false},{"label":"WiFi Şifresi","isSensitive":true},{"label":"Alarm Kodu","isSensitive":true},{"label":"Kapı Şifresi","isSensitive":true}]"""),
                        Category(name="Lisanslar", icon="Key", colorHex="#FF9800", sortOrder=6,
                            fieldTemplate="""[{"label":"Yazılım","isSensitive":false},{"label":"Lisans Anahtarı","isSensitive":true},{"label":"E-posta","isSensitive":false},{"label":"Bitiş Tarihi","isSensitive":false}]"""),
                        Category(name="Notlar", icon="StickyNote2", colorHex="#607D8B", sortOrder=7,
                            fieldTemplate="""[{"label":"Not","isSensitive":true}]"""),
                    )
                    cats.forEach { dao.insert(it) }
                }
            }
        }
    }
}
