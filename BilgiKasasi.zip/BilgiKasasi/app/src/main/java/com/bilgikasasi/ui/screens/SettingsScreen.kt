package com.bilgikasasi.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bilgikasasi.security.PinManager
import com.bilgikasasi.ui.theme.VaultPurple

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var showPinChange by remember { mutableStateOf(false) }
    var autoLock by remember { mutableIntStateOf(PinManager.getAutoLockSeconds(context)) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ayarlar") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            // PIN Change
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp).then(
                        Modifier.let { if (!showPinChange) it else it }
                    ), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, null, tint = VaultPurple)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("PIN Degistir", fontWeight = FontWeight.Medium)
                            Text("6 haneli guvenlik PIN'inizi degistirin", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        FilledTonalButton(onClick = { showPinChange = true }) { Text("Degistir") }
                    }
                }
            }

            // Auto-lock
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Timer, null, tint = VaultPurple)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Otomatik Kilit", fontWeight = FontWeight.Medium)
                                Text("$autoLock saniye inaktivite sonrasi", style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(15, 30, 60, 120).forEach { sec ->
                                FilterChip(
                                    selected = autoLock == sec,
                                    onClick = { autoLock = sec; PinManager.setAutoLockSeconds(context, sec) },
                                    label = { Text("${sec}s") }
                                )
                            }
                        }
                    }
                }
            }

            // Security info
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(
                    containerColor = VaultPurple.copy(alpha = 0.1f))) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, null, tint = VaultPurple)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("Guvenlik", fontWeight = FontWeight.Medium)
                            Text("AES-256-GCM sifreleme. Tum veriler cihazinizda kalir. Internete hicbir veri gonderilmez.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            // About
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Bilgi Kasasi v1.0", fontWeight = FontWeight.Medium)
                        Text("Kisisel bilgilerinizi guvenle saklayan offline kasa",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    // PIN Change Dialog
    if (showPinChange) {
        var oldPin by remember { mutableStateOf("") }
        var newPin by remember { mutableStateOf("") }
        var error by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showPinChange = false },
            title = { Text("PIN Degistir") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(value = oldPin, onValueChange = { if (it.length <= 6) oldPin = it.filter { c -> c.isDigit() } },
                        label = { Text("Mevcut PIN") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = newPin, onValueChange = { if (it.length <= 6) newPin = it.filter { c -> c.isDigit() } },
                        label = { Text("Yeni PIN (6 hane)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (newPin.length != 6) { error = "PIN 6 haneli olmali" }
                    else if (PinManager.changePin(context, oldPin, newPin)) { showPinChange = false }
                    else { error = "Mevcut PIN yanlis" }
                }) { Text("Degistir") }
            },
            dismissButton = { TextButton(onClick = { showPinChange = false }) { Text("Iptal") } }
        )
    }
}
