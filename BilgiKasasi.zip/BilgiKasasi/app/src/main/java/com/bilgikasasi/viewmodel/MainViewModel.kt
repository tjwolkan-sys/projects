package com.bilgikasasi.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bilgikasasi.App
import com.bilgikasasi.data.entity.*
import com.bilgikasasi.security.PinManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AuthState { LOCKED, UNLOCKED, SETUP_REQUIRED }

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = (application as App).repository
    private val context = application.applicationContext

    // ── Auth ──
    private val _authState = MutableStateFlow(
        if (PinManager.isSetup(context)) AuthState.LOCKED else AuthState.SETUP_REQUIRED
    )
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    fun setupPin(pin: String) {
        PinManager.setupPin(context, pin)
        _authState.value = AuthState.UNLOCKED
    }

    fun verifyPin(pin: String): Boolean {
        val ok = PinManager.verifyPin(context, pin)
        if (ok) {
            _authState.value = AuthState.UNLOCKED
            _authError.value = null
        } else {
            _authError.value = "Yanlış PIN"
        }
        return ok
    }

    fun lock() { _authState.value = AuthState.LOCKED }

    fun unlockWithBiometric() { _authState.value = AuthState.UNLOCKED }

    // ── Categories ──
    val allCategories = repo.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun getCategoryItemCount(catId: Long) = repo.getCategoryItemCount(catId)

    // ── Vault Items ──
    fun getItemsByCategory(catId: Long) = repo.getItemsByCategory(catId)
    val favorites = repo.getFavorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentItems = repo.getRecentItems()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allItems = repo.getAllItems()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ── Decrypt helpers ──
    fun decryptTitle(item: VaultItem) = repo.decryptTitle(item)
    fun decryptFields(item: VaultItem) = repo.decryptFields(item)
    fun decryptNotes(item: VaultItem) = repo.decryptNotes(item)
    fun getFieldTemplate(cat: Category) = repo.getFieldTemplate(cat)

    // ── CRUD ──
    private val _toast = MutableSharedFlow<String>()
    val toast: SharedFlow<String> = _toast.asSharedFlow()

    fun saveItem(categoryId: Long, title: String, fields: List<VaultField>, notes: String,
                 existingId: Long? = null, isFavorite: Boolean = false) {
        viewModelScope.launch {
            repo.saveItem(categoryId, title, fields, notes, existingId, isFavorite)
            _toast.emit(if (existingId != null) "Güncellendi" else "Kaydedildi")
        }
    }

    fun toggleFavorite(item: VaultItem) {
        viewModelScope.launch { repo.toggleFavorite(item) }
    }

    fun deleteItem(item: VaultItem) {
        viewModelScope.launch {
            repo.deleteItem(item)
            _toast.emit("Silindi")
        }
    }

    fun addCategory(name: String, color: String) {
        viewModelScope.launch {
            repo.insertCategory(Category(name = name, colorHex = color))
            _toast.emit("Kategori eklendi")
        }
    }

    fun deleteCategory(cat: Category) {
        viewModelScope.launch {
            repo.deleteCategory(cat)
            _toast.emit("Kategori silindi")
        }
    }

    suspend fun getCategoryById(id: Long) = repo.getCategoryById(id)
    suspend fun getItemById(id: Long) = repo.getItemById(id)
}
