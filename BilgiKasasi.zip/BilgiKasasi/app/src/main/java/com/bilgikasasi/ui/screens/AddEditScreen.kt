package com.bilgikasasi.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.bilgikasasi.data.entity.Category
import com.bilgikasasi.data.entity.VaultField
import com.bilgikasasi.data.entity.VaultItem
import com.bilgikasasi.ui.theme.VaultPurple

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditScreen(
    category: Category?,
    existingItem: VaultItem?,
    initialTitle: String,
    initialFields: List<VaultField>,
    initialNotes: String,
    isFavorite: Boolean,
    onBack: () -> Unit,
    onSave: (String, List<VaultField>, String, Boolean) -> Unit
) {
    var title by remember { mutableStateOf(initialTitle) }
    var fields by remember { mutableStateOf(initialFields.ifEmpty { listOf(VaultField("", "", true)) }) }
    var notes by remember { mutableStateOf(initialNotes) }
    var favorite by remember { mutableStateOf(isFavorite) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (existingItem != null) "Duzenle" else "Yeni Kayit") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.Close, "Iptal") } },
                actions = {
                    IconButton(onClick = { favorite = !favorite }) {
                        Icon(if (favorite) Icons.Default.Star else Icons.Default.StarOutline, "Favori",
                            tint = if (favorite) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = {
                        if (title.isNotBlank()) onSave(title, fields.filter { it.label.isNotBlank() || it.value.isNotBlank() }, notes, favorite)
                    }) { Text("Kaydet", color = VaultPurple, fontWeight = FontWeight.Bold) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            item {
                category?.let {
                    AssistChip(onClick = {}, label = { Text(it.name) },
                        leadingIcon = { Icon(Icons.Default.Folder, null, modifier = Modifier.size(16.dp)) })
                }
            }
            item {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Baslik") },
                    placeholder = { Text("Orn: Garanti Bankasi") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = VaultPurple))
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Alanlar", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = { fields = fields + VaultField("", "", true) }) {
                        Icon(Icons.Default.Add, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Alan Ekle")
                    }
                }
            }
            itemsIndexed(fields, key = { i, _ -> "f_$i" }) { index, field ->
                FieldEditor(field,
                    onUpdate = { updated -> fields = fields.toMutableList().also { it[index] = updated } },
                    onRemove = { if (fields.size > 1) fields = fields.toMutableList().also { it.removeAt(index) } }
                )
            }
            item {
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notlar (opsiyonel)") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp), maxLines = 5,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = VaultPurple))
            }
            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}

@Composable
private fun FieldEditor(field: VaultField, onUpdate: (VaultField) -> Unit, onRemove: () -> Unit) {
    var showVal by remember { mutableStateOf(!field.isSensitive) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = field.label, onValueChange = { onUpdate(field.copy(label = it)) },
                    label = { Text("Etiket") }, placeholder = { Text("Orn: IBAN") }, singleLine = true,
                    modifier = Modifier.weight(1f), textStyle = MaterialTheme.typography.bodySmall,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = VaultPurple))
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = onRemove, Modifier.size(32.dp)) {
                    Icon(Icons.Default.Close, "Kaldir", Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = field.value, onValueChange = { onUpdate(field.copy(value = it)) },
                label = { Text("Deger") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (!showVal && field.isSensitive) PasswordVisualTransformation() else VisualTransformation.None,
                trailingIcon = {
                    Row {
                        if (field.isSensitive) {
                            IconButton(onClick = { showVal = !showVal }, Modifier.size(32.dp)) {
                                Icon(if (showVal) Icons.Default.VisibilityOff else Icons.Default.Visibility, null, Modifier.size(18.dp))
                            }
                        }
                        IconButton(onClick = { onUpdate(field.copy(isSensitive = !field.isSensitive)) }, Modifier.size(32.dp)) {
                            Icon(if (field.isSensitive) Icons.Default.Lock else Icons.Default.LockOpen, "Hassas", Modifier.size(18.dp),
                                tint = if (field.isSensitive) VaultPurple else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = VaultPurple))
        }
    }
}
