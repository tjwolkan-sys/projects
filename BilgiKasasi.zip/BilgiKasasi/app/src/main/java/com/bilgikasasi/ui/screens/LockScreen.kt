package com.bilgikasasi.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bilgikasasi.ui.theme.VaultPurple
import com.bilgikasasi.ui.theme.VaultPurpleDark
import com.bilgikasasi.viewmodel.AuthState

@Composable
fun LockScreen(
    authState: AuthState,
    authError: String?,
    onPinSubmit: (String) -> Unit,
    onSetupPin: (String) -> Unit,
    onBiometricRequest: () -> Unit
) {
    val isSetup = authState == AuthState.SETUP_REQUIRED
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var isConfirmStep by remember { mutableStateOf(false) }
    var setupError by remember { mutableStateOf<String?>(null) }
    val maxLen = 6

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F0F1A), Color(0xFF1A1A2E), Color(0xFF16213E))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            // Lock icon
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(VaultPurple.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Lock,
                    contentDescription = null,
                    modifier = Modifier.size(40.dp),
                    tint = VaultPurple
                )
            }

            Spacer(Modifier.height(24.dp))

            Text(
                if (isSetup) {
                    if (isConfirmStep) "PIN'i tekrar girin" else "6 haneli PIN belirleyin"
                } else "PIN girin",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(Modifier.height(8.dp))

            Text(
                if (isSetup) "Kasanızı koruyacak PIN'i oluşturun" else "Kasanızın kilidini açın",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF9E9EB8)
            )

            Spacer(Modifier.height(32.dp))

            // PIN dots
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                val currentPin = if (isConfirmStep) confirmPin else pin
                repeat(maxLen) { i ->
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(
                                if (i < currentPin.length) VaultPurple else Color(0xFF2D2D44)
                            )
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // Error message
            val error = authError ?: setupError
            AnimatedVisibility(visible = error != null) {
                Text(
                    error ?: "",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(Modifier.height(32.dp))

            // Number pad
            val numbers = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("bio", "0", "del")
            )

            numbers.forEach { row ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    row.forEach { key ->
                        when (key) {
                            "bio" -> {
                                if (!isSetup) {
                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF2D2D44))
                                            .clickable { onBiometricRequest() },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Fingerprint, null,
                                            tint = VaultPurple, modifier = Modifier.size(28.dp))
                                    }
                                } else {
                                    Spacer(Modifier.size(72.dp))
                                }
                            }
                            "del" -> {
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF2D2D44))
                                        .clickable {
                                            if (isConfirmStep && confirmPin.isNotEmpty()) {
                                                confirmPin = confirmPin.dropLast(1)
                                            } else if (!isConfirmStep && pin.isNotEmpty()) {
                                                pin = pin.dropLast(1)
                                            }
                                            setupError = null
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Backspace, null,
                                        tint = Color(0xFF9E9EB8), modifier = Modifier.size(24.dp))
                                }
                            }
                            else -> {
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF2D2D44))
                                        .clickable {
                                            setupError = null
                                            if (isSetup) {
                                                if (isConfirmStep) {
                                                    if (confirmPin.length < maxLen) {
                                                        confirmPin += key
                                                        if (confirmPin.length == maxLen) {
                                                            if (confirmPin == pin) {
                                                                onSetupPin(pin)
                                                            } else {
                                                                setupError = "PIN'ler eşleşmiyor"
                                                                confirmPin = ""
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    if (pin.length < maxLen) {
                                                        pin += key
                                                        if (pin.length == maxLen) {
                                                            isConfirmStep = true
                                                        }
                                                    }
                                                }
                                            } else {
                                                if (pin.length < maxLen) {
                                                    pin += key
                                                    if (pin.length == maxLen) {
                                                        onPinSubmit(pin)
                                                        pin = ""
                                                    }
                                                }
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        key,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
