package com.bilgikasasi.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val VaultPurple = Color(0xFF6C63FF)
val VaultPurpleLight = Color(0xFFADA8FF)
val VaultPurpleDark = Color(0xFF3D35CC)
val VaultGold = Color(0xFFFFB300)
val VaultGreen = Color(0xFF00E676)
val VaultRed = Color(0xFFFF5252)
val VaultSurface = Color(0xFF1A1A2E)
val VaultSurfaceLight = Color(0xFF16213E)
val VaultBg = Color(0xFF0F0F1A)

private val DarkColorScheme = darkColorScheme(
    primary = VaultPurple,
    onPrimary = Color.White,
    primaryContainer = VaultPurpleDark,
    onPrimaryContainer = Color(0xFFE8E5FF),
    secondary = VaultGold,
    onSecondary = Color.Black,
    tertiary = VaultGreen,
    surface = VaultSurface,
    onSurface = Color(0xFFE4E4ED),
    surfaceVariant = VaultSurfaceLight,
    onSurfaceVariant = Color(0xFF9E9EB8),
    background = VaultBg,
    onBackground = Color(0xFFE4E4ED),
    error = VaultRed,
    outline = Color(0xFF2D2D44),
)

private val LightColorScheme = lightColorScheme(
    primary = VaultPurple,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8E5FF),
    onPrimaryContainer = Color(0xFF1A1145),
    secondary = Color(0xFFFF8F00),
    surface = Color(0xFFFAFAFF),
    onSurface = Color(0xFF1A1A2E),
    surfaceVariant = Color(0xFFF0F0F8),
    onSurfaceVariant = Color(0xFF5A5A7A),
    background = Color(0xFFF5F5FA),
    error = Color(0xFFD32F2F),
)

@Composable
fun VaultTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) {
    // Vault app defaults to dark theme for that premium security feel
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(colorScheme = colorScheme, typography = Typography(), content = content)
}
