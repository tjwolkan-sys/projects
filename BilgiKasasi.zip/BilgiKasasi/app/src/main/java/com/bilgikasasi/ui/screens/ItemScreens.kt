package com.bilgikasasi.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bilgikasasi.data.entity.Category
import com.bilgikasasi.data.entity.VaultField
import com.bilgikasasi.data.entity.VaultItem
import com.bilgikasasi.ui.theme.VaultPurple
import kotlinx.coroutines.launch

// ══════════════════════════════════════
// ITEM LIST SCREEN
// ══════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ItemListScreen(
    category: Category?,
    items: List<VaultItem>,
    decryptTitle: (VaultItem) -> String,
    onBack: () -> Unit,
    onItemClick: (Long) -> Unit,
    onAddClick: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(category?.name ?: "Kayıtlar") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddClick, containerColor = VaultPurple) {
                Icon(Icons.Default.Add, "Ekle", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    ) { padding ->
        if (items.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Text("Bu kategoride kayıt yok", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    Text("+ ile yeni ekleyin", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(items, key = { it.id }) { item ->
                    val title = remember(item.id, item.updatedAt) { decryptTitle(item) }
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onItemClick(item.id) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Article, null, tint = VaultPurple, modifier = Modifier.size(24.dp))
                            Spacer(Modifier.width(14.dp))
                            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium,
                                modifier = Modifier.weight(1f))
                            if (item.isFavorite) {
                                Icon(Icons.Default.Star, null, tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                            }
                            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                item { Spacer(Modifier.height(72.dp)) }
            }
        }
    }
}

// ══════════════════════════════════════
// ITEM DETAIL SCREEN
// ══════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ItemDetailScreen(
    item: VaultItem?,
    category: Category?,
    decryptTitle: (VaultItem) -> String,
    decryptFields: (VaultItem) -> List<VaultField>,
    decryptNotes: (VaultItem) -> String,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    if (item == null) { onBack(); return }

    val title = remember(item.id, item.updatedAt) { decryptTitle(item) }
    val fields = remember(item.id, item.updatedAt) { decryptFields(item) }
    val notes = remember(item.id, item.updatedAt) { decryptNotes(item) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri") } },
                actions = {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            if (item.isFavorite) Icons.Default.Star else Icons.Default.StarOutline,
                            "Favori",
                            tint = if (item.isFavorite) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Düzenle") }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, "Sil", tint = MaterialTheme.colorScheme.error)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            // Category badge
            item {
                if (category != null) {
                    AssistChip(
                        onClick = {},
                        label = { Text(category.name, style = MaterialTheme.typography.labelMedium) },
                        leadingIcon = { Icon(Icons.Default.Folder, null, modifier = Modifier.size(16.dp)) }
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }

            // Fields
            items(fields) { field ->
                FieldCard(field = field, context = context)
            }

            // Notes
            if (notes.isNotBlank()) {
                item {
                    Spacer(Modifier.height(4.dp))
                    Text("Notlar", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Text(notes, modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Kaydı Sil") },
            text = { Text("'$title' kalıcı olarak silinecek. Bu işlem geri alınamaz.") },
            confirmButton = {
                Button(onClick = { onDelete(); showDeleteDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Sil") }
            },
            dismissButton = { TextButton(onClick = { showDeleteDialog = false }) { Text("İptal") } }
        )
    }
}

@Composable
private fun FieldCard(field: VaultField, context: Context) {
    var isVisible by remember { mutableStateOf(!field.isSensitive) }
    val displayValue = if (isVisible) field.value else "••••••••"

    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(field.label, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(2.dp))
                Text(displayValue, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            }
            if (field.isSensitive) {
                IconButton(onClick = { isVisible = !isVisible }, modifier = Modifier.size(36.dp)) {
                    Icon(
                        if (isVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        "Göster/Gizle",
                        modifier = Modifier.size(20.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            IconButton(
                onClick = {
                    val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cb.setPrimaryClip(ClipData.newPlainText(field.label, field.value))
                    Toast.makeText(context, "${field.label} kopyalandı", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(Icons.Default.ContentCopy, "Kopyala", modifier = Modifier.size(20.dp), tint = VaultPurple)
            }
        }
    }
}
