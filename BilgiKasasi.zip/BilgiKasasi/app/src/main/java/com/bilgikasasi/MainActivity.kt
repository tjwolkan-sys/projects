package com.bilgikasasi

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.bilgikasasi.data.entity.VaultField
import com.bilgikasasi.ui.navigation.Screen
import com.bilgikasasi.ui.screens.*
import com.bilgikasasi.ui.theme.VaultTheme
import com.bilgikasasi.viewmodel.AuthState
import com.bilgikasasi.viewmodel.MainViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var biometricPrompt: BiometricPrompt
    private var onBiometricSuccess: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        biometricPrompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onBiometricSuccess?.invoke()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                        errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
                        Toast.makeText(this@MainActivity, errString, Toast.LENGTH_SHORT).show()
                    }
                }
            })

        setContent {
            VaultTheme {
                VaultApp(
                    onBiometricRequest = { onSuccess ->
                        onBiometricSuccess = onSuccess
                        showBiometricPrompt()
                    }
                )
            }
        }
    }

    private fun showBiometricPrompt() {
        val canAuth = BiometricManager.from(this)
            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "Biyometrik dogrulama kulanilamiyor", Toast.LENGTH_SHORT).show()
            return
        }
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Bilgi Kasasi")
            .setSubtitle("Parmak izi veya yuz ile girin")
            .setNegativeButtonText("PIN Kullan")
            .build()
        biometricPrompt.authenticate(promptInfo)
    }
}

@Composable
fun VaultApp(
    vm: MainViewModel = viewModel(),
    onBiometricRequest: (onSuccess: () -> Unit) -> Unit
) {
    val authState by vm.authState.collectAsState()
    val authError by vm.authError.collectAsState()
    val navController = rememberNavController()
    val categories by vm.allCategories.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val recentItems by vm.recentItems.collectAsState()
    val allItems by vm.allItems.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        vm.toast.collectLatest { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
    }

    // Auto-lock: when auth changes to LOCKED, navigate to lock screen
    LaunchedEffect(authState) {
        if (authState != AuthState.UNLOCKED) {
            navController.navigate(Screen.Lock.route) {
                popUpTo(0) { inclusive = true }
            }
        }
    }

    NavHost(navController, startDestination = Screen.Lock.route) {
        composable(Screen.Lock.route) {
            LockScreen(
                authState = authState,
                authError = authError,
                onPinSubmit = { pin -> vm.verifyPin(pin) },
                onSetupPin = { pin -> vm.setupPin(pin); navController.navigate(Screen.Home.route) { popUpTo(0) { inclusive = true } } },
                onBiometricRequest = { onBiometricRequest { vm.unlockWithBiometric(); navController.navigate(Screen.Home.route) { popUpTo(0) { inclusive = true } } } }
            )
            // Navigate to home if already unlocked
            LaunchedEffect(authState) {
                if (authState == AuthState.UNLOCKED) {
                    navController.navigate(Screen.Home.route) { popUpTo(0) { inclusive = true } }
                }
            }
        }

        composable(Screen.Home.route) {
            HomeScreen(
                categories = categories,
                recentItems = recentItems,
                favorites = favorites,
                getCategoryItemCount = { catId ->
                    val count by vm.getCategoryItemCount(catId).collectAsState(initial = 0)
                    count
                },
                decryptTitle = vm::decryptTitle,
                onCategoryClick = { navController.navigate(Screen.ItemList.create(it)) },
                onItemClick = { navController.navigate(Screen.ItemDetail.create(it)) },
                onSearchClick = { navController.navigate(Screen.Search.route) },
                onSettingsClick = { navController.navigate(Screen.Settings.route) },
                onLock = { vm.lock() }
            )
        }

        composable(Screen.ItemList.route, arguments = listOf(navArgument("categoryId") { type = NavType.LongType })) { entry ->
            val catId = entry.arguments?.getLong("categoryId") ?: return@composable
            val items by vm.getItemsByCategory(catId).collectAsState(initial = emptyList())
            val cat by produceState<com.bilgikasasi.data.entity.Category?>(null, catId) { value = vm.getCategoryById(catId) }
            ItemListScreen(
                category = cat, items = items, decryptTitle = vm::decryptTitle,
                onBack = { navController.popBackStack() },
                onItemClick = { navController.navigate(Screen.ItemDetail.create(it)) },
                onAddClick = { navController.navigate(Screen.AddEdit.createNew(catId)) }
            )
        }

        composable(Screen.ItemDetail.route, arguments = listOf(navArgument("itemId") { type = NavType.LongType })) { entry ->
            val itemId = entry.arguments?.getLong("itemId") ?: return@composable
            var item by remember { mutableStateOf<com.bilgikasasi.data.entity.VaultItem?>(null) }
            var cat by remember { mutableStateOf<com.bilgikasasi.data.entity.Category?>(null) }
            LaunchedEffect(itemId) {
                item = vm.getItemById(itemId)
                item?.let { cat = vm.getCategoryById(it.categoryId) }
            }
            ItemDetailScreen(
                item = item, category = cat,
                decryptTitle = vm::decryptTitle, decryptFields = vm::decryptFields, decryptNotes = vm::decryptNotes,
                onBack = { navController.popBackStack() },
                onEdit = { item?.let { navController.navigate(Screen.AddEdit.createEdit(it.categoryId, it.id)) } },
                onDelete = { item?.let { vm.deleteItem(it); navController.popBackStack() } },
                onToggleFavorite = { item?.let { vm.toggleFavorite(it); scope.launch { item = vm.getItemById(itemId) } } }
            )
        }

        composable(Screen.AddEdit.route, arguments = listOf(
            navArgument("categoryId") { type = NavType.LongType },
            navArgument("itemId") { defaultValue = -1L; type = NavType.LongType }
        )) { entry ->
            val catId = entry.arguments?.getLong("categoryId") ?: return@composable
            val itemId = entry.arguments?.getLong("itemId") ?: -1L
            var cat by remember { mutableStateOf<com.bilgikasasi.data.entity.Category?>(null) }
            var existingItem by remember { mutableStateOf<com.bilgikasasi.data.entity.VaultItem?>(null) }
            var initialTitle by remember { mutableStateOf("") }
            var initialFields by remember { mutableStateOf<List<VaultField>>(emptyList()) }
            var initialNotes by remember { mutableStateOf("") }
            var initFav by remember { mutableStateOf(false) }
            var loaded by remember { mutableStateOf(false) }

            LaunchedEffect(catId, itemId) {
                cat = vm.getCategoryById(catId)
                if (itemId > 0) {
                    vm.getItemById(itemId)?.let { item ->
                        existingItem = item
                        initialTitle = vm.decryptTitle(item)
                        initialFields = vm.decryptFields(item)
                        initialNotes = vm.decryptNotes(item)
                        initFav = item.isFavorite
                    }
                } else {
                    cat?.let { initialFields = vm.getFieldTemplate(it) }
                }
                loaded = true
            }

            if (loaded) {
                AddEditScreen(
                    category = cat, existingItem = existingItem,
                    initialTitle = initialTitle, initialFields = initialFields,
                    initialNotes = initialNotes, isFavorite = initFav,
                    onBack = { navController.popBackStack() },
                    onSave = { title, fields, notes, fav ->
                        vm.saveItem(catId, title, fields, notes, existingItem?.id, fav)
                        navController.popBackStack()
                    }
                )
            }
        }

        composable(Screen.Search.route) {
            SearchScreen(allItems = allItems, categories = categories,
                decryptTitle = vm::decryptTitle,
                onItemClick = { navController.navigate(Screen.ItemDetail.create(it)) },
                onBack = { navController.popBackStack() })
        }

        composable(Screen.Settings.route) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
    }
}
