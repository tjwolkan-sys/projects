package com.bilgikasasi.data.repository

import com.bilgikasasi.data.dao.CategoryDao
import com.bilgikasasi.data.dao.VaultItemDao
import com.bilgikasasi.data.entity.*
import com.bilgikasasi.security.CryptoManager
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class VaultRepository(
    private val categoryDao: CategoryDao,
    private val vaultItemDao: VaultItemDao
) {
    private val gson = Gson()

    // ── Categories ──
    val allCategories: Flow<List<Category>> = categoryDao.getAll()
    suspend fun getCategoryById(id: Long) = categoryDao.getById(id)
    fun getCategoryItemCount(catId: Long) = categoryDao.getItemCount(catId)
    suspend fun insertCategory(cat: Category) = categoryDao.insert(cat)
    suspend fun updateCategory(cat: Category) = categoryDao.update(cat)
    suspend fun deleteCategory(cat: Category) = categoryDao.delete(cat)

    // ── Vault Items (encrypted) ──
    fun getItemsByCategory(categoryId: Long): Flow<List<VaultItem>> =
        vaultItemDao.getByCategory(categoryId)

    fun getFavorites(): Flow<List<VaultItem>> = vaultItemDao.getFavorites()
    fun getAllItems(): Flow<List<VaultItem>> = vaultItemDao.getAll()
    fun getRecentItems(limit: Int = 10): Flow<List<VaultItem>> = vaultItemDao.getRecent(limit)
    suspend fun getItemById(id: Long) = vaultItemDao.getById(id)

    suspend fun saveItem(
        categoryId: Long,
        title: String,
        fields: List<VaultField>,
        notes: String,
        existingId: Long? = null,
        isFavorite: Boolean = false
    ): Long {
        val encTitle = CryptoManager.encrypt(title)
        val encFields = CryptoManager.encrypt(gson.toJson(fields))
        val encNotes = CryptoManager.encrypt(notes)

        val item = VaultItem(
            id = existingId ?: 0,
            categoryId = categoryId,
            title = encTitle,
            fieldsJson = encFields,
            notes = encNotes,
            isFavorite = isFavorite,
            updatedAt = System.currentTimeMillis(),
            createdAt = if (existingId != null) {
                vaultItemDao.getById(existingId)?.createdAt ?: System.currentTimeMillis()
            } else System.currentTimeMillis()
        )
        return vaultItemDao.insert(item)
    }

    suspend fun toggleFavorite(item: VaultItem) {
        vaultItemDao.update(item.copy(isFavorite = !item.isFavorite, updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteItem(item: VaultItem) = vaultItemDao.delete(item)

    // ── Decryption helpers ──
    fun decryptTitle(item: VaultItem): String = CryptoManager.decrypt(item.title)

    fun decryptFields(item: VaultItem): List<VaultField> {
        return try {
            val json = CryptoManager.decrypt(item.fieldsJson)
            val type = object : TypeToken<List<VaultField>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun decryptNotes(item: VaultItem): String = CryptoManager.decrypt(item.notes)

    fun getFieldTemplate(category: Category): List<VaultField> {
        return try {
            if (category.fieldTemplate.isBlank()) return emptyList()
            val type = object : TypeToken<List<Map<String, Any>>>() {}.type
            val list: List<Map<String, Any>> = gson.fromJson(category.fieldTemplate, type)
            list.map { VaultField(
                label = it["label"] as? String ?: "",
                value = "",
                isSensitive = it["isSensitive"] as? Boolean ?: true
            ) }
        } catch (e: Exception) { emptyList() }
    }
}
