package com.bilgikasasi.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val icon: String = "Lock",         // Material icon name
    val colorHex: String = "#6C63FF",
    val fieldTemplate: String = "",    // JSON: default field labels for new items
    val sortOrder: Int = 0
)
