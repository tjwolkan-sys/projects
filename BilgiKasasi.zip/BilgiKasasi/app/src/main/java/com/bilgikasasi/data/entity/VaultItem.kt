package com.bilgikasasi.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "vault_items",
    foreignKeys = [ForeignKey(
        entity = Category::class,
        parentColumns = ["id"],
        childColumns = ["categoryId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("categoryId")]
)
data class VaultItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val categoryId: Long,
    val title: String,                          // Encrypted
    val fieldsJson: String,                     // Encrypted JSON: [{"label":"IBAN","value":"TR...","isSensitive":true}]
    val notes: String = "",                     // Encrypted
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

// Deserialized field model (not stored directly)
data class VaultField(
    val label: String,
    val value: String,
    val isSensitive: Boolean = true    // Masked by default
)

data class VaultItemWithCategory(
    val item: VaultItem,
    val categoryName: String,
    val categoryColor: String,
    val categoryIcon: String
)
