package com.bilgikasasi.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest

object PinManager {
    private const val PREFS_NAME = "vault_secure_prefs"
    private const val KEY_PIN_HASH = "pin_hash"
    private const val KEY_PIN_SALT = "pin_salt"
    private const val KEY_IS_SETUP = "is_setup"
    private const val KEY_AUTO_LOCK_SECONDS = "auto_lock_seconds"

    private fun getPrefs(context: Context): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context, PREFS_NAME, masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun isSetup(context: Context): Boolean = getPrefs(context).getBoolean(KEY_IS_SETUP, false)

    fun setupPin(context: Context, pin: String) {
        val salt = generateSalt()
        val hash = hashPin(pin, salt)
        getPrefs(context).edit()
            .putString(KEY_PIN_HASH, hash)
            .putString(KEY_PIN_SALT, salt)
            .putBoolean(KEY_IS_SETUP, true)
            .apply()
    }

    fun verifyPin(context: Context, pin: String): Boolean {
        val prefs = getPrefs(context)
        val storedHash = prefs.getString(KEY_PIN_HASH, null) ?: return false
        val salt = prefs.getString(KEY_PIN_SALT, null) ?: return false
        return hashPin(pin, salt) == storedHash
    }

    fun changePin(context: Context, oldPin: String, newPin: String): Boolean {
        if (!verifyPin(context, oldPin)) return false
        setupPin(context, newPin)
        return true
    }

    fun getAutoLockSeconds(context: Context): Int =
        getPrefs(context).getInt(KEY_AUTO_LOCK_SECONDS, 30)

    fun setAutoLockSeconds(context: Context, seconds: Int) {
        getPrefs(context).edit().putInt(KEY_AUTO_LOCK_SECONDS, seconds).apply()
    }

    private fun generateSalt(): String {
        val bytes = ByteArray(32)
        java.security.SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun hashPin(pin: String, salt: String): String {
        val input = "$pin:$salt"
        // Multiple rounds for brute-force resistance
        var hash = input.toByteArray(Charsets.UTF_8)
        val digest = MessageDigest.getInstance("SHA-256")
        repeat(10000) {
            hash = digest.digest(hash + salt.toByteArray())
        }
        return hash.joinToString("") { "%02x".format(it) }
    }
}
