package com.bilgikasasi.data.dao

import androidx.room.*
import com.bilgikasasi.data.entity.Category
import com.bilgikasasi.data.entity.VaultItem
import kotlinx.coroutines.flow.Flow

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY sortOrder ASC, name ASC")
    fun getAll(): Flow<List<Category>>

    @Query("SELECT * FROM categories WHERE id = :id")
    suspend fun getById(id: Long): Category?

    @Query("SELECT COUNT(*) FROM vault_items WHERE categoryId = :categoryId")
    fun getItemCount(categoryId: Long): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: Category): Long

    @Update
    suspend fun update(category: Category)

    @Delete
    suspend fun delete(category: Category)
}

@Dao
interface VaultItemDao {
    @Query("SELECT * FROM vault_items WHERE categoryId = :categoryId ORDER BY isFavorite DESC, updatedAt DESC")
    fun getByCategory(categoryId: Long): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE isFavorite = 1 ORDER BY updatedAt DESC")
    fun getFavorites(): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items ORDER BY updatedAt DESC")
    fun getAll(): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE id = :id")
    suspend fun getById(id: Long): VaultItem?

    @Query("SELECT * FROM vault_items ORDER BY updatedAt DESC LIMIT :limit")
    fun getRecent(limit: Int = 10): Flow<List<VaultItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: VaultItem): Long

    @Update
    suspend fun update(item: VaultItem)

    @Delete
    suspend fun delete(item: VaultItem)
}
