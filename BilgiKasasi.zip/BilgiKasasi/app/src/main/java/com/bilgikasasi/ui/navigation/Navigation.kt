package com.bilgikasasi.ui.navigation

sealed class Screen(val route: String) {
    data object Lock : Screen("lock")
    data object Home : Screen("home")
    data object ItemList : Screen("items/{categoryId}") {
        fun create(catId: Long) = "items/$catId"
    }
    data object ItemDetail : Screen("detail/{itemId}") {
        fun create(itemId: Long) = "detail/$itemId"
    }
    data object AddEdit : Screen("addEdit/{categoryId}?itemId={itemId}") {
        fun createNew(catId: Long) = "addEdit/$catId"
        fun createEdit(catId: Long, itemId: Long) = "addEdit/$catId?itemId=$itemId"
    }
    data object Search : Screen("search")
    data object Settings : Screen("settings")
}
