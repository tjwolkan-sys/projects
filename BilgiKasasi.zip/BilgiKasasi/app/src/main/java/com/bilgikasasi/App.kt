package com.bilgikasasi

import android.app.Application
import com.bilgikasasi.data.database.AppDatabase
import com.bilgikasasi.data.repository.VaultRepository

class App : Application() {
    val database by lazy { AppDatabase.get(this) }
    val repository by lazy { VaultRepository(database.categoryDao(), database.vaultItemDao()) }
}
