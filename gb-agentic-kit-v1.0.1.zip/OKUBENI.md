# Agentik Çalışma Yapısı — Kurulum

Bu paket, projenize Global Bilgi agentik çalışma standardını kurar: ortak çalışma
sözleşmesi (`AGENTS.md`), ajan köprüleri, ortak skill kütüphanesi ve doküman hafızası.
Kurulum sonunda Claude açılır ve projenizi inceleyip `AGENTS.md`'nin PROJE bölümünü
sizin reponuza göre doldurur.

## 1. Zip'i çıkarın

Zip'i bir klasöre **tamamen çıkarın**. Zip'in içinden doğrudan çalıştırmayın.

## 2. Kurulumu başlatın

Çıkardığınız klasörde bir komut istemi açın ve **entegre etmek istediğiniz projenin
yolunu vererek** çalıştırın:

```
kur.cmd C:\projeler\benim-projem
```

Yolda boşluk varsa tırnak içine alın:

```
kur.cmd "D:\repos\odeme servisi"
```

Yol vermeden çalıştırırsanız yol sorulur.

> PowerShell tercih ederseniz: `.\gb-agentic-setup.ps1 C:\projeler\benim-projem`
> (mail ile gelen dosyada engel çıkarsa `kur.cmd` kullanın — engeli o kaldırıyor.)

## 3. Ne olacak

1. Script projenizi kontrol eder, uygulama adını git remote'undan türetir, teknoloji
   yığınını tespit eder.
2. Ortak taban dosyalarını yazar. **Var olan dosyanın üzerine yazmaz**, atlar ve
   size bildirir.
3. `.gitignore`'a yalnız eksik 2 satırı ekler; mevcut içeriğe dokunmaz.
4. **Claude Code kurulu değilse kurmayı teklif eder.** Onay verirseniz resmî
   kurulumu indirir (yönetici yetkisi gerekmez, kullanıcı profilinize kurulur).
5. Claude Code açılır ve projenizi inceleyip dokümantasyonu üretir.
6. Sonunda Claude size birkaç soru sorar — cevabı kodda olmayan, size özel şeyler
   (bağımlılık deposuna erişim, araç yolları, entegrasyon branch'i gibi). Cevaplarınız
   kalıcı kurala dönüşür.

Kurulum **tekrar çalıştırılabilir**: ikinci kez çalıştırmak hiçbir şeyi bozmaz.

### Claude Code kurulumu hakkında

- Kurulum yeri: `%USERPROFILE%\.local\bin` — **yönetici yetkisi gerekmez**.
- İndirme boyutu ~330 MB, internet erişimi gerekir.
- Kurulum başarısız olursa (kurumsal ağ engeli vb.) agentik dosyalar **yine kurulur**;
  ekranda elle kurulum seçenekleri ve çalıştırmanız gereken komut yazar.
- **İlk açılışta tarayıcıdan giriş yapmanız istenir.** Claude Code Pro, Max, Team,
  Enterprise veya Console hesabı gerektirir; ücretsiz plan yeterli değildir.
  Giriş sonrası bootstrap kendiliğinden başlamazsa ekrandaki komutu tekrar çalıştırın.

## 4. Kurulumdan sonra

Araç yollarınızı tanımlayın (bu dosya commit'lenmez):

```
copy .codex\TOOL-PATHS.example.properties .codex\TOOL-PATHS.local.properties
```

Sonra gerçek Maven / JDK / Node yollarınızı içine yazın.

## Önkoşullar

| Gereksinim | Not |
|---|---|
| Windows PowerShell 5.1+ | Windows'ta hazır gelir |
| git | Proje git deposu olmalı (history ve sync akışları git bekler) |
| Claude Code | Kurulu değilse script kurmayı teklif eder |
| Claude hesabı | Pro / Max / Team / Enterprise / Console |

## Faydalı bayraklar

| Bayrak | İşlev |
|---|---|
| `-DryRun` | Hiçbir şey yazmaz, ne yapacağını listeler |
| `-NoClaude` | Yalnız dosyaları kurar, Claude açmaz |
| `-InstallClaude` | Claude Code yoksa sormadan kurar |
| `-SkipClaudeInstall` | Claude Code yoksa kurmayı denemez |
| `-AppName "Ödeme Servisi"` | Uygulama adını elle verir |

`kur.cmd C:\projem -DryRun` şeklinde birlikte kullanılabilir.

## Sorun çıkarsa

| Belirti | Çözüm |
|---|---|
| "betik çalıştırma devre dışı" / execution policy hatası | `.ps1` yerine `kur.cmd` kullanın |
| "gb-agentic-setup.ps1 bulunamadi" | Zip'i klasöre tam çıkarmadınız |
| "Hedef, kurulum kitinin kendisi" | Proje yolunu parametre olarak vermeyi atladınız |
| Claude Code kurulumu başarısız | Ağ engeli olabilir; ekrandaki elle kurulum komutlarını deneyin veya ağ ekibine `claude.ai` erişimini sorun |
| Giriş ekranında kaldınız | Tarayıcıdan giriş yapın, sonra ekrandaki `claude --effort max ...` komutunu tekrar çalıştırın |

Takıldığınız yerde kurulum çıktısının ekran görüntüsüyle bize dönün.
