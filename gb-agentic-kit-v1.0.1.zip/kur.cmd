@echo off
setlocal
rem ============================================================
rem  Global Bilgi - Agentik Calisma Yapisi Kurulumu
rem
rem  Kullanim:
rem    kur.cmd C:\projeler\benim-projem
rem    kur.cmd "D:\repos\proje adinda bosluk var"
rem    kur.cmd                    (yol sorulur)
rem
rem  Bu sarmalayici iki isi halleder:
rem    1) PowerShell execution policy engelini asar
rem    2) Mail/zip ile gelen dosyalardaki "blocked" isaretini kaldirir
rem ============================================================

set "PS1=%~dp0gb-agentic-setup.ps1"

if not exist "%PS1%" (
  echo.
  echo  [x] gb-agentic-setup.ps1 bulunamadi.
  echo      Zip'i klasore TAMAMEN cikardiginizdan emin olun
  echo      ^(zip icinden dogrudan calistirmayin^).
  echo.
  exit /b 1
)

rem 1) mark-of-the-web temizligi
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Filter *.ps1 -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue"

rem 2) kurulumu baslat (-File arguman tirnaklamasini dogru yapar)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%" %*
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
  echo.
  echo  Kurulum %RC% kodu ile sonlandi.
)

endlocal & exit /b %RC%
