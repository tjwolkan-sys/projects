﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Global Bilgi agentik çalışma yapısını mevcut bir projeye kurar.

.DESCRIPTION
    Ortak taban dosyalarını (AGENTS.md, ajan köprüleri, gb-* skill'leri, docs/ iskeleti,
    izin baseline'ı) bulunduğunuz proje dizinine yazar; ardından Claude Code'u açıp
    PROJE bölümünü ve mimari dokümanları dolduran bootstrap görevini başlatır.

    Bu dosya kendi kendine yeterlidir: ağ, VPN veya git erişimi gerektirmez.

.PARAMETER ProjectPath
    Agentik yapının kurulacağı proje dizini. Verilmezse bulunduğunuz dizin kullanılır;
    kurulum kitinin içinden çalıştırıyorsanız yol sorulur.

.PARAMETER AppName
    AGENTS.md başlığında kullanılacak uygulama adı. Verilmezse git remote'undan,
    olmazsa klasör adından türetilir.

.PARAMETER Effort
    Claude oturumunun effort seviyesi. Varsayılan: max

.PARAMETER PermissionMode
    Claude izin modu. Varsayılan: auto

.PARAMETER Model
    Claude modeli (ör. opus, sonnet). Verilmezse oturum varsayılanı kullanılır.

.PARAMETER Force
    Mevcut dosyaların üzerine yazar. Varsayılan davranış: var olanı atla.

.PARAMETER NoClaude
    Yalnız dosyaları kurar, Claude oturumu başlatmaz.

.PARAMETER InstallClaude
    Claude Code kurulu değilse sormadan kurar (gözetimsiz kurulum için).

.PARAMETER SkipClaudeInstall
    Claude Code kurulu değilse kurmayı hiç denemez, yalnız bilgilendirir.

.PARAMETER DryRun
    Hiçbir dosya yazmaz; ne yapılacağını listeler.

.EXAMPLE
    .\gb-agentic-setup.ps1 C:\projeler\benim-servisim

.EXAMPLE
    .\gb-agentic-setup.ps1 -ProjectPath D:\repos\odeme -AppName "Odeme Servisi" -NoClaude
#>
[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [string]$ProjectPath,
    [string]$AppName,
    [ValidateSet('low', 'medium', 'high', 'xhigh', 'max')]
    [string]$Effort = 'max',
    [ValidateSet('auto', 'acceptEdits', 'bypassPermissions', 'manual', 'dontAsk', 'plan')]
    [string]$PermissionMode = 'auto',
    [string]$Model,
    [switch]$Force,
    [switch]$NoClaude,
    [switch]$InstallClaude,
    [switch]$SkipClaudeInstall,
    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
$BaselineVersion = '1.0.1'
$GitignoreKey = '.gitignore.append'

# ============================== PAYLOAD ==============================
# Bu blok build-installer.ps1 tarafından payload/ klasöründen üretilir.
$Payload = [ordered]@{}
$Payload['.claude/settings.json'] = @'
{
  "permissions": {
    "allow": [
      "Read",
      "Edit",
      "Bash(git status)",
      "Bash(git diff:*)",
      "Bash(git log:*)",
      "Bash(git branch:*)",
      "Bash(git fetch:*)",
      "Bash(rg:*)",
      "Bash(mvn -o:*)",
      "Bash(npm run test:*)",
      "Bash(npm run build:*)",
      "Bash(go test:*)",
      "Bash(go build:*)",
      "Bash(go vet:*)"
    ],
    "deny": [
      "Bash(rm -rf:*)",
      "Bash(git push --force:*)",
      "Bash(git reset --hard:*)",
      "Bash(curl:*)",
      "Read(./**/*.env)",
      "Read(./**/*.env.*)",
      "Read(./**/TOOL-PATHS.local.properties)",
      "Read(./**/settings.local.json)",
      "Read(./**/*.pem)",
      "Read(./**/settings.xml)"
    ]
  }
}

'@

$Payload['.codex/BOOTSTRAP-PROMPT.md'] = @'
# Bootstrap Görevi — PROJE Bölümü ve Mimari Dokümanlar

Bu dosya kurulum script'i tarafından yerleştirildi. **Tek seferlik bootstrap görevini** tanımlar; tamamlandıktan sonra repoda kalır ve büyük mimari değişimlerden sonra yeniden çalıştırılabilir.

## Durum
- Bu repoya Global Bilgi agentik çalışma yapısı yeni kuruldu.
- `AGENTS.md`'nin **Ortak Taban** bloğu hazır; **`# PROJE` bölümü şablon hâlinde boş**.
- `docs/` iskeleti hazır; `docs/architecture/` yalnız `README.md` içeriyor.
- Ortak `gb-*` skill'leri kurulu. Proje skill'i henüz yok.

## Görev
Repoyu **derinlemesine** incele ve `AGENTS.md`'nin `# PROJE` bölümü ile `docs/architecture/` doküman setini bu reponun **gerçeğine** göre üret. Sonunda geliştiriciye yalnız koddan çıkarılamayan soruları sor ve cevapları uygula.

---

## 1. İnceleme (uydurma yok, ölç)

Sırayla ve gerçekten oku:

**Build ve bağımlılık**
- Build dosyaları: `pom.xml` / `build.gradle(.kts)` / `package.json` / `go.mod` / `*.csproj` / `pyproject.toml` / `requirements.txt` / `Makefile` / `Dockerfile` / `docker-compose*.yml`
- Bağımlılık **sürümlerini** not al; sabitlenmiş araç sürümlerini (plugin'lerin indirdiği Node/JDK gibi) ayrıca yaz — bunlar contract'tır.
- Artifact deposu (iç registry/mirror) kullanılıyor mu?

**Kaynak kökleri ve mimari**
- Kaynak/test kökleri; hangileri build'e **bağlı**, hangileri değil (ör. pom'da tanımlı olmayan bir `src/integration-test`).
- Paket/klasör ağacı ve her birinin sorumluluğu. Dosya **sayıları** ve en büyük dosyaların **satır sayıları** — bakım yükü buradadır.
- Frontend/backend ayrımı; frontend build çıktısı nereye gidiyor, hangi yolla sunuluyor.

**Config ve çalışma zamanı**
- Config nereden geliyor: dosya, env, DB tablosu, config server? Bootstrap zinciri ne?
- Uygulamanın beklediği property/env anahtarlarını çıkar (kod içi `${...}` / `@Value` / `os.Getenv` / `process.env`).
- Başlangıç sırası (listener/filter/middleware), servlet/route eşlemeleri.
- Tek instans mı, çok instans mı? Çok instansta ortak state ve lider seçimi nasıl?

**Dış boundary'ler ve contract'lar**
- Mesajlaşma kanalları, event/mesaj tipleri, kuyruk/topic adları — **başka repolarla paylaşılan** adları özellikle işaretle.
- API yüzeyi, kimlik/rol adları, güvenlik zincirleri.
- Şema/persistence: entity sayısı, migration yönetimi, audit mekanizması.
- Enum'lardaki sabit id/sıra bağımlılıkları (ordinal'e bağlı davranış, DB ile eşleşen sabit id'ler).

**Test ve gözlemlenebilirlik**
- Test dosya sayıları ve çerçeveleri; hangi alanlar test edilmiş, hangileri çıplak.
- Log yapılandırması, log dosyaları, saklama süresi, health/metrik uçları.

**Doğrulama komutlarını gerçekten dene**
- Derleme ve hedefli test komutunu çalıştır. Çalışmıyorsa **neden** çalışmadığını tam olarak kaydet (eksik artifact adı, erişilemeyen depo, sürüm uyuşmazlığı).
- Yerel araç sürümlerini ölç (`java -version`, `mvn -v`, `node -v`, `go version` …) ve projenin hedef sürümüyle karşılaştır.

## 2. `# PROJE` bölümünü doldur

Şablondaki başlıkları koru, içeriği gerçekle değiştir:

- **Misyon** — Uygulama ne, neden kritik, bozulursa ne kaybedilir, ajan neyi **asla** bozmamalı. Tek instans varsayımı gibi mimari önkabulleri burada yaz.
- **Proje Kuralları** — Bu bölümü 5. adımda doldur (geliştirici cevapları buraya tarihli kural olarak yazılır). Şimdilik şablon maddesini bırak; soru sorulmadıysa "Henüz onaylanmış proje kuralı yok." yaz.
- **Repo Haritası** — Yol → ne var. Sayılarla (dosya adedi, satır sayısı). Build'e bağlı olmayan kaynak köklerini açıkça işaretle.
- **Teknoloji Yığını** — **Sürümleriyle**. Sabitlenmiş araç sürümlerini ve yığın tavanını (bir bileşen yüzünden daha yeni sürüme geçilemiyorsa) yaz.
- **Doğrulama Komutları** — Gerçekten çalışan komutlar. Çalışmıyorsa kanonik komutu yaz **ve** ölçülen durumu ayrı bir alt başlıkta dürüstçe kaydet. Bu ortamda kalıcı bir kısıt varsa (depo erişimi yok gibi) bunu **bağlayıcı kural** olarak yaz.
- **Mimari Dokümanlar** — `docs/architecture/` dosyalarının özeti + linki. Ayrıntı orada kalır, burada tekrarlanmaz.
- **Yüksek-Riskli Alanlar** — Dosya + satır sayısı + neden riskli. Her madde "karakterizasyon testi olmadan değişmez" kuralına tabi.
- **Domain Contract'ları** — Geçiş notu olmadan değişmeyecek her şey: kanal/event/topic adları, sabit id'ler ve **tam listeleri**, rol adları, API yolları, property anahtarları, enum sırası bağımlılıkları, audit alan adları. Sayı verirken **doğru say**.
- **Proje Skill Envanteri** — Henüz yoksa "henüz yok" ve nereye eklendiği.
- **Roadmap** — Dosyalanmış roadmap yoksa bunu yaz; koddan çıkan roadmap adaylarını (yükseltme zorunlulukları, eksik health/metrik) önceliklendirmeden listele.
- **Açık Sorular** — Koddan çıkarılamayanlar. Bunlar 4. adımda sorulacak.

**Yazım kuralları**
- Kısa, emir kipinde, ölçülebilir. "İyi tasarlanmış" gibi değerlendirme yazma; sayı ve dosya adı yaz.
- **Sır/IP/credential/müşteri bilgisi yazma.** İç sunucu adreslerini yer tutucuyla an (`<NEXUS_HOST>`, `<DB_HOST>`).
- **Bilmediğini uydurma.** Emin olmadığın her şey "Açık Sorular"a gider.
- Kod içinde bulduğun uyarıları/TODO'ları ve bilinçli görünen tuhaflıkları kaydet — bunlar en değerli bilgidir.

## 3. `docs/architecture/` setini üret

`docs/architecture/README.md`'deki standarda uyarak konu bazlı dosyalar yaz. Dosya adlarını **bu reponun gerçek konularına** göre seç; aşağıdaki set bir başlangıç şablonudur, uymayanı yazma, eksik konu varsa ekle:

`MIMARI.md` (üst düzey resim + katman şeması) · `PRODUCT-SCOPE.md` · `TECHNOLOGY-STACK.md` · `DEPLOYMENT-AND-RUNTIME.md` · `CONFIGURATION-AND-SECRETS.md` · `DATA-PERSISTENCE-AND-DB.md` · `API-AND-UI.md` · `OBSERVABILITY-AND-OPERATIONS.md` · `TESTING-AND-SAFE-CHANGE.md`

Domain'e özel konular için ayrı dosya aç (mesajlaşma/event contract'ı, çekirdek durum makinesi, dış sistem entegrasyonu, iş akışı lifecycle'ı gibi).

Her dosyada:
- Mevcut davranışı yaz, hedef mimari vaadi yazma.
- Tablo ve sayı kullan; kaynak dosya adını ver.
- Sonunda **"Açık Sorular"** başlığı bırak.
- `README.md`'nin okuma sırası ve dosya listesini gerçek sete göre güncelle.

`docs/README.md` indeksine yeni dokümanlar için **yalnız yeni satır** ekle (append-only).

## 4. Geliştiriciye sor (kurulumun tek soru turu)

Şimdi `AskUserQuestion` ile sor. Kurallar:
- **Yalnız koddan çıkarılamayanları** sor. Sürüm, dosya sayısı, kanal adı gibi ölçülebilir şeyleri sorma — ölç.
- En çok **2 tur**, tur başına en çok 4 soru. Her soruya somut seçenekler ver, önerdiğin seçeneği başa koy ve "(Önerilen)" yaz.
- Kod veya git'ten türetilebilecek şeyi (uygulama adı, branch adı, kullanıcı adı) türet, sonra **teyit** ettir.

Sorulacak çekirdek konular:
1. **Doğrulama ortamı** — Bağımlılık deposuna (iç registry/mirror) erişim bu makinede var mı, olacak mı? Cevap doğrulama modelini belirler: komut çalıştırma mı, dosya/diff incelemesi mi.
2. **Araç yolları** — `.codex/TOOL-PATHS.local.properties` şimdi oluşturulsun mu; hangi stack bölümleri tutulsun? (Dosya commit'lenmez; ajan gerçek yolları oraya yazar, dokümana yazmaz.)
3. **KIMLIK konvansiyonu** — History ve plan dosya adlarında task id mi kullanılacak, developer username mi?
4. **Entegrasyon branch'i** — `gb-sync-develop-branch` hangi branch'i hedeflesin (varsayılan `origin/develop`)?
5. **Üretim gerçekleri** — Koddan çıkmayan ve riskli olan ne varsa: hedef runtime sürümü, migration aracı, üretim profili farkları, deployment topolojisi.
6. Kendi incelemende çıkan, cevabı yalnız ekipte olan sorular.

## 5. Cevapları uygula ve kapat

- Her cevabı **`AGENTS.md → PROJE → Proje Kuralları`** bölümüne tarihli ve bağlayıcı bir madde olarak yaz; cevaplanan madde "Açık Sorular"dan çıkar. Sorunun cevabı operasyonel bir ayrıntıysa (komut, yol, branch adı) ayrıntıyı ilgili bölüme yaz, "Proje Kuralları"nda yalnız kararı bırak — aynı şeyi iki yerde tekrarlama.
- Cevap koddaki gerçekle çelişiyorsa **koddaki gerçeği söyle**, sessizce cevabı uygulama.
- `.codex/TOOL-PATHS.local.properties` istendiyse oluştur (gerçek yollar yalnız bu dosyada; commit'lenmez).
- Kalan gerçek açık soruları `AGENTS.md → Açık Sorular` altında bırak.
- `gb-agent-history` ile `docs/history/YYYY-MM-DD.md`'ye append-only kayıt ekle; yeni gün açtıysan `docs/history/README.md` indeksine tek satır ekle.
- Kapanışta **5 maddelik özet** ver ve cevap bekleyen soruları tekrar listele.

## Yapılmayacaklar
- Kod davranışı değiştirme. Bu görev **dokümantasyon + config** işidir.
- Build dosyalarına dokunma (eksik gördüğün yapılandırma bilinçli bir karar olabilir — sor, ekleme).
- Bağımlılık indirmeye çalışma; eksik artifact'i adıyla raporla.
- Var olan dosyaları toptan yeniden üretme; indeks/history dosyalarında append-only kuralına uy.

'@

$Payload['.codex/skills/gb-agent-history/SKILL.md'] = @'
---
name: gb-agent-history
description: >
  Ajan kaynaklı dosya değişikliği olan işleri append-only history formatıyla kaydetme ve
  yalnız yeni gün açıldığında history indeksini güncelleme akışı. Soru-cevap, salt inceleme
  ve planlama gibi read-only işlerde KULLANILMAZ.
version: 1.0.0
tags: [history, hafıza, ortak]
---

# gb-agent-history

## Ne Zaman Kullanılır
- Çalışmayı yürüten ajan bu görev kapsamında repo dosyalarında **değişiklik yaptıysa** (kod, test, doküman, skill, config — ekleme/silme/güncelleme).

## Ne Zaman Kullanılmaz
- Soru-cevap, salt inceleme, planlama, brainstorming; `git log`/`rg`/dosya okuma gibi read-only işler.
- Çalışma ağacındaki değişiklikler ajanın bu görevdeki değişiklikleri değilse.

## Zorunlu Akış
1. Görev bitince ajan kaynaklı dosya değişikliği var mı kontrol et; **yoksa kayıt ekleme**.
2. Varsa günün `docs/history/YYYY-MM-DD.md` dosyasını oku, mevcut içeriği koru ve **sonuna** yeni kayıt ekle.
3. O güne ait dosya yoksa oluştur ve **yalnız bu durumda** `docs/history/README.md` indeksine yeni gün satırı ekle (mevcut satırları silme/sıralama/yeniden üretme yok).
4. Kayıtta zorunlu alanlar: `Kapsam`, `Değişiklikler`, `Doğrulama`.
5. Başlık: `### YYYY-MM-DD HH:mm:ss +03:00 | KIMLIK | slug` (KIMLIK = task id, yoksa username).
6. Mevcut meşru kayıtları silme/düzenleme/yeniden numaralandırma; düzeltme gerekiyorsa **yeni append-only düzeltme notu** ekle.

## Kayıt Şablonu
```md
### 2026-07-29 14:05:00 +03:00 | BS-1423 | dnc-expire-date-validation
- Kapsam: <modül/ekran/servis>
- Değişiklikler:
  - <madde 1>
- Doğrulama: <test komutu + sonucu / "çalıştırılmadı; nedeni">
```

## Kurallar
- Kısa, tekrar etmeyen yazım; yapılmayan işi yapılmış gibi yazma.
- Doğrulama çalıştırılmadıysa açıkça `Doğrulama: çalıştırılmadı` yaz.
- README/index dosyaları da append-only'dir; eski satır silen diff görürsen **dur ve overwrite riski olarak raporla**.
- Merge/rebase conflict'inde tek taraflı `ours/theirs` history seçimi yapma; iki taraftaki meşru kayıtları koru.

## Done Kriteri
- Değişiklik varsa günün dosyasında yeni append-only kayıt var; yoksa history değişmemiş.
- İndeks diff'i yalnız yeni satır ekliyor.
- Kayıt, aynı işin tekrar değerlendirilmesini önleyecek kadar net bağlam içeriyor.

'@

$Payload['.codex/skills/gb-characterization-tests/SKILL.md'] = @'
---
name: gb-characterization-tests
description: >
  Belirsiz veya kırılgan mevcut (legacy) davranışı riskli değişikliklerden ÖNCE testle
  kilitleme akışı. Çalışmayı yürüten ajan davranışı tam bilinmeyen koda dokunacaksa,
  refactor/fix öncesi bugünkü davranışı değiştirmeden kayıt altına almak için kullan.
version: 1.0.0
tags: [test, legacy, ortak]
---

# gb-characterization-tests

## Akış
1. Aynı package/modül veya davranış için yakındaki mevcut testleri bul.
2. Önce mevcut davranışı **değiştirmeden** testle kilitle (test, bugünkü gerçeği belgeler — "doğru" davranışı değil).
3. Mümkün olan en sade test araçlarını kullan (projenin standart birim test çatısı + mock kütüphanesi).
4. Controller/context davranışı test ediliyorsa projenin entegrasyon-test desteğini kullan.
5. Static/private construction daha basit test boundary'sini engelliyorsa özel mock araçlarını **son çare** olarak kullan; yeni kodda bu ihtiyacı büyütme.
6. Testleri deterministik tut: gerçek DB, kuyruk, cache, harici API veya ağ çağrısı yapma.
7. Hedefli komutla çalıştır (tek sınıf/tek spec).

## Stil
- Test adını implementation detayına göre değil, **davranışa** göre ver.
- Fixture'larda yalnız ilgili branch için gereken alanları set et.
- `sleep` kullanma; clock/executor üzerinden kontrol edilebilir boundary ekle.
- Legacy private state için yalnız testte reflection kullanmak, üretim API'sini test için genişletmekten iyidir.

## Öncelikli Alanlar
`AGENTS.md → PROJE → Yüksek-Riskli Alanlar` listesi bu skill'in hedef listesidir: oraya dokunan her değişiklikten önce karakterizasyon testi düşün.

'@

$Payload['.codex/skills/gb-commit-discipline/SKILL.md'] = @'
---
name: gb-commit-discipline
description: >
  Commit hazırlığı ve değişiklik hijyeni akışı. Diff kontrolü, ilgisiz değişiklik ayırma,
  secret/IP sızıntı kontrolü, README/index/history append-only kontrolü, test sonucu
  raporlama ve tip etiketli Türkçe commit mesajı hazırlığı gerektiğinde kullan.
version: 1.0.0
tags: [commit, hijyen, ortak]
---

# gb-commit-discipline

## Amaç
Commit yalnızca ilişkili ve doğrulanmış değişiklikleri içermelidir. Bu skill commit atmadan önce çalışma ağacını temiz anlamaya ve riskleri görünür yapmaya yarar.

## Akış
1. `git status --short` ile değişen dosyaları listele.
2. Her dosyanın bu işle ilişkisini kontrol et; **ilgisiz kullanıcı değişikliklerine dokunma** ve commit kapsamına alma.
3. `git diff` ile davranış, config, secret ve format-dışı değişiklikleri incele.
4. README/index/history dosyalarında append-only dışı satır silme, toplu yeniden yazım veya yeniden sıralama var mı kontrol et.
5. Test çıktısını (veya çalıştırılamadıysa nedenini) kaydet.
6. Commit mesajını tip etiketiyle, Türkçe ve açıklayıcı öner:

```text
<tip>: <Türkçe kısa ve özgül başlık>

- Yapılan ana değişiklik
- Test/doğrulama
- Risk veya migration notu
```

## Commit Mesajı Standardı
- Başlık `<tip>: <başlık>` formatında; tip İngilizce Conventional Commit türü (`feat fix docs test refactor chore build ci perf revert`), başlık/gövde Türkçe.
- Scope yalnız anlam katıyorsa: `fix(ami): ...`.
- Başlık emir kipinde ve özgül; `fix`, `update`, `düzenleme` gibi belirsiz başlık önerme.

## Kontrol Listesi
- Secret, gerçek IP, şifre, token veya credential eklendi mi?
- Local çalışma dosyaları (`TOOL-PATHS.local`, `settings.local.json`) yanlışlıkla izleniyor mu?
- History/README/index diff'leri append-only mi?
- Kod değiştiyse TDD veya karakterizasyon testi var mı? Planlı akışta açık soru bloklaması uygulandı mı?
- Yeni skill eklendiyse `AGENTS.md` envanteri güncellendi mi?

## Yapılmayacaklar
- Kullanıcı açıkça istemedikçe commit atma.
- İlgisiz dosyaları staging'e alma.
- Başarısız/çalıştırılmamış testi başarılı gibi yazma.
- README/index/history'de onaysız eski satır silme, yeniden sıralama veya komple dosya yeniden üretme.

'@

$Payload['.codex/skills/gb-dead-code-audit/SKILL.md'] = @'
---
name: gb-dead-code-audit
description: >
  Kullanılmayan kodu silmeden ÖNCE kanıta dayalı analiz akışı. DI config, reflection,
  mapping, template, bundler, route, mesaj kanalı veya event kayıtları nedeniyle statik
  aramanın yetersiz kalabileceği durumlarda kullan. Kanıt yoksa silme yapılmaz.
version: 1.0.0
tags: [dead-code, audit, ortak]
---

# gb-dead-code-audit

## Ana İlke
Bu skill kod silmek için değil, **silmenin güvenli olup olmadığını kanıtlamak** için kullanılır. Kanıt yoksa silme yapılmaz.

## Akış
1. Silinmesi düşünülen sınıf/metot/endpoint/DTO/property/asset'i netleştir.
2. **Statik** kullanım ara: `rg`, import, bean/component adı, endpoint path'i, string referansı, test referansı.
3. **Dinamik** kullanım ara: DI config (XML/anotasyon/component-scan), reflection, mapper (ör. Dozer/ORM mapping), template'ler (JSP/HTML), frontend route'ları, bundler manifestleri, mesaj kanalı/event kayıtları.
4. **Üretim contract'ı** var mı kontrol et: REST API, mesaj payload'ı, DB kolonu, result code, harici sistem callback'i (`AGENTS.md → PROJE → Domain Contract'ları`).
5. Kullanım bulunamadıysa hedefli test veya smoke doğrulama planı yaz.
6. Silme yapılacaksa **ayrı patch, ayrı commit** olarak yap.
7. Silme sonrası hedefli testleri çalıştır; diff'i özellikle config/contract açısından incele.

## Korumalı Alanlar
`PROJE → Domain Contract'ları` listesi + entity/DTO/mapper sınıfları + DI config bean adları ve property placeholder'ları + bundler/asset listeleri + profile/property dosyaları.

## Çıktı Formatı
- İncelenen aday · bulunan referanslar · dinamik kullanım riski · öneri (**güvenli / riskli / silme**) · gerekli test/doğrulama.

'@

$Payload['.codex/skills/gb-no-workaround-root-cause/SKILL.md'] = @'
---
name: gb-no-workaround-root-cause
description: >
  Bug fix, runtime hata, data/contract drift, sayaç uyuşmazlığı veya UI/backend validation
  ayrışmasında case-specific patch yerine root-cause-first, contract seviyesinde kalıcı çözüm
  uygulama akışı. Tekil semptom yamama, silent fallback veya hack riski varsa kullan.
version: 1.0.0
tags: [root-cause, bugfix, ortak]
---

# gb-no-workaround-root-cause

## Amaç
Tekil semptomu yamamak yerine **semptomu üreten sistemik kusuru** kapatmak; aynı bug class'ının başka varyantlarda tekrarını engellemek.

## Yasak Pattern'ler
- Tek input varyantı için lokal `if/else` ile semptomu susturmak.
- `if (x == null) return`, sessiz default, `catch (Exception e) {}` benzeri **silent fallback**.
- Kaynağı düzeltmeden yalnız UI, yalnız controller veya yalnız prompt/tool seviyesinde patch.
- Sayaç drift'ini gerçek owner'ı bulmadan ek increment/decrement ile kozmetik kapatmak.
- Tek kayıt/tek state/tek payload shape için özel-case yazmak.
- Testi yeşil yapmak için geçici patch, skip veya daraltılmış assertion.

## Root Cause Akışı
1. **Semptomu yaz:** hata mesajı, bozuk state, yanlış sayaç veya kırık akış ne?
2. **Owner boundary'yi bul:** validation, mapping, persistence, event parsing, runtime state veya UI — hangi katman authoritative?
3. **Writer/reader zincirini çıkar:** bu state'i kim üretiyor, kim dönüştürüyor, kim tüketiyor?
4. **Tekrar yüzeyini ara:** aynı kusur benzer controller/event/DTO/counter/akışta nerede tekrar eder?
5. **Kalıcı çözümü owner boundary'de uygula:** contract, validation, parser, mapper veya state owner düzeyinde.
6. Çözümün hangi contract'ı netleştirdiğini yaz.
7. **Regression testiyle** aynı bug class'ını kilitle.

## Fail-Closed Yorumu
Beklenmeyen durum sessizce tolere edilmez; ama fail-closed tüm sistemi kör durdurmak değildir: bozuk input/event/contract-dışı state **explicit reject** edilir veya kontrollü exception ile görünür kılınır; etkilenen birim (request/record/işlem) kirli state üretmeden durdurulur; shared runtime state sessizce bozulmaz.

## İlkeler
- Frontend validation yardımcı katmandır; authoritative kural backend/uygun contract owner'ında kapanır.
- Mesaj/event normalize edilecekse boundary parser/adapter katmanında yapılır; downstream consumer'lara dağıtılmaz.
- Sayaç/durum sorununda önce authoritative source belirlenir; mümkünse türetilmiş değer tercih edilir.
- Bug birden fazla alana dokunuyorsa ilgili proje domain skill'iyle birlikte kullan.

## Done Kriteri
- Workaround/silent fallback yok · root cause owner boundary'de kapalı · benzer bug class taranmış · contract netleşmiş · regression/karakterizasyon testi eklenmiş.

## Yararlı Arama Kalıpları
- `rg -n "catch \(Exception|return null|default|fallback" <src-kök>`
- `rg -n "increment|decrement|counter" <src-kök>`
- `rg -n "publish|subscribe|channel|event" <src-kök>`

'@

$Payload['.codex/skills/gb-safe-change/SKILL.md'] = @'
---
name: gb-safe-change
description: >
  Üretimde çalışan davranışı bozmadan küçük ve doğrulanabilir değişiklik yapma akışı.
  Çalışmayı yürüten ajan canlı bir sistemde hata düzeltirken veya dar kapsamlı özellik
  geliştirirken kritik akışları (contract, lifecycle, runtime state) kırmamalıysa kullan.
version: 1.0.0
tags: [safe-change, legacy, ortak]
---

# gb-safe-change

## Akış
1. İstenen değişikliğin **en küçük davranış yüzeyini** belirle.
2. Kod yazmadan önce mevcut akışı oku: caller'lar, event writer'ları, async worker'lar, persistence ve yan etkiler.
3. Hedef alanın `AGENTS.md → PROJE → Yüksek-Riskli Alanlar` listesindeki kırılgan runtime state'e dokunup dokunmadığını kontrol et.
4. Davranış kırılgan veya belirsizse önce karakterizasyon testi yaz (`gb-characterization-tests`).
5. Değişikliği küçük tut. Cleanup, biçimlendirme ve davranış değişikliğini aynı patch'te karıştırma.
6. En dar anlamlı test komutuyla doğrula; araç yoksa bunu açıkça belirt.
7. Sonuçta üretim riski, değişen davranış ve kalan doğrulama boşluklarını yaz.

## Kurallar
- `AGENTS.md → PROJE → Domain Contract'ları` listesindeki adlar/şemalar (channel, event, result code, state transition, property adları…) geçiş notu olmadan değişmez.
- Yeni static mutable state ekleme.
- Legacy kodda yeni kütüphane ekleme; önce mevcut bağımlılıklar, standart kütüphane ve küçük local adapter/pure function boundary'leri.
- Yeni kütüphane/artifact zorunluysa kod yazmadan **önce** geliştiriciye gerekçesiyle bildir (offline/VPN kısıtı olabilir).
- Counter/increment mantığını başka truth source ile değiştiriyorsan migration ve reconciliation yolunu açıkça yaz.
- Geniş yeniden yazım yerine adapter, test edilebilir boundary ve küçük davranış değişikliği tercih et.
- Projenin dil/derleyici hedef sürümünü koru (PROJE bölümünde belirtilir).

## Yararlı Arama Kalıpları
- `rg -n "increment|decrement|counter|activeC|state" <src-kök>` — runtime state yüzeyi
- `rg -n "publish|subscribe|channel|event" <src-kök>` — mesajlaşma contract yüzeyi
- (Projeye özel kalıplar ilgili domain skill'ine yazılır.)

'@

$Payload['.codex/skills/gb-safe-refactor/SKILL.md'] = @'
---
name: gb-safe-refactor
description: >
  Davranış değiştirmeden, test koruması altında küçük ve güvenli refactor yapma akışı.
  Çalışmayı yürüten ajan isim düzeltme, metot çıkarma, dependency boundary veya tekrar
  azaltma gibi mekanik düzenlemeler yapacaksa kullan. Davranış değişecekse bu skill değil
  gb-tdd-workflow kullanılır.
version: 1.0.0
tags: [refactor, ortak]
---

# gb-safe-refactor

## Ön Koşul
Refactor, davranış değişikliği **değildir**. Davranış değişecekse önce `gb-tdd-workflow` ve gerekirse `gb-characterization-tests` kullan.

## Akış
1. Refactor hedefini tek cümleyle yaz: isim düzeltme, metot çıkarma, dependency boundary, tekrar azaltma, package içi düzenleme.
2. Etkilenen davranışı koruyan hedefli testleri bul.
3. Test yoksa küçük bir karakterizasyon testi ekle.
4. Refactor **öncesi** hedefli testi çalıştır.
5. En küçük mekanik değişikliği yap.
6. Aynı hedefli testi **tekrar** çalıştır.
7. Diff'i kontrol et: davranış, config ve `PROJE → Domain Contract'ları` (channel/event/schema/endpoint) değişmediğini doğrula.

## Riskler
- DI/config dosyaları (XML/anotasyon), bundler manifestleri, template'ler, mapping/reflection kullanımı **statik referansları gizleyebilir** — bean/component adı, property adı ve endpoint path'i refactor sırasında kırılabilir.
- Test yoksa "sadece isim değişikliği" bile riskli kabul edilir.

## Yapılmayacaklar
- Refactor patch'inde dead code silme (onun için `gb-dead-code-audit`).
- Refactor patch'inde davranış düzeltme.
- Refactor patch'inde bağımlılık yükseltme.
- Refactor patch'inde secret veya ortam dosyası düzenleme.

'@

$Payload['.codex/skills/gb-sync-agentic-baseline/SKILL.md'] = @'
---
name: gb-sync-agentic-baseline
description: >
  Merkezî agentic-baseline reposunun yeni sürümünü bu repoya güvenli uygulama akışı.
  AGENTS.md'nin Katman 1 (Ortak Taban) bloğunu, köprüleri, izin baseline'ını ve gb-*
  skill'lerini günceller; PROJE bölümüne ve proje skill'lerine ASLA dokunmaz.
version: 1.0.0
tags: [baseline, sync, governance, ortak]
---

# gb-sync-agentic-baseline

## Ne Zaman Kullanılır
- Agentik Bülten'de yeni baseline sürümü duyurulduğunda veya `AGENTS.md` başındaki `ortak-taban: vX.Y.Z` etiketi merkezî `CHANGELOG.md`'nin gerisindeyse.

## Kapsam Sınırı (kritik)
Bu skill **yalnız** şunları güncelleyebilir: `AGENTS.md` Katman 1 bloğu (PROJE başlığına kadar), `CLAUDE.md`/`GEMINI.md`/Copilot/Cursor köprüleri, `.claude/settings.json` içindeki **yalnız `deny` listesi**, `.codex/TOOL-PATHS.example.properties`, `.mcp.json.example`, `.codex/skills/gb-*` klasörleri, `docs/` iskelet README'lerinin **şablon bölümleri**.
**Dokunulmaz:** `AGENTS.md → # PROJE` bölümü, `<app>-*` proje skill'leri, `docs/` içindeki gerçek kayıtlar (history/ADR/analiz/planlar), local dosyalar, `.claude/settings.json` içindeki **`allow` listesi**.

> `deny` listesi ortak tabana aittir (yıkıcı komut ve secret dosyası yasakları); `allow` listesi **projeye** aittir çünkü stack'e özgü derleme/test komutlarını taşır. Sync yalnız eksik `deny` satırlarını ekler, `allow` listesine hiç dokunmaz. Makineye özgü izinler `.claude/settings.local.json` dosyasında tutulur (bu dosya commit'lenmez).

## Akış
1. Merkezî baseline'ın hedef sürümünü ve `CHANGELOG.md` farkını oku; bu repodaki `ortak-taban:` etiketiyle karşılaştır.
2. Değişecek dosyaların listesini ve her birinin diff özetini **rapor olarak sun**; geliştirici onayı iste.
3. Onaydan sonra: Katman 1 bloğunu yeni sürümle değiştir (PROJE bölümünü byte'ı byte'ına koru), köprü/izin/skill dosyalarını güncelle, `ortak-taban:` etiketini yeni sürüme çek.
4. Repo yerel olarak Katman 1'de sapma yaptıysa (yapmamalı) sapmayı **kaybetme**: farkı raporla ve PROJE bölümüne taşınmasını öner.
5. Doğrulama: `git diff` ile PROJE bölümünün ve proje skill'lerinin değişmediğini göster.
6. `gb-agent-history` ile append-only kayıt ekle: eski→yeni sürüm, güncellenen dosyalar.
7. Commit önerisini `chore: agentic-baseline vX.Y.Z güncellemesi` formatında hazırla (`gb-commit-discipline`).

## Done Kriteri
- `ortak-taban:` etiketi yeni sürümde · PROJE bölümü ve proje skill'leri değişmemiş · diff raporlanıp onaylanmış · history kaydı eklenmiş.

'@

$Payload['.codex/skills/gb-sync-develop-branch/SKILL.md'] = @'
---
name: gb-sync-develop-branch
description: >
  Local çalışma branch'ini remote entegrasyon branch'i (varsayılan origin/develop; proje
  farklıysa AGENTS.md → PROJE'de belirtilir) ile güvenli sync etme akışı. PR öncesi
  değişiklikleri almak, conflict riskini raporlamak ve onaylı merge yapmak için kullan.
version: 1.0.0
tags: [git, sync, ortak]
---

# gb-sync-develop-branch

## Temel Kurallar
- Entegrasyon branch'ine geçme, üzerinde commit atma veya push etme.
- Current branch üzerinde çalış; detached HEAD veya entegrasyon branch'indeysen dur.
- Working tree temiz değilse otomatik stash/commit/revert yapma; önce raporla.
- `git reset --hard`, `git push --force`, blanket `ours/theirs` ve onaysız conflict edit'i **yasak**.
- Merge öncesi geliştiriciye **sync raporu** sun; açık onay olmadan `git merge` çalıştırma.

## Akış
1. **Ön kontrol:** `git branch --show-current` · `git status --short` · `git remote -v`.
2. **Analiz:** `git fetch origin <branch>` → `git rev-list --left-right --count HEAD...origin/<branch>` (ahead/behind) → incoming/local commit listeleri (`git log --oneline`).
3. **Conflict riski:** merge-base'e göre iki tarafın değiştirdiği dosyaların kesişimini çıkar:
   `$mb = git merge-base HEAD origin/<branch>` → `git diff --name-only "$mb..HEAD"` ∩ `git diff --name-only "$mb..origin/<branch>"`.
4. **Rapor:** current branch, incoming/local commit sayıları, kesişen dosyalar, öneri (`git merge --no-ff origin/<branch>`), doğrulama planı. **Onay bekle.**
5. **Merge:** onaydan sonra `git merge --no-ff origin/<branch>`. Conflict yoksa merge commit hash'i + doğrulamayı raporla.
6. **Conflict varsa:** `git diff --name-only --diff-filter=U` ile listele, dosya bazlı çözüm planı sun, **onaydan sonra** minimal çözüm yap, stage et, merge commit'i tamamla.

## Conflict Çözüm İlkeleri
- İki tarafı da kapsayan **en dar** çözümü uygula; blanket `ours/theirs` kullanma (tek dosyada açıkça gerekiyorsa nedenini raporla + onay al).
- Contract/riskli alan dosyalarında ilgili proje domain skill'ini birlikte kullan.
- Çözüm davranışı etkiliyorsa hedefli test çalıştır; docs-only conflict'te `git diff --check` yeterli.

## Kapanış
- `git status --short` ile son durumu raporla; çalıştırılan doğrulamaları ve çalıştırılmayanların nedenini yaz.
- Anlamlı sync/çözüm yapıldıysa `gb-agent-history` ile append-only kayıt ekle.

'@

$Payload['.codex/skills/gb-tdd-workflow/SKILL.md'] = @'
---
name: gb-tdd-workflow
description: >
  Her hata düzeltmesi ve özellik geliştirmesini TDD ile yürütme akışı. Çalışmayı
  yürüten ajan kod davranışı değiştirecekse kullan: önce başarısız test, sonra en
  küçük üretim kodu, sonra güvenli refactor. Legacy/belirsiz davranışta önce
  karakterizasyon testi gerekir.
version: 1.0.0
tags: [tdd, test, ortak]
---

# gb-tdd-workflow

## Temel Kural
Her geliştirme testle başlar. Legacy davranış belirsizse önce `gb-characterization-tests` ile bugünkü davranış kilitlenir; istenen yeni davranış için başarısız test eklenir; sonra yalnızca testi geçirecek kadar üretim kodu değiştirilir.

## Analiz ve Plan Ön Koşulu
`AGENTS.md → Planlama ve Açık Soru Kapısı` bölümündeki akış uygulanır: dert çerçevelenir → "Plan aşamasına geçeyim mi?" sorulur (plan türü + plansız seçenek + ajanın önerisi) → onaysız plan dosyası açılmaz → Açık Sorular cevaplanmadan kod değiştirilmez. Kurallar burada tekrarlanmaz; kaynak `AGENTS.md`'dir.

## Red-Green-Refactor Akışı
1. Değişecek davranışı tek cümleyle yaz.
2. En yakın test dosyasını bul; yoksa test standardına göre yenisini aç.
3. Mevcut davranış riskliyse önce karakterizasyon testiyle kilitle.
4. İstenen davranış için **başarısız** test yaz.
5. Yalnızca testi geçirecek kadar üretim kodu değiştir.
6. Hedefli testi çalıştır (komutlar `AGENTS.md → PROJE → Doğrulama Komutları`'nda; araç yolları `.codex/TOOL-PATHS.local.properties`'ten).
7. Yeşil olduktan sonra yalnız küçük ve güvenli refactor yap; aynı hedefli testi tekrar çalıştır.

## Test Dosyası Standardı
- Yeni testler projenin mevcut test düzenine uyar; düzen `AGENTS.md → PROJE`'de belirtilir. Düzen belirsizse en yakın mevcut test dosyasının bulunduğu yapı örnek alınır, yeni bir kök icat edilmez.
- Test sınıfı adı: `<Konu><Davranış><TestTipi>Test` — test tipi örnekleri: `Characterization`, `Regression`, `Contract`, `Feature`.
- Mevcut test sınıfı doğrudan ilgiliyse aynı dosya genişletilebilir.

## Yerel Tool Path Ön Koşulu
- Test/derleme gerektiren doğrulamadan önce `.codex/TOOL-PATHS.local.properties` okunur; oradaki binary/settings/repo yolları kullanılır.
- Paket yöneticisi komutları varsayılan **offline** çalıştırılır; ajan dependency indirmeyi denemez. Eksik artifact adıyla raporlanır; geliştirici cache'i güncelledikten sonra aynı komut tekrar denenir.
- Local dosya yoksa PATH kullanılır; araç bulunamazsa bu doğrulama sonucu olarak açıkça raporlanır.

## İstisnalar
- Testlerde gerçek dış sistem bağlantısı kurma (DB, mesaj kuyruğu, harici API…); deterministik boundary kullan.
- Async/race davranışında `sleep` ile test yazma; executor, clock veya callback kontrol noktası kullan.
- Üretim hatası acilse bile en azından regression test eklemeden davranış değiştirme.
- Test yazılamıyorsa nedenini açıkça belirt ve en yakın doğrulama yöntemini uygula.

## Final Çıktı
- Yazılan başarısız test · yapılan üretim kodu değişikliği · kısa **Test Özeti** (komutlar + durumlar) · çalıştırılamayan test varsa nedeni · plan durumu (işaretlenen adımlar, açık soru, kapanış).

'@

$Payload['.codex/TOOL-PATHS.example.properties'] = @'
# Bu dosyayı kopyalayıp `.codex/TOOL-PATHS.local.properties` olarak doldur.
# `.local.properties` geliştiriciye özeldir, GERÇEK yolları içerebilir ve COMMIT'LENMEZ.
# Şablonda ve dokümanlarda yalnız yer tutucu kullanılır. Windows yollarında ileri slash tercih et.
# Kullanılmayan stack bölümünü silebilirsin.

# ---- Java / Maven stack (kullanılıyorsa) ----
MAVEN_CMD=C:/araclar/apache-maven-X.Y.Z/bin/mvn.cmd
MAVEN_SETTINGS=C:/Users/<KULLANICI>/.m2/settings.xml
MAVEN_REPO_LOCAL=C:/Users/<KULLANICI>/.m2/repository
# Ajan Maven'ı daima -o (offline) çalıştırır; eksik artifact'i raporlar, indirmeyi denemez.
MAVEN_OFFLINE=true
JAVA_HOME=C:/araclar/jdk-<SURUM>
# Opsiyonel Tomcat:
CATALINA_HOME=
TOMCAT_BASE=

# ---- Node stack (kullanılıyorsa) ----
NPM_CMD=C:/Program Files/nodejs/npm.cmd

# ---- Go stack (kullanılıyorsa) ----
GO_CMD=C:/Program Files/Go/bin/go.exe

# KURAL: Bu dosyaya şifre, token, gerçek müşteri bilgisi veya ortam credential'ı YAZILMAZ.

'@

$Payload['.cursor/rules/00-agents.mdc'] = @'
---
description: Global Bilgi agentik çalışma sözleşmesi — tek kaynak AGENTS.md
alwaysApply: true
---

Bu repoda birincil ve TEK kural kaynağı: kök `AGENTS.md`. Kod önermeden/değiştirmeden
önce `AGENTS.md`'yi uygula; çakışmada `AGENTS.md` kazanır. Skill iş akışları
`.codex/skills/<ad>/SKILL.md` altındadır. Üretim davranışını testsiz bozma, TDD ile
ilerle, secret/credential yazma. Metinlerde `Codex` = "çalışmayı yürüten ajan".
Ayrıntılı kurallar AGENTS.md'de — burada tekrarlanmaz.

'@

$Payload['.github/copilot-instructions.md'] = @'
# GitHub Copilot Köprüsü

Bu repoda birincil ve **TEK** kural kaynağı: kök `AGENTS.md`.

- Kod önermeden/değiştirmeden önce `AGENTS.md`'deki çalışma sözleşmesini uygula; çakışmada `AGENTS.md` kazanır.
- Skill iş akışları: `.codex/skills/<ad>/SKILL.md`.
- Üretim davranışını testsiz bozma; TDD ile ilerle; secret/credential yazma.
- Metinlerde `Codex` = "çalışmayı yürüten ajan".

> Ayrıntılı kurallar `AGENTS.md`'de — burada tekrarlanmaz.

'@

$Payload['.gitignore.append'] = @'
.codex/TOOL-PATHS.local.properties
.claude/settings.local.json

'@

$Payload['.mcp.json.example'] = @'
{
  "//": "Kopyala: .mcp.json — YALNIZ onaylı MCP kayıt defterindeki sunucular eklenir.",
  "//kural": "Varsayılan salt-okunur/izin-listeli. Credential düz yazılmaz; env/secret yönetimi kullanılır.",
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "."]
    },
    "ic-sistem-ORNEK": {
      "command": "node",
      "args": ["./mcp/ic-sistem-mcp/index.js"],
      "env": {
        "API_URL": "https://ic-sistem.example.local",
        "MODE": "read-only"
      }
    }
  }
}

'@

$Payload['AGENTS.md'] = @'
<!-- ortak-taban: v1.0.1
     Bu bloğu elle düzenlemeyin; `gb-sync-agentic-baseline` skill'i ile güncellenir.
     Projeye özel her şey en alttaki "# PROJE" bölümüne yazılır. -->

# <UYGULAMA> Agent Rehberi

## Ajan Kapsamı (ortak)
- Bu rehber Codex, Claude, Gemini ve repoda çalışan diğer tüm ajanlar için **ortak çalışma sözleşmesidir**.
- Metinlerde `Codex` geçen operasyonel kural, köprü üzerinden çalışan Claude/Gemini için de **"çalışmayı yürüten ajan"** demektir. Hiçbir ajan `Codex` ifadesini kendini hariç tutma olarak yorumlamaz.
- Çakışma hâlinde öncelik: bu `AGENTS.md` > araç köprüsü (`CLAUDE.md` / `GEMINI.md` / Copilot / Cursor).

## Dil Standardı (ortak)
- `AGENTS.md`, `docs/**/*.md` ve `.codex/skills/**/SKILL.md` Türkçe yazılır; Türkçe karakterler doğru kullanılır.
- Yerleşik teknik jargon İngilizce kalır (contract, event, lifecycle, queue, migration, refactor…); Türkçe ek alabilir (`contract'ı`, `event'i`).
- Harf içeren Markdown dosya adları büyük harfli-tireli yazılır: `GO-MICROSERVICE-ROADMAP.md`.
- Tarih bazlı dosyalar **ISO** formatındadır: `YYYY-MM-DD.md`.

## Çalışma Kuralları (ortak)
- **Üretim davranışını testsiz bozma.** Repo canlı bir sistem gibi ele alınır.
- Geniş refactor ile hata düzeltmesini aynı değişiklikte karıştırma.
- Her kod değişikliği **TDD** ile ilerler: önce başarısız test → en küçük üretim kodu → güvenli refactor (`gb-tdd-workflow`).
- Belirsiz/kırılgan legacy davranışı önce **karakterizasyon testiyle** kilitle (`gb-characterization-tests`).
- Yeni dosyalara **secret / gerçek IP / şifre / token / müşteri bilgisi** yazma → yer tutucu kullan.
- Çalışma ağacı kirli olabilir; **ilgisiz yerel değişiklikleri geri alma**.
- Yeni kütüphane/artifact gerçekten zorunluysa **önce geliştiriciye bildir** (offline/VPN/depo kısıtları olabilir).
- Yıkıcı komut (`rm -rf`, `git push --force`, `git reset --hard`, kitlesel silme) çalıştırma — gerekiyorsa **sor**.
- Yeni static mutable state ekleme; increment/decrement counter'ı tek gerçek kaynak gibi kullanma — authoritative state'ten türetilebiliyorsa türetilmiş değeri tercih et.

## Planlama ve Açık Soru Kapısı (ortak)
- Kod değişikliği gerektiren her istekte ajan önce derdi kendi tespit/risk/çözüm önerisiyle kısaca çerçeveler.
- Sorun ve çözüm yönü netleşince açıkça sorar: **"Plan aşamasına geçeyim mi?"** — yeni özellik → `new feature planı` (`docs/analyse/` + `docs/execution-plan/`); fix/hotfix/refactor/perf/diğer → `change-fix planı` (`docs/change-fix-plan/`). Plansız doğrudan çözüm seçeneği de aynı mesajda belirtilir.
- Üretim, lifecycle, persistence veya contract riski varsa **varsayılan öneri planlı ilerlemektir**.
- Kullanıcı onaylamadan plan dosyası açılmaz; plansız seçildiyse plan dosyası açılmaz.
- Plan dosyalarında şu bölümler zorunludur: bağlam, mevcut davranış, beklenen davranış, etkilenen kod alanları, riskler, TDD stratejisi, uygulama kontrol listesi, hedefli doğrulama komutları, kapanış kriteri, **Açık Sorular**.
- **Açık Sorular** bölümünde cevaplanmamış madde varken kod/test/config değişikliğine geçilmez; ajan soruları kendiliğinden sorar.
- Dosya adlandırma: `ETIKET-KIMLIK-KISA-AD.md` — etiket büyük harf (`FIX-BS-1423-...`), `KIMLIK` = task id, yoksa developer username. Tarih klasörü ISO: `docs/change-fix-plan/YYYY-MM-DD/`.
- Commit etiketleri: `feat · fix · docs · test · refactor · chore · build · ci · perf · revert`.

## History Disiplini (ortak — append-only)
- History kaydı yalnızca **ajan kaynaklı dosya değişikliği** olduğunda eklenir; soru-cevap/salt inceleme/planlamada eklenmez (`gb-agent-history`).
- Kayıt `docs/history/YYYY-MM-DD.md` dosyasının **sonuna** eklenir. Eski kayıt **asla** silinmez, düzenlenmez, yeniden numaralandırılmaz.
- Başlık: `### YYYY-MM-DD HH:mm:ss +03:00 | KIMLIK | slug` — zorunlu alanlar: `Kapsam`, `Değişiklikler`, `Doğrulama`.
- Yeni gün açıldığında yalnız o gün `docs/history/README.md` indeksine satır eklenir (indeksler de append-only).
- Merge conflict'te tek taraflı `ours/theirs` history çözümü yapılmaz; iki taraftaki meşru kayıtlar korunur. Overwrite riski görülürse işlem durdurulur ve raporlanır.
- **Kod yazmadan önce ilgili history + mimari doküman + ADR kayıtları okunur.**

## Hafıza Modeli (ortak)
- `docs/history/` → **ne oldu** (günlük, append-only worklog)
- `docs/architecture/` → **ne var** (mevcut kodun ve güvenli boundary'lerin kaydı; hedef değil). Kod davranışı mimariyi etkiliyorsa **aynı işte** güncellenir.
- `docs/decisions/` → **neden böyle** (ADR — karar, alternatifler, gerekçe; ekle-değişmez)
- `docs/project/` → **nereye** (roadmap dosyaları)

## Doğrulama Felsefesi (ortak)
- Doğrulama komutu işin türüne göre seçilir. Soru-cevap / salt inceleme / planlama / dokümantasyon-only işlerde test çalıştırılmaz; dosya/diff kontrolü yeterlidir.
- Kod davranışı değiştiğinde **yalnız etkilenen kapsamın hedefli testleri** çalıştırılır; tam suite yalnız geniş risk, ortak sözleşme değişikliği veya geliştirici isteğiyle.
- Her çalışma sonunda kısa **"Test Özeti"** raporlanır: çalıştırılan komutlar + sonuçlar; çalıştırılmadıysa nedeni (`Test çalıştırılmadı; kod davranışı değişmedi.`).
- Araç yolları ve offline ayarları `.codex/TOOL-PATHS.local.properties` dosyasından okunur; ajan dependency indirmeyi denemez, eksik artifact'i raporlar.

## Skill Kullanımı (ortak)
- Skill kütüphanesi: `.codex/skills/<ad>/SKILL.md`. Görev uyduğunda ilgili skill okunur; **en dar gerekli set** kullanılır, gereksiz skill yüklenmez.
- **Ortak skill'ler** (`gb-*` — elle düzenlenmez, `gb-sync-agentic-baseline` ile güncellenir): `gb-tdd-workflow`, `gb-safe-change`, `gb-safe-refactor`, `gb-characterization-tests`, `gb-commit-discipline`, `gb-dead-code-audit`, `gb-no-workaround-root-cause`, `gb-agent-history`, `gb-sync-develop-branch`, `gb-sync-agentic-baseline`.
- **Proje skill'leri** (`<app>-*`) bu reponun PROJE bölümündeki envanterde listelenir. İhtiyaç doğdukça proje ekibi ekler.

## MCP Kullanımı (ortak)
- Ajanın dış sistem araçları `.mcp.json` ile tanımlanır; **yalnız onaylı MCP kayıt defterindeki** sunucular eklenir.
- MCP sunucuları varsayılan **salt-okunur/izin-listeli** başlar; yazma/işlem yapan uçlar insan onayı gerektirir.
- Credential'lar `.mcp.json` içine düz yazılmaz; env/secret yönetimi kullanılır.

<!-- ORTAK TABAN SONU — aşağısı projeye özeldir -->

# PROJE

<!-- Bu bölümü uygulama ekibi sahiplenir. Kısa ve ölçülebilir tut; ortak kurallar
     yukarıda. İlk doldurma `.codex/BOOTSTRAP-PROMPT.md` ile yapılır. -->

## Misyon
<Bu uygulama nedir, neden kritik, ajan neyi asla bozmamalı?>

## Proje Kuralları
<!-- Koddan çıkarılamayan, ekip tarafından onaylanmış ve bağlayıcı kararlar.
     Bir madde önce "Açık Sorular"da durur; cevaplanınca buraya taşınır (tarihiyle).
     Ortak kurallar burada TEKRARLANMAZ. Operasyonel ayrıntı ilgili bölümde kalır
     (ör. komutlar "Doğrulama Komutları"nda); burada yalnız karar kaydı durur. -->
- `<YYYY-MM-DD>` — <karar>

## Repo Haritası
- `<yol>`: <ne var>

## Teknoloji Yığını
- <backend / frontend / altyapı — sürümleriyle>

## Doğrulama Komutları
- Hedefli test: `<komut>`
- Derleme: `<komut>`

## Mimari Dokümanlar
- <docs/architecture/ altındaki dosyaların özeti + linki>

## Yüksek-Riskli Alanlar
- <dokunmadan önce okunacak sınıf/modül/akış>

## Domain Contract'ları (geçiş notu olmadan değişmez)
- <channel adları, event adları, API shape, state transition…>

## Proje Skill Envanteri
- <henüz yok — ihtiyaç doğdukça `.codex/skills/<app>-<ad>/SKILL.md` eklenir>

## Roadmap
- `docs/project/<...>-ROADMAP.md`

## Açık Sorular
- <koddan çıkarılamayan, geliştiriciden cevap bekleyen maddeler>

'@

$Payload['CLAUDE.md'] = @'
# Claude Agent Köprüsü

Bu repoda birincil ve **TEK** kural kaynağı: kök `AGENTS.md`.

1. Önce `AGENTS.md`'yi oku ve ana çalışma sözleşmesi olarak uygula. Çakışmada `AGENTS.md` kazanır.
2. Skill kütüphanesi: `.codex/skills/<ad>/SKILL.md`. Göreve uyan **en dar** seti kullan; ortak (`gb-*`) ve proje skill envanteri `AGENTS.md`'dedir.
3. Metinlerde `Codex` = "çalışmayı yürüten ajan"; kendini hariç tutma.
4. İzinler: `.claude/settings.json` · Araç yolları/offline: `.codex/TOOL-PATHS.local.properties`.

> Kurallar ve skill eşlemeleri burada TEKRARLANMAZ — hepsi `AGENTS.md`'de. Bu dosya yalnız yönlendirir.

'@

$Payload['docs/analyse/README.md'] = @'
# analyse — Yeni Feature Analizleri

Yeni feature işleri (`feat`) önce burada analiz edilir: `YYYY-MM-DD/FEAT-KIMLIK-KISA-AD.md`.
Analiz incelenip netleşmeden `execution-plan/` açılmaz. Bu indeks append-only'dir.

## Kayıtlar
<!-- yeni satırlar buraya eklenir -->

'@

$Payload['docs/architecture/README.md'] = @'
# Mevcut Mimari Dokümanları

Bu klasör uygulamanın mevcut mimarisini yaşayan kod tabanına göre özetler. Amaç yeni geliştiriciye sistemi hızlı anlatmak, ajanla yapılacak işleri güvenli boundary'lere oturtmak ve riskli değişiklikleri önceden görünür kılmaktır.

Bu dokümanlar hedef mimari belgesi değildir. Mevcut davranış koddan çıkarılır; eksik veya yanlış görünen noktalar bulunduğunda ilgili dosya **aynı iş içinde** güncellenir.

İlk set `.codex/BOOTSTRAP-PROMPT.md` ile üretilir.

## Okuma Sırası
<!-- Gerçek dosya setine göre doldurulur; numaralı sıra yeni geliştiricinin izleyeceği yoldur. -->

## Dosyalar
<!-- Her dosya için: `AD.md`: tek satır kapsam açıklaması -->

## Güncelleme Standardı

- Kodda mimari davranışı etkileyen her değişiklik ilgili dokümanı da günceller.
- Dokümanlar Türkçe karakterlerle ve TDK yazımına uygun yazılır.
- Gerçek IP, şifre, token, anahtar veya müşteri bilgisi dokümana yazılmaz; yer tutucu kullanılır.
- Davranış belirsizse dokümana kesin hüküm yazılmaz; **"Açık Sorular"** başlığı altında bırakılır.
- `AGENTS.md`'nin PROJE bölümü bu dokümanların **özetini + linkini** taşır; ayrıntı burada kalır, iki yerde tekrarlanmaz.
- Mevcut davranış yazılır, hedef design vaadi yazılmaz.

'@

$Payload['docs/change-fix-plan/README.md'] = @'
# change-fix-plan — Fix / Refactor / Diğer İş Planları

Fix, hotfix, change request, refactor, perf, test, build, ci, chore, revert ve feature-dışı işler için **tek dosyalı** (analiz + execution plan) planlar: `YYYY-MM-DD/ETIKET-KIMLIK-KISA-AD.md` (ör. `FIX-BS-1423-AKTIF-CAGRI-SAYACI-DRIFT.md`). Bu indeks append-only'dir.

## Kayıtlar
<!-- yeni satırlar buraya eklenir -->

'@

$Payload['docs/decisions/ADR-SABLON.md'] = @'
# ADR-NNNN · <Karar başlığı>

- **Durum:** Önerildi | Kabul | Yerini aldı (ADR-MMMM) | İptal
- **Tarih:** YYYY-MM-DD
- **Karar veren:** <kişi/komite> · **Kimlik:** <task id / username>

## Bağlam
<Hangi sorun/ihtiyaç bu kararı gerektirdi? Kısıtlar neler?>

## Değerlendirilen seçenekler
- **A)** <seçenek> — artı/eksi
- **B)** <seçenek> — artı/eksi

## Karar
<Ne karar verildi — net ve tek cümle.>

## Gerekçe
<Neden bu seçenek? Diğerleri neden elendi?>

## Sonuçlar
- <kazanım>
- <bedel / takas / gelecekte dikkat edilecek>

## Etkilenen alanlar
<Modüller/contract'lar/ekipler; ilgili mimari doküman ve roadmap linkleri.>

'@

$Payload['docs/decisions/README.md'] = @'
# decisions — ADR (Architecture Decision Records)

**"Neyi neden seçtik"** buraya yazılır; böylece aynı karar tekrar tartışılmaz, ajan geçmiş gerekçeyi okur. ADR'ler **ekle-değişmez**: karar değişirse yeni ADR yazılır ve eskisi "Yerini aldı (ADR-NNNN)" olarak işaretlenir.

- Dosya adı: `ADR-NNNN-kisa-ad.md` (sıralı numara). Şablon: `ADR-SABLON.md`.
- Kod yazmadan önce ilgili ADR'ler okunur (bkz. `AGENTS.md` → Hafıza Modeli).

## Kayıtlar
<!-- yeni satırlar buraya eklenir (append-only) -->

'@

$Payload['docs/execution-plan/README.md'] = @'
# execution-plan — Feature Uygulama Planları

Analizi netleşen feature işleri için checkbox'lı uygulama planları: `YYYY-MM-DD/FEAT-KIMLIK-KISA-AD.md`.
Plan onaylanmadan uygulama başlamaz; tamamlanan adımlar planda işaretlenir. Bu indeks append-only'dir.

## Kayıtlar
<!-- yeni satırlar buraya eklenir -->

'@

$Payload['docs/history/README.md'] = @'
# history — Günlük İşlem Kaydı İndeksi

Ajan kaynaklı dosya değişikliği olan işler `YYYY-MM-DD.md` dosyalarına **append-only** kaydedilir (bkz. `gb-agent-history` skill'i). Bu indeks de append-only'dir: yalnız yeni gün satırı eklenir.

## Kayıt standardı (minimal)
```md
### YYYY-MM-DD HH:mm:ss +03:00 | KIMLIK | slug
- Kapsam: <modül/ekran/servis>
- Değişiklikler:
  - <madde>
- Doğrulama: <test komutu + sonuç / "çalıştırılmadı; nedeni">
```

## Günler
<!-- yeni gün satırları buraya eklenir -->

'@

$Payload['docs/project/README.md'] = @'
# project — Roadmap ve Dönüşüm Planları

Proje planları ve roadmap dosyaları burada tutulur (`<KONU>-ROADMAP.md`). Skill dosyaları roadmap saklamaz; skill'ler yalnız güvenli çalışma tekniğini tarif eder. Bu indeks append-only'dir.

## Kayıtlar
<!-- yeni satırlar buraya eklenir -->

'@

$Payload['docs/README.md'] = @'
# docs — Doküman Üst İndeksi

Bu indeks **append-only**dir: yeni doküman eklendiğinde yalnız yeni satır eklenir; mevcut satırlar silinmez, yeniden sıralanmaz, dosya baştan üretilmez.

## Klasörler
- `architecture/` — mevcut ürün mimarisi ve güvenli boundary'ler (**ne var**)
- `decisions/` — ADR karar kayıtları (**neden böyle**)
- `history/` — ajan işlerinin günlük geçmişi, append-only (**ne oldu**)
- `project/` — roadmap ve dönüşüm planları (**nereye**)
- `analyse/` — yeni feature analizleri (gün bazlı, ISO klasör: `YYYY-MM-DD/`)
- `execution-plan/` — feature uygulama planları (gün bazlı)
- `change-fix-plan/` — fix/refactor/perf ve feature-dışı işler için tek dosyalı planlar (gün bazlı)

## Dokümanlar
<!-- yeni satırlar buraya eklenir -->

'@

$Payload['GEMINI.md'] = @'
# Gemini Agent Köprüsü

Bu repoda birincil ve **TEK** kural kaynağı: kök `AGENTS.md`.

1. Önce `AGENTS.md`'yi oku ve ana çalışma sözleşmesi olarak uygula. Çakışmada `AGENTS.md` kazanır.
2. Skill kütüphanesi: `.codex/skills/<ad>/SKILL.md`. Göreve uyan **en dar** seti kullan; ortak (`gb-*`) ve proje skill envanteri `AGENTS.md`'dedir.
3. Metinlerde `Codex` = "çalışmayı yürüten ajan"; kendini hariç tutma.
4. Araç yolları/offline: `.codex/TOOL-PATHS.local.properties`.

> Kurallar ve skill eşlemeleri burada TEKRARLANMAZ — hepsi `AGENTS.md`'de. Bu dosya yalnız yönlendirir.

'@
# ============================ /PAYLOAD ===============================

# Claude oturumuna verilecek açılış komutu. Görev tanımı repoda dosyada durur;
# böylece uzun prompt komut satırında taşınmaz, incelenebilir ve tekrar çalıştırılabilir.
$LaunchPrompt = '.codex/BOOTSTRAP-PROMPT.md dosyasini oku ve icindeki bootstrap gorevini bastan sona uygula.'

# ------------------------------ yardımcılar ------------------------------

$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Write-Head($Text) { Write-Host ""; Write-Host $Text -ForegroundColor Cyan }
function Write-Ok($Text) { Write-Host "  [+] $Text" -ForegroundColor Green }
function Write-Skip($Text) { Write-Host "  [=] $Text" -ForegroundColor DarkGray }
function Write-Warn2($Text) { Write-Host "  [!] $Text" -ForegroundColor Yellow }
function Write-Err2($Text) { Write-Host "  [x] $Text" -ForegroundColor Red }

function Save-Text {
    param([string]$Path, [string]$Text)
    $dir = Split-Path -Parent $Path
    if ($dir -and -not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
    [System.IO.File]::WriteAllText($Path, $Text, $Utf8NoBom)
}

function Get-DetectedAppName {
    $fromRemote = $null
    try {
        $remote = & git remote get-url origin 2>$null
        if ($LASTEXITCODE -eq 0 -and $remote) {
            $leaf = ($remote -replace '\.git$', '') -split '[/\\]' | Where-Object { $_ } | Select-Object -Last 1
            if ($leaf) { $fromRemote = $leaf }
        }
    }
    catch { }
    if ($fromRemote) { return $fromRemote }
    return (Split-Path -Leaf (Get-Location).Path)
}

function Get-DetectedStack {
    $found = New-Object System.Collections.Generic.List[string]
    $probe = [ordered]@{
        'Java / Maven'      = @('pom.xml')
        'Java / Gradle'     = @('build.gradle', 'build.gradle.kts', 'settings.gradle', 'settings.gradle.kts')
        'Node / JS-TS'      = @('package.json')
        'Go'                = @('go.mod')
        '.NET'              = @('*.sln', '*.csproj')
        'Python'            = @('pyproject.toml', 'requirements.txt', 'setup.py')
        'PHP / Composer'    = @('composer.json')
        'Ruby'             = @('Gemfile')
        'Rust'              = @('Cargo.toml')
        'Docker'            = @('Dockerfile', 'docker-compose.yml', 'docker-compose.yaml')
    }
    foreach ($name in $probe.Keys) {
        foreach ($pattern in $probe[$name]) {
            $hit = Get-ChildItem -Path . -Filter $pattern -File -ErrorAction SilentlyContinue |
                Select-Object -First 1
            if (-not $hit) {
                $hit = Get-ChildItem -Path . -Filter $pattern -File -Recurse -Depth 2 -ErrorAction SilentlyContinue |
                    Select-Object -First 1
            }
            if ($hit) { $found.Add($name); break }
        }
    }
    return $found
}

function Merge-Gitignore {
    param([string]$Path, [string]$Lines, [bool]$Simulate)

    $wanted = $Lines -split "`r?`n" | Where-Object { $_.Trim() -ne '' }
    if (-not (Test-Path -LiteralPath $Path)) {
        if (-not $Simulate) {
            $header = "# Agentik çalışma dosyaları (geliştiriciye özel, commit'lenmez)"
            Save-Text -Path $Path -Text (($header, $wanted) -join "`r`n")
        }
        return @{ Created = $true; Added = $wanted }
    }

    $existing = [System.IO.File]::ReadAllLines($Path)
    $missing = $wanted | Where-Object { $existing -notcontains $_ }
    if ($missing.Count -gt 0 -and -not $Simulate) {
        $tail = @('', "# Agentik çalışma dosyaları (geliştiriciye özel, commit'lenmez)") + $missing
        Add-Content -LiteralPath $Path -Value $tail -Encoding UTF8
    }
    return @{ Created = $false; Added = $missing }
}

# ------------------------------ 1. ön kontrol ------------------------------

Write-Host ""
Write-Host "  Global Bilgi - Agentik Calisma Yapisi Kurulumu" -ForegroundColor White
Write-Host "  ortak taban: v$BaselineVersion" -ForegroundColor DarkGray

if ($Payload.Count -eq 0) {
    Write-Err2 "Payload bos. Bu script build-installer.ps1 ile uretilmemis."
    exit 1
}

Write-Head "1) Hedef proje dizini"

$kitDir = $PSScriptRoot

# Kit dizininin icinden yolsuz calistirilmissa yolu sor: bu akista geliştirici
# zip'i actigi klasorde durur, hedef proje baska yerdedir.
if (-not $ProjectPath -or $ProjectPath.Trim() -eq '') {
    if ((Get-Location).Path -eq $kitDir) {
        Write-Warn2 "Kurulum kitinin icinden calistiriliyor; hedef proje yolu gerekli."
        $ProjectPath = Read-Host "  Entegre edilecek proje dizini"
    }
}

if ($ProjectPath -and $ProjectPath.Trim() -ne '') {
    $ProjectPath = $ProjectPath.Trim().Trim('"')
    if (-not (Test-Path -LiteralPath $ProjectPath)) {
        Write-Err2 "Dizin bulunamadi: $ProjectPath"
        exit 1
    }
    $resolved = (Resolve-Path -LiteralPath $ProjectPath).Path
    if (-not (Get-Item -LiteralPath $resolved).PSIsContainer) {
        Write-Err2 "Bir dizin degil: $resolved"
        exit 1
    }
    Set-Location -LiteralPath $resolved
}

$target = (Get-Location).Path
Write-Host "  $target"

if ($target -eq $kitDir) {
    Write-Err2 "Hedef, kurulum kitinin kendisi. Agentik yapi kite kurulmaz."
    Write-Host ""
    Write-Host "  Dogru kullanim:" -ForegroundColor Yellow
    Write-Host "    .\gb-agentic-setup.ps1 C:\projeler\benim-projem" -ForegroundColor Yellow
    Write-Host ""
    exit 1
}

$isGit = Test-Path -LiteralPath (Join-Path $target '.git')
if ($isGit) {
    Write-Ok "git deposu bulundu"
}
else {
    Write-Warn2 "Burada .git yok. Yine de kurulum yapilabilir; ancak history/sync akislari git bekler."
}

if (-not $AppName -or $AppName.Trim() -eq '') {
    $AppName = Get-DetectedAppName
    Write-Host "  Uygulama adi (otomatik): $AppName"
}
else {
    Write-Host "  Uygulama adi: $AppName"
}

$stack = Get-DetectedStack
if ($stack.Count -gt 0) {
    Write-Host "  Tespit edilen yigin: $($stack -join ', ')"
}
else {
    Write-Warn2 "Bilinen build dosyasi bulunamadi; bootstrap gorevi yigini kendi tespit edecek."
}

if ($DryRun) { Write-Warn2 "DryRun: hicbir dosya yazilmayacak." }

# ------------------------------ 2. dosyaları kur ------------------------------

Write-Head "2) Ortak taban dosyalari"

$created = 0; $skipped = 0; $overwritten = 0
$skippedList = New-Object System.Collections.Generic.List[string]

foreach ($rel in $Payload.Keys) {
    if ($rel -eq $GitignoreKey) { continue }

    $content = $Payload[$rel]
    if ($rel -eq 'AGENTS.md') {
        $content = $content.Replace('<UYGULAMA>', $AppName)
    }

    $full = Join-Path $target $rel
    $exists = Test-Path -LiteralPath $full

    if ($exists -and -not $Force) {
        $skipped++; $skippedList.Add($rel) | Out-Null
        continue
    }

    if ($DryRun) {
        if ($exists) { Write-Ok "uzerine yazilacak: $rel" } else { Write-Ok "olusturulacak: $rel" }
        if ($exists) { $overwritten++ } else { $created++ }
        continue
    }

    Save-Text -Path $full -Text $content
    if ($exists) { $overwritten++; Write-Ok "guncellendi: $rel" }
    else { $created++; Write-Ok "olusturuldu: $rel" }
}

if ($skippedList.Count -gt 0) {
    Write-Skip "$($skippedList.Count) dosya zaten var, atlandi (uzerine yazmak icin -Force):"
    foreach ($s in $skippedList) { Write-Skip "    $s" }
}

# ------------------------------ 3. .gitignore ------------------------------

Write-Head "3) .gitignore"

if ($Payload.Contains($GitignoreKey)) {
    $gi = Merge-Gitignore -Path (Join-Path $target '.gitignore') -Lines $Payload[$GitignoreKey] -Simulate:$DryRun.IsPresent
    if ($gi.Created) {
        Write-Ok ".gitignore olusturuldu ($($gi.Added.Count) satir)"
    }
    elseif ($gi.Added.Count -gt 0) {
        foreach ($line in $gi.Added) { Write-Ok "eklendi: $line" }
    }
    else {
        Write-Skip "gerekli satirlar zaten var"
    }
}

# ------------------------------ 4. özet ------------------------------

Write-Head "4) Kurulum ozeti"
Write-Host "  olusturulan : $created"
Write-Host "  guncellenen : $overwritten"
Write-Host "  atlanan     : $skipped"

if (-not $DryRun) {
    Write-Host ""
    Write-Host "  Siradaki elle adim:" -ForegroundColor White
    Write-Host "    - .codex/TOOL-PATHS.example.properties -> .codex/TOOL-PATHS.local.properties olarak kopyalayip"
    Write-Host "      gercek arac yollarini doldurun (bu dosya commit'lenmez)."
    Write-Host "    - MCP kullanacaksaniz .mcp.json.example -> .mcp.json"
}

# ------------------------------ 5. Claude Code ------------------------------

function Update-PathFromRegistry {
    # Kurulum PATH'e yazar ama calisan surecimiz bunu gormez; registry'den yenile.
    try {
        $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
        $user = [Environment]::GetEnvironmentVariable('Path', 'User')
        $joined = @($machine, $user) | Where-Object { $_ }
        if ($joined) { $env:Path = $joined -join ';' }
    }
    catch { }
}

function Find-Claude {
    $cmd = Get-Command claude -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    # Native kurulum sabit yola gider; PATH henuz yenilenmemis olabilir.
    $native = Join-Path $env:USERPROFILE '.local\bin\claude.exe'
    if (Test-Path -LiteralPath $native) { return $native }
    return $null
}

function Install-ClaudeCode {
    # PS 5.1 varsayilan olarak eski TLS deneyebilir; modern uclar icin TLS 1.2 zorla.
    try {
        [Net.ServicePointManager]::SecurityProtocol =
            [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    }
    catch { }

    Write-Host "  yontem 1/2: resmi native installer" -ForegroundColor DarkGray
    Write-Host "    irm https://claude.ai/install.ps1 | iex" -ForegroundColor DarkGray
    try {
        $installer = Invoke-RestMethod -Uri 'https://claude.ai/install.ps1' -TimeoutSec 120
        & ([scriptblock]::Create($installer))
        Update-PathFromRegistry
        if (Find-Claude) { return 'native installer' }
        Write-Warn2 "native installer calisti ama claude bulunamadi"
    }
    catch {
        Write-Warn2 "native installer basarisiz: $($_.Exception.Message)"
    }

    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host "  yontem 2/2: winget" -ForegroundColor DarkGray
        Write-Host "    winget install Anthropic.ClaudeCode" -ForegroundColor DarkGray
        try {
            & winget install --id Anthropic.ClaudeCode --exact `
                --accept-package-agreements --accept-source-agreements | Out-Host
            Update-PathFromRegistry
            if (Find-Claude) { return 'winget' }
            Write-Warn2 "winget calisti ama claude bulunamadi"
        }
        catch {
            Write-Warn2 "winget basarisiz: $($_.Exception.Message)"
        }
    }
    else {
        Write-Skip "winget yok, atlandi"
    }

    return $null
}

Write-Head "5) Claude Code"

$claudePath = Find-Claude
$freshInstall = $false

if ($claudePath) {
    Write-Ok "bulundu: $claudePath"
}
else {
    Write-Warn2 "Claude Code kurulu degil."

    $doInstall = $false
    if ($InstallClaude) {
        $doInstall = $true
        Write-Host "  -InstallClaude verildi, sorulmadan kurulacak."
    }
    elseif ($SkipClaudeInstall -or $NoClaude -or $DryRun) {
        Write-Skip "kurulum atlandi (bayrak)"
    }
    else {
        Write-Host ""
        Write-Host "  Kurulum kullanici profiline yapilir, yonetici yetkisi gerekmez:"
        Write-Host "    $env:USERPROFILE\.local\bin"
        Write-Host "  Indirme boyutu ~330 MB. Internet erisimi gerekir."
        Write-Host ""
        $answer = Read-Host "  Claude Code simdi kurulsun mu? [E/h]"
        $doInstall = ($answer.Trim() -eq '' -or $answer.Trim() -match '^[eEyY]')
    }

    if ($doInstall) {
        Write-Host ""
        $via = Install-ClaudeCode
        Write-Host ""
        if ($via) {
            $claudePath = Find-Claude
            $freshInstall = $true
            Write-Ok "Claude Code kuruldu ($via)"
            try {
                $ver = (& $claudePath --version 2>&1 | Select-Object -First 1)
                Write-Host "  surum: $ver"
            }
            catch { }
        }
        else {
            Write-Err2 "Claude Code kurulamadi."
            Write-Host "  Elle kurulum secenekleri:" -ForegroundColor Yellow
            Write-Host "    PowerShell : irm https://claude.ai/install.ps1 | iex"
            Write-Host "    WinGet     : winget install Anthropic.ClaudeCode"
            Write-Host "    npm        : npm install -g @anthropic-ai/claude-code   (Node 22+)"
            Write-Host "  Kurumsal agda cikis engelliyse ag ekibiyle claude.ai erisimini konusun."
        }
    }
}

# ------------------------------ 6. bootstrap ------------------------------

Write-Head "6) Bootstrap gorevi"

if ($DryRun) {
    Write-Skip "DryRun: oturum baslatilmadi"
    Write-Host ""
    Write-Host "    claude --effort $Effort --permission-mode $PermissionMode `"$LaunchPrompt`"" -ForegroundColor Yellow
    Write-Host ""
    exit 0
}

if ($NoClaude) {
    Write-Skip "-NoClaude: oturum baslatilmadi"
    Write-Host "  Hazir oldugunuzda proje dizininde:"
    Write-Host ""
    Write-Host "    claude --effort $Effort --permission-mode $PermissionMode `"$LaunchPrompt`"" -ForegroundColor Yellow
    Write-Host ""
    exit 0
}

if (-not $claudePath) {
    Write-Warn2 "Claude Code olmadigi icin bootstrap baslatilamiyor."
    Write-Host "  Dosyalar kuruldu; Claude Code'u kurduktan sonra proje dizininde:"
    Write-Host ""
    Write-Host "    claude --effort $Effort --permission-mode $PermissionMode `"$LaunchPrompt`"" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Kurulum rehberi: https://code.claude.com/docs/en/setup"
    exit 0
}

if ($freshInstall) {
    Write-Host "  Yeni kurulum: ilk acilista tarayicidan giris yapmaniz istenebilir." -ForegroundColor Yellow
    Write-Host "  Giris sonrasi bootstrap kendiliginden baslamazsa su komutu tekrar calistirin:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "    claude --effort $Effort --permission-mode $PermissionMode `"$LaunchPrompt`"" -ForegroundColor Yellow
    Write-Host ""
}

$claudeArgs = @('--effort', $Effort, '--permission-mode', $PermissionMode)
if ($Model) { $claudeArgs += @('--model', $Model) }
$claudeArgs += $LaunchPrompt

Write-Host "  gorev tanimi: .codex/BOOTSTRAP-PROMPT.md" -ForegroundColor DarkGray
Write-Host "  claude --effort $Effort --permission-mode $PermissionMode `"<bootstrap>`""
Write-Host ""

& $claudePath @claudeArgs
exit $LASTEXITCODE
