package com.masrafradar.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.masrafradar.data.entity.Expense
import com.masrafradar.data.entity.ExpenseWithCategory
import com.masrafradar.ui.components.Fmt
import com.masrafradar.viewmodel.DashboardState

@Composable
fun ExpensesScreen(
    state: DashboardState,
    pendingExpenses: List<ExpenseWithCategory>,
    onConfirm: (Expense) -> Unit,
    onDelete: (Expense) -> Unit,
    onUpdateAmount: (Expense, Double) -> Unit
) {
    var editTarget by remember { mutableStateOf<Expense?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // ── Pending Section ──
        if (pendingExpenses.isNotEmpty()) {
            item {
                Text("Onay Bekleyenler", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
            }
            items(pendingExpenses, key = { "p_${it.expense.id}" }) { ewc ->
                PendingCard(
                    ewc = ewc,
                    onConfirm = { onConfirm(ewc.expense) },
                    onDelete = { onDelete(ewc.expense) },
                    onEdit = { editTarget = ewc.expense }
                )
            }
            item { HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp)) }
        }

        // ── Monthly Expenses ──
        item {
            Text(
                "${Fmt.monthName(state.currentMonth)} ${state.currentYear} Masrafları",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }

        val monthExpenses = state.recentExpenses.filter {
            it.expense.year == state.currentYear && it.expense.month == state.currentMonth
        }

        if (monthExpenses.isEmpty()) {
            item {
                Card(modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("Bu ay masraf kaydı yok", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        items(monthExpenses, key = { "e_${it.expense.id}" }) { ewc ->
            ExpenseDetailCard(
                ewc = ewc,
                onDelete = { onDelete(ewc.expense) }
            )
        }
    }

    // Edit Amount Dialog
    editTarget?.let { expense ->
        var newAmount by remember { mutableStateOf(if (expense.amount > 0) "%.2f".format(expense.amount) else "") }
        AlertDialog(
            onDismissRequest = { editTarget = null },
            title = { Text("Tutar Düzenle") },
            text = {
                Column {
                    expense.rawNotification?.let {
                        Text("Bildirim: $it", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3)
                        Spacer(Modifier.height(12.dp))
                    }
                    OutlinedTextField(
                        value = newAmount,
                        onValueChange = { newAmount = it.filter { c -> c.isDigit() || c == '.' || c == ',' } },
                        label = { Text("Tutar (TL)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val parsed = newAmount.replace(",", ".").toDoubleOrNull()
                    if (parsed != null && parsed > 0) { onUpdateAmount(expense, parsed); editTarget = null }
                }) { Text("Kaydet") }
            },
            dismissButton = { TextButton(onClick = { editTarget = null }) { Text("İptal") } }
        )
    }
}

@Composable
private fun PendingCard(
    ewc: ExpenseWithCategory,
    onConfirm: () -> Unit,
    onDelete: () -> Unit,
    onEdit: () -> Unit
) {
    val e = ewc.expense
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.NotificationsActive, null, modifier = Modifier.size(18.dp),
                    tint = MaterialTheme.colorScheme.error)
                Spacer(Modifier.width(8.dp))
                Text(e.matchedKeyword ?: "Bilinmeyen", fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.weight(1f))
                if (e.amount > 0) {
                    Text(Fmt.money(e.amount), fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall)
                } else {
                    Text("Tutar yok", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error)
                }
            }

            e.rawNotification?.let {
                Spacer(Modifier.height(4.dp))
                Text(it, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            }

            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = onConfirm, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Check, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Onayla")
                }
                OutlinedButton(onClick = onEdit, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Edit, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Düzenle")
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, "Sil", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun ExpenseDetailCard(ewc: ExpenseWithCategory, onDelete: () -> Unit) {
    val e = ewc.expense
    var showDelete by remember { mutableStateOf(false) }

    Card(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(ewc.subCategoryName ?: "Kategorisiz",
                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                Text(
                    "${e.day}/${e.month}/${e.year} · ${e.description.ifBlank { ewc.categoryName ?: e.source }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(Fmt.money(e.amount), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.width(4.dp))
            IconButton(onClick = { showDelete = true }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Close, "Sil", modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Masraf Sil") },
            text = { Text("${Fmt.money(e.amount)} tutarındaki masraf silinecek.") },
            confirmButton = {
                Button(onClick = { onDelete(); showDelete = false },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Sil") }
            },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("İptal") } }
        )
    }
}
