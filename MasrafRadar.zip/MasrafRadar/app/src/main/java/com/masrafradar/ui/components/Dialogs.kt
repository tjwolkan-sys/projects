package com.masrafradar.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.masrafradar.data.entity.CategoryWithSubs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddExpenseDialog(
    categories: List<CategoryWithSubs>,
    onDismiss: () -> Unit,
    onConfirm: (subCategoryId: Long, amount: Double, description: String) -> Unit
) {
    var selectedCatIndex by remember { mutableIntStateOf(-1) }
    var selectedSubId by remember { mutableLongStateOf(-1L) }
    var amount by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var catExpanded by remember { mutableStateOf(false) }
    var subExpanded by remember { mutableStateOf(false) }

    val selectedCat = if (selectedCatIndex >= 0) categories.getOrNull(selectedCatIndex) else null
    val subs = selectedCat?.subCategories?.map { it.subCategory } ?: emptyList()
    val selectedSub = subs.find { it.id == selectedSubId }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Masraf Ekle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Kategori seçimi
                ExposedDropdownMenuBox(expanded = catExpanded, onExpandedChange = { catExpanded = it }) {
                    OutlinedTextField(
                        value = selectedCat?.category?.name ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Kategori") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(catExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
                        categories.forEachIndexed { i, cws ->
                            DropdownMenuItem(
                                text = { Text(cws.category.name) },
                                onClick = {
                                    selectedCatIndex = i
                                    selectedSubId = -1
                                    catExpanded = false
                                }
                            )
                        }
                    }
                }

                // Alt kategori seçimi
                if (subs.isNotEmpty()) {
                    ExposedDropdownMenuBox(expanded = subExpanded, onExpandedChange = { subExpanded = it }) {
                        OutlinedTextField(
                            value = selectedSub?.name ?: "",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Alt Kategori") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(subExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = subExpanded, onDismissRequest = { subExpanded = false }) {
                            subs.forEach { sub ->
                                DropdownMenuItem(
                                    text = { Text(sub.name) },
                                    onClick = {
                                        selectedSubId = sub.id
                                        subExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' || c == ',' } },
                    label = { Text("Tutar (TL)") },
                    placeholder = { Text("0,00") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Açıklama (opsiyonel)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val parsed = amount.replace(",", ".").toDoubleOrNull() ?: 0.0
                if (selectedSubId > 0 && parsed > 0) {
                    onConfirm(selectedSubId, parsed, description)
                    onDismiss()
                }
            }) { Text("Ekle") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }
    )
}

@Composable
fun AddCategoryDialog(onDismiss: () -> Unit, onConfirm: (name: String, color: String) -> Unit) {
    var name by remember { mutableStateOf("") }
    val colors = listOf("#4CAF50","#1976D2","#E91E63","#FF9800","#00BCD4","#9C27B0","#673AB7","#607D8B")
    var selectedColor by remember { mutableStateOf(colors[0]) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Yeni Kategori") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Kategori Adı") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Renk seçin:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    colors.forEach { color ->
                        val c = android.graphics.Color.parseColor(color)
                        val isSelected = color == selectedColor
                        FilledIconButton(
                            onClick = { selectedColor = color },
                            modifier = Modifier.size(36.dp),
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = androidx.compose.ui.graphics.Color(c),
                                contentColor = androidx.compose.ui.graphics.Color.White
                            )
                        ) {
                            if (isSelected) {
                                Text("✓", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank()) { onConfirm(name.trim(), selectedColor); onDismiss() }
            }) { Text("Ekle") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }
    )
}

@Composable
fun SimpleInputDialog(
    title: String,
    label: String,
    placeholder: String = "",
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var value by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                label = { Text(label) },
                placeholder = { Text(placeholder) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(onClick = {
                if (value.isNotBlank()) { onConfirm(value.trim()); onDismiss() }
            }) { Text("Ekle") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }
    )
}
