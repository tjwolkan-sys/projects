package com.masrafradar.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.masrafradar.data.dao.*
import com.masrafradar.data.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Category::class, SubCategory::class, Keyword::class, Expense::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun categoryDao(): CategoryDao
    abstract fun subCategoryDao(): SubCategoryDao
    abstract fun keywordDao(): KeywordDao
    abstract fun expenseDao(): ExpenseDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "masraf_radar_db"
                )
                .addCallback(SeedCallback())
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class SeedCallback : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                CoroutineScope(Dispatchers.IO).launch {
                    seedDatabase(database)
                }
            }
        }
    }
}

private suspend fun seedDatabase(db: AppDatabase) {
    val catDao = db.categoryDao()
    val subDao = db.subCategoryDao()
    val kwDao = db.keywordDao()

    data class Seed(val cat: String, val color: String, val icon: String, val subs: List<Pair<String, List<String>>>)

    val seeds = listOf(
        Seed("Araç Şarj", "#4CAF50", "ElectricCar", listOf(
            "Şarj İstasyonları" to listOf("ZES", "Eşarj", "Sharz", "Trugo", "Voltrun", "Beefull", "Tesla")
        )),
        Seed("Faturalar", "#1976D2", "Receipt", listOf(
            "Elektrik" to listOf("AYEDAŞ", "Enerjisa", "CK Enerji", "Başkent Elektrik"),
            "Su" to listOf("İSKİ", "ASKİ", "SASKİ"),
            "Doğalgaz" to listOf("İGDAŞ", "Başkent Doğalgaz"),
            "Telefon / İnternet" to listOf("Turkcell", "Vodafone", "Türk Telekom")
        )),
        Seed("Dijital Abonelikler", "#E91E63", "Subscriptions", listOf(
            "Video / Müzik" to listOf("Netflix", "Spotify", "YouTube", "Disney+", "BluTV", "Gain", "Exxen"),
            "AI / Bulut" to listOf("ChatGPT", "Claude", "iCloud", "Google One", "Dropbox"),
            "Oyun" to listOf("Game Pass", "PS Plus", "EA Play", "Steam")
        )),
        Seed("Market / Yemek", "#FF9800", "ShoppingCart", listOf(
            "Market" to listOf("Migros", "A101", "BİM", "Şok", "CarrefourSA", "Getir", "Trendyol"),
            "Yemek Sipariş" to listOf("Yemeksepeti", "Getir Yemek")
        )),
        Seed("Ulaşım", "#00BCD4", "DirectionsCar", listOf(
            "Toplu Taşıma" to listOf("İstanbulkart", "Ankarakart", "İzmirim Kart"),
            "Geçiş / Taksi" to listOf("HGS", "OGS", "BiTaksi", "Uber"),
            "Havayolu" to listOf("THY", "Pegasus", "AnadoluJet", "SunExpress")
        )),
        Seed("Sağlık", "#9C27B0", "LocalHospital", listOf(
            "Sağlık" to listOf("Eczane", "Hastane", "Medikal")
        )),
        Seed("Eğitim", "#673AB7", "School", listOf(
            "Online Eğitim" to listOf("Udemy", "Coursera", "Duolingo"),
            "Kitap" to listOf("D&R", "Kitapyurdu", "Amazon Kindle")
        )),
        Seed("Konut / Aidat", "#607D8B", "Home", listOf(
            "Konut" to listOf("Aidat", "Kira", "Tadilat")
        ))
    )

    for ((index, seed) in seeds.withIndex()) {
        val catId = catDao.insert(Category(name = seed.cat, colorHex = seed.color, icon = seed.icon, sortOrder = index))
        for (sub in seed.subs) {
            val subId = subDao.insert(SubCategory(categoryId = catId, name = sub.first))
            for (kw in sub.second) {
                kwDao.insert(Keyword(subCategoryId = subId, keyword = kw))
            }
        }
    }
}
