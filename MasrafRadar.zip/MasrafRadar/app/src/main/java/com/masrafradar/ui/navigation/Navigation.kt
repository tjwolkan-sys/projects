package com.masrafradar.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    data object Dashboard : Screen("dashboard", "Özet", Icons.Default.Dashboard)
    data object Expenses : Screen("expenses", "Masraflar", Icons.Default.Receipt)
    data object Categories : Screen("categories", "Kategoriler", Icons.Default.Category)
    data object Settings : Screen("settings", "Ayarlar", Icons.Default.Settings)
}

val bottomNavItems = listOf(Screen.Dashboard, Screen.Expenses, Screen.Categories, Screen.Settings)
