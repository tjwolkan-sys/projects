package com.masrafradar.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.masrafradar.App
import com.masrafradar.data.entity.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

data class DashboardState(
    val monthlyTotal: Double = 0.0,
    val categoryTotals: List<CategoryTotal> = emptyList(),
    val recentExpenses: List<ExpenseWithCategory> = emptyList(),
    val pendingCount: Int = 0,
    val currentYear: Int = Calendar.getInstance().get(Calendar.YEAR),
    val currentMonth: Int = Calendar.getInstance().get(Calendar.MONTH) + 1,
    val monthlyHistory: List<MonthlyTotal> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = (application as App).repository

    private val _currentYear = MutableStateFlow(Calendar.getInstance().get(Calendar.YEAR))
    private val _currentMonth = MutableStateFlow(Calendar.getInstance().get(Calendar.MONTH) + 1)

    val dashboardState: StateFlow<DashboardState> = combine(
        _currentYear, _currentMonth
    ) { year, month -> year to month }
        .flatMapLatest { (year, month) ->
            combine(
                repo.getMonthlyTotal(year, month),
                repo.getCategoryTotals(year, month),
                repo.getRecentExpenses(15),
                repo.getPendingExpenses(),
                repo.getMonthlyTotals()
            ) { total, catTotals, recent, pending, history ->
                DashboardState(
                    monthlyTotal = total ?: 0.0,
                    categoryTotals = catTotals,
                    recentExpenses = recent,
                    pendingCount = pending.size,
                    currentYear = year,
                    currentMonth = month,
                    monthlyHistory = history
                )
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardState())

    val allCategoriesWithSubs = repo.allCategoriesWithSubs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingExpenses = repo.getPendingExpenses()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _toast = MutableSharedFlow<String>()
    val toast: SharedFlow<String> = _toast.asSharedFlow()

    // ── Navigation ──
    fun setMonth(year: Int, month: Int) {
        _currentYear.value = year
        _currentMonth.value = month
    }

    // ── Expense Operations ──
    fun addExpense(subCategoryId: Long, amount: Double, description: String, currency: String = "TRY") {
        viewModelScope.launch {
            val cal = Calendar.getInstance()
            repo.insertExpense(Expense(
                subCategoryId = subCategoryId,
                amount = amount,
                currency = currency,
                description = description,
                source = "manual",
                isConfirmed = true,
                year = cal.get(Calendar.YEAR),
                month = cal.get(Calendar.MONTH) + 1,
                day = cal.get(Calendar.DAY_OF_MONTH)
            ))
            _toast.emit("Masraf eklendi")
        }
    }

    fun confirmExpense(expense: Expense) {
        viewModelScope.launch {
            repo.updateExpense(expense.copy(isConfirmed = true))
            _toast.emit("Masraf onaylandı")
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            repo.deleteExpense(expense)
            _toast.emit("Masraf silindi")
        }
    }

    fun updateExpenseAmount(expense: Expense, newAmount: Double) {
        viewModelScope.launch {
            repo.updateExpense(expense.copy(amount = newAmount, isConfirmed = true))
            _toast.emit("Tutar güncellendi")
        }
    }

    // ── Category Operations ──
    fun addCategory(name: String, color: String) {
        viewModelScope.launch {
            repo.insertCategory(Category(name = name, colorHex = color))
            _toast.emit("Kategori eklendi")
        }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            repo.deleteCategory(category)
            _toast.emit("Kategori silindi")
        }
    }

    fun addSubCategory(categoryId: Long, name: String) {
        viewModelScope.launch {
            repo.insertSubCategory(SubCategory(categoryId = categoryId, name = name))
            _toast.emit("Alt kategori eklendi")
        }
    }

    fun deleteSubCategory(sub: SubCategory) {
        viewModelScope.launch {
            repo.deleteSubCategory(sub)
            _toast.emit("Alt kategori silindi")
        }
    }

    fun addKeyword(subCategoryId: Long, keyword: String) {
        viewModelScope.launch {
            repo.insertKeyword(Keyword(subCategoryId = subCategoryId, keyword = keyword.trim()))
            _toast.emit("Keyword eklendi: $keyword")
        }
    }

    fun deleteKeyword(keyword: Keyword) {
        viewModelScope.launch {
            repo.deleteKeyword(keyword)
            _toast.emit("Keyword silindi")
        }
    }

    fun toggleKeyword(keyword: Keyword) {
        viewModelScope.launch {
            repo.updateKeyword(keyword.copy(isActive = !keyword.isActive))
        }
    }
}
