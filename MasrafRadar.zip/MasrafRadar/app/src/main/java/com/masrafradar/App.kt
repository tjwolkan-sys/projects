package com.masrafradar

import android.app.Application
import com.masrafradar.data.database.AppDatabase
import com.masrafradar.data.repository.MasrafRepository

class App : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy {
        MasrafRepository(
            database.categoryDao(),
            database.subCategoryDao(),
            database.keywordDao(),
            database.expenseDao()
        )
    }
}
