package com.masrafradar.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.masrafradar.data.entity.CategoryTotal
import com.masrafradar.data.entity.CategoryWithSubs
import com.masrafradar.data.entity.ExpenseWithCategory
import com.masrafradar.ui.components.AddExpenseDialog
import com.masrafradar.ui.components.Fmt
import com.masrafradar.viewmodel.DashboardState

@Composable
fun DashboardScreen(
    state: DashboardState,
    categories: List<CategoryWithSubs>,
    onAddExpense: (Long, Double, String) -> Unit,
    onSetMonth: (Int, Int) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    val prevMonth = if (state.currentMonth == 1) 12 else state.currentMonth - 1
    val prevYear = if (state.currentMonth == 1) state.currentYear - 1 else state.currentYear
    val prevTotal = state.monthlyHistory.find { it.year == prevYear && it.month == prevMonth }?.total

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, "Masraf Ekle")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            // ── Month Selector ──
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { onSetMonth(prevYear, prevMonth) }) {
                        Icon(Icons.Default.ChevronLeft, "Önceki ay")
                    }
                    Text(
                        "${Fmt.monthName(state.currentMonth)} ${state.currentYear}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    val nextMonth = if (state.currentMonth == 12) 1 else state.currentMonth + 1
                    val nextYear = if (state.currentMonth == 12) state.currentYear + 1 else state.currentYear
                    IconButton(onClick = { onSetMonth(nextYear, nextMonth) }) {
                        Icon(Icons.Default.ChevronRight, "Sonraki ay")
                    }
                }
            }

            // ── Total Card ──
            item {
                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.elevatedCardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("Aylık Toplam", style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            Fmt.money(state.monthlyTotal),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (prevTotal != null && prevTotal > 0) {
                            val diff = state.monthlyTotal - prevTotal
                            val pct = (diff / prevTotal * 100)
                            val isUp = diff > 0
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (isUp) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = if (isUp) com.masrafradar.ui.theme.Red600 else com.masrafradar.ui.theme.Green600
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    "Geçen aya göre ${if (isUp) "+" else ""}${String.format("%.1f", pct)}%",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isUp) com.masrafradar.ui.theme.Red600 else com.masrafradar.ui.theme.Green600
                                )
                            }
                        }
                    }
                }
            }

            // ── Pending Badge ──
            if (state.pendingCount > 0) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.NotificationsActive, null, tint = MaterialTheme.colorScheme.error)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                "${state.pendingCount} onay bekleyen masraf var",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
            }

            // ── Category Breakdown ──
            if (state.categoryTotals.isNotEmpty()) {
                item {
                    Text("Kategori Dağılımı", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                items(state.categoryTotals) { ct -> CategoryBar(ct, state.monthlyTotal) }
            }

            // ── Recent Expenses ──
            if (state.recentExpenses.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(4.dp))
                    Text("Son Masraflar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                items(state.recentExpenses.take(10), key = { it.expense.id }) { ewc ->
                    ExpenseRow(ewc)
                }
            }

            // ── Empty State ──
            if (state.categoryTotals.isEmpty() && state.recentExpenses.isEmpty()) {
                item {
                    Card(modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.fillMaxWidth().padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Receipt, null, modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(8.dp))
                            Text("Bu ay henüz masraf yok", style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("+ butonuyla ekleyin veya bildirimleri dinleyin",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    if (showAddDialog) {
        AddExpenseDialog(
            categories = categories,
            onDismiss = { showAddDialog = false },
            onConfirm = onAddExpense
        )
    }
}

@Composable
private fun CategoryBar(ct: CategoryTotal, total: Double) {
    val ratio = if (total > 0) (ct.total / total).toFloat().coerceIn(0f, 1f) else 0f
    val color = try { Color(android.graphics.Color.parseColor(ct.colorHex)) } catch (_: Exception) { MaterialTheme.colorScheme.primary }

    Card(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(ct.categoryName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { ratio },
                    modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = color,
                    trackColor = color.copy(alpha = 0.15f)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(Fmt.money(ct.total), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                Text("${String.format("%.0f", ratio * 100)}%", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun ExpenseRow(ewc: ExpenseWithCategory) {
    val e = ewc.expense
    val catColor = ewc.categoryColor?.let {
        try { Color(android.graphics.Color.parseColor(it)) } catch (_: Exception) { null }
    } ?: MaterialTheme.colorScheme.primary
    val sourceIcon = when (e.source) {
        "notification" -> Icons.Default.NotificationsActive
        "sms" -> Icons.Default.Sms
        else -> Icons.Default.Edit
    }

    Card(modifier = Modifier.fillMaxWidth(),
        colors = if (!e.isConfirmed) CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
        ) else CardDefaults.cardColors()
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(catColor))
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    ewc.subCategoryName ?: "Kategorisiz",
                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(sourceIcon, null, modifier = Modifier.size(12.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(4.dp))
                    Text(
                        e.description.ifBlank { ewc.categoryName ?: "" },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }
            Text(
                Fmt.money(e.amount),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
