package com.masrafradar.ui.components

import java.text.NumberFormat
import java.util.Locale

object Fmt {
    private val tr = Locale("tr", "TR")
    private val curr = NumberFormat.getCurrencyInstance(tr).apply { maximumFractionDigits = 2 }

    fun money(value: Double): String = curr.format(value)
    fun monthName(m: Int): String = when (m) {
        1->"Ocak";2->"Şubat";3->"Mart";4->"Nisan";5->"Mayıs";6->"Haziran"
        7->"Temmuz";8->"Ağustos";9->"Eylül";10->"Ekim";11->"Kasım";12->"Aralık";else->""
    }
}
