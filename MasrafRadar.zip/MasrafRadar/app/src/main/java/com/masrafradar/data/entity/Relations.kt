package com.masrafradar.data.entity

import androidx.room.Embedded
import androidx.room.Relation

data class SubCategoryWithKeywords(
    @Embedded val subCategory: SubCategory,
    @Relation(
        parentColumn = "id",
        entityColumn = "subCategoryId"
    )
    val keywords: List<Keyword>
)

data class CategoryWithSubs(
    @Embedded val category: Category,
    @Relation(
        parentColumn = "id",
        entityColumn = "categoryId",
        entity = SubCategory::class
    )
    val subCategories: List<SubCategoryWithKeywords>
)

data class ExpenseWithCategory(
    @Embedded val expense: Expense,
    val categoryName: String?,
    val subCategoryName: String?,
    val categoryColor: String?
)

data class CategoryTotal(
    val categoryId: Long,
    val categoryName: String,
    val colorHex: String,
    val total: Double
)

data class MonthlyTotal(
    val year: Int,
    val month: Int,
    val total: Double
)
