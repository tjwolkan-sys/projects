package com.masrafradar.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat
import com.masrafradar.MainActivity
import com.masrafradar.data.database.AppDatabase
import com.masrafradar.data.entity.Expense
import com.masrafradar.data.entity.Keyword
import com.masrafradar.data.entity.SubCategory
import kotlinx.coroutines.*
import java.util.Calendar
import java.util.regex.Pattern

class MasrafNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var keywordCache: List<Pair<Keyword, SubCategory>>? = null
    private var lastCacheRefresh = 0L

    companion object {
        private const val TAG = "MasrafListener"
        private const val CHANNEL_ID = "masraf_detected"
        private const val CACHE_TTL = 60_000L // 1 dakika

        // Türk Lirası tutar yakalama pattern'leri
        private val AMOUNT_PATTERNS = listOf(
            // ₺150,00 veya ₺1.500,00 veya ₺150
            Pattern.compile("₺\\s*([\\d.]+[,.]\\d{0,2})"),
            // 150,00 TL veya 1.500,00 TL
            Pattern.compile("([\\d.]+,\\d{2})\\s*TL"),
            // 150.00 TL
            Pattern.compile("([\\d,]+\\.\\d{2})\\s*TL"),
            // 150 TL
            Pattern.compile("(\\d[\\d.]*)\\s*TL"),
            // Tutar: 150,00 veya Tutar: 150.00
            Pattern.compile("[Tt]utar[:\\s]*([\\d.,]+)"),
            // USD patterns
            Pattern.compile("\\$\\s*([\\d.,]+)"),
            Pattern.compile("([\\d.,]+)\\s*(?:USD|\\$)"),
            // EUR patterns
            Pattern.compile("€\\s*([\\d.,]+)"),
            Pattern.compile("([\\d.,]+)\\s*(?:EUR|€)"),
        )
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        // Kendi bildirimlerimizi dinleme
        if (sbn.packageName == packageName) return

        val notification = sbn.notification ?: return
        val extras = notification.extras ?: return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: ""

        val fullText = "$title $text $bigText".trim()
        if (fullText.isBlank()) return

        scope.launch {
            try {
                processNotification(fullText, sbn.packageName)
            } catch (e: Exception) {
                Log.e(TAG, "Error processing notification", e)
            }
        }
    }

    private suspend fun processNotification(fullText: String, packageName: String) {
        val keywords = getKeywordCache()
        val textLower = fullText.lowercase()

        // Keyword eşleşmesi ara
        val match = keywords.firstOrNull { (kw, _) ->
            textLower.contains(kw.keyword.lowercase())
        } ?: return

        // Tutar çıkar
        val amount = extractAmount(fullText)

        val cal = Calendar.getInstance()
        val expense = Expense(
            subCategoryId = match.second.id,
            amount = amount ?: 0.0,
            description = if (amount != null) {
                "${match.first.keyword} - otomatik yakalandı"
            } else {
                "${match.first.keyword} - tutar bulunamadı"
            },
            source = "notification",
            matchedKeyword = match.first.keyword,
            rawNotification = fullText.take(500),
            isConfirmed = amount != null && amount > 0,
            year = cal.get(Calendar.YEAR),
            month = cal.get(Calendar.MONTH) + 1,
            day = cal.get(Calendar.DAY_OF_MONTH)
        )

        val db = AppDatabase.getDatabase(applicationContext)
        val expenseId = db.expenseDao().insert(expense)

        // Kullanıcıya bildir
        if (amount != null && amount > 0) {
            showDetectionNotification(match.first.keyword, amount, expenseId)
        }
    }

    fun extractAmount(text: String): Double? {
        for (pattern in AMOUNT_PATTERNS) {
            val matcher = pattern.matcher(text)
            if (matcher.find()) {
                val raw = matcher.group(1) ?: continue
                return parseAmount(raw)
            }
        }
        return null
    }

    private fun parseAmount(raw: String): Double? {
        return try {
            // Türk formatı: 1.500,75 → binlik ayırıcı nokta, ondalık virgül
            // Amerikan formatı: 1,500.75 → binlik ayırıcı virgül, ondalık nokta
            val cleaned = if (raw.contains(",") && raw.indexOf(",") > raw.lastIndexOf(".")) {
                // Türk formatı: 1.234,56
                raw.replace(".", "").replace(",", ".")
            } else if (raw.contains(".") && raw.indexOf(".") > raw.lastIndexOf(",")) {
                // Amerikan formatı: 1,234.56
                raw.replace(",", "")
            } else if (raw.contains(",") && !raw.contains(".")) {
                // Sadece virgül: 234,56
                raw.replace(",", ".")
            } else {
                raw
            }
            cleaned.toDoubleOrNull()
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun getKeywordCache(): List<Pair<Keyword, SubCategory>> {
        val now = System.currentTimeMillis()
        if (keywordCache != null && (now - lastCacheRefresh) < CACHE_TTL) {
            return keywordCache!!
        }
        val db = AppDatabase.getDatabase(applicationContext)
        val activeKeywords = db.keywordDao().getAllActive()
        val allSubs = db.subCategoryDao().getAll()
        val subMap = allSubs.associateBy { it.id }

        keywordCache = activeKeywords.mapNotNull { kw ->
            subMap[kw.subCategoryId]?.let { sub -> kw to sub }
        }
        lastCacheRefresh = now
        return keywordCache!!
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Masraf Tespiti",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Otomatik yakalanan masraf bildirimleri"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun showDetectionNotification(keyword: String, amount: Double, expenseId: Long) {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, expenseId.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val formattedAmount = String.format("%,.2f", amount)
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setContentTitle("Masraf Yakalandı")
            .setContentText("$keyword: ₺$formattedAmount")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val nm = getSystemService(NotificationManager::class.java)
        nm?.notify(expenseId.toInt(), notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
