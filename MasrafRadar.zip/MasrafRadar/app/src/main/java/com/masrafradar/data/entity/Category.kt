package com.masrafradar.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val icon: String = "Receipt",    // Material icon name
    val colorHex: String = "#1976D2",
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
