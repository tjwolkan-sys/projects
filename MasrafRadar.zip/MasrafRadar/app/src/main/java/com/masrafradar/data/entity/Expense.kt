package com.masrafradar.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "expenses",
    foreignKeys = [ForeignKey(
        entity = SubCategory::class,
        parentColumns = ["id"],
        childColumns = ["subCategoryId"],
        onDelete = ForeignKey.SET_NULL
    )],
    indices = [Index("subCategoryId"), Index("createdAt")]
)
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subCategoryId: Long? = null,
    val amount: Double,
    val currency: String = "TRY",           // TRY, USD, EUR
    val description: String = "",
    val source: String = "manual",          // manual, notification, sms
    val matchedKeyword: String? = null,     // Hangi keyword eşleşti
    val rawNotification: String? = null,    // Orijinal bildirim metni
    val isConfirmed: Boolean = true,        // Otomatik yakalananlar false olabilir
    val year: Int,
    val month: Int,                         // 1-12
    val day: Int,
    val createdAt: Long = System.currentTimeMillis()
)
