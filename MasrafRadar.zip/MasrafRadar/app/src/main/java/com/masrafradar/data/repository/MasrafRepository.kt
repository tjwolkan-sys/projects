package com.masrafradar.data.repository

import com.masrafradar.data.dao.*
import com.masrafradar.data.entity.*
import kotlinx.coroutines.flow.Flow

class MasrafRepository(
    private val categoryDao: CategoryDao,
    private val subCategoryDao: SubCategoryDao,
    private val keywordDao: KeywordDao,
    private val expenseDao: ExpenseDao
) {
    // ── Categories ──
    val allCategoriesWithSubs: Flow<List<CategoryWithSubs>> = categoryDao.getAllWithSubs()
    val allCategories: Flow<List<Category>> = categoryDao.getAll()
    suspend fun insertCategory(cat: Category) = categoryDao.insert(cat)
    suspend fun updateCategory(cat: Category) = categoryDao.update(cat)
    suspend fun deleteCategory(cat: Category) = categoryDao.delete(cat)

    // ── SubCategories ──
    fun getSubsByCategory(catId: Long) = subCategoryDao.getByCategory(catId)
    suspend fun getAllSubs() = subCategoryDao.getAll()
    suspend fun insertSubCategory(sub: SubCategory) = subCategoryDao.insert(sub)
    suspend fun updateSubCategory(sub: SubCategory) = subCategoryDao.update(sub)
    suspend fun deleteSubCategory(sub: SubCategory) = subCategoryDao.delete(sub)

    // ── Keywords ──
    val allKeywords: Flow<List<Keyword>> = keywordDao.getAll()
    suspend fun getAllActiveKeywords() = keywordDao.getAllActive()
    fun getKeywordsBySub(subId: Long) = keywordDao.getBySubCategory(subId)
    suspend fun insertKeyword(kw: Keyword) = keywordDao.insert(kw)
    suspend fun updateKeyword(kw: Keyword) = keywordDao.update(kw)
    suspend fun deleteKeyword(kw: Keyword) = keywordDao.delete(kw)

    // ── Expenses ──
    fun getExpensesByMonth(year: Int, month: Int) = expenseDao.getByMonth(year, month)
    fun getRecentExpenses(limit: Int = 20) = expenseDao.getRecent(limit)
    fun getPendingExpenses() = expenseDao.getPendingConfirmation()
    fun getMonthlyTotal(year: Int, month: Int) = expenseDao.getMonthlyTotal(year, month)
    fun getCategoryTotals(year: Int, month: Int) = expenseDao.getCategoryTotals(year, month)
    fun getMonthlyTotals() = expenseDao.getMonthlyTotals()
    suspend fun insertExpense(expense: Expense) = expenseDao.insert(expense)
    suspend fun updateExpense(expense: Expense) = expenseDao.update(expense)
    suspend fun deleteExpense(expense: Expense) = expenseDao.delete(expense)
}
