package com.masrafradar.data.dao

import androidx.room.*
import com.masrafradar.data.entity.CategoryTotal
import com.masrafradar.data.entity.Expense
import com.masrafradar.data.entity.ExpenseWithCategory
import com.masrafradar.data.entity.MonthlyTotal
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {
    @Query("""
        SELECT e.*, c.name AS categoryName, sc.name AS subCategoryName, c.colorHex AS categoryColor
        FROM expenses e
        LEFT JOIN sub_categories sc ON e.subCategoryId = sc.id
        LEFT JOIN categories c ON sc.categoryId = c.id
        WHERE e.year = :year AND e.month = :month
        ORDER BY e.createdAt DESC
    """)
    fun getByMonth(year: Int, month: Int): Flow<List<ExpenseWithCategory>>

    @Query("""
        SELECT e.*, c.name AS categoryName, sc.name AS subCategoryName, c.colorHex AS categoryColor
        FROM expenses e
        LEFT JOIN sub_categories sc ON e.subCategoryId = sc.id
        LEFT JOIN categories c ON sc.categoryId = c.id
        ORDER BY e.createdAt DESC
        LIMIT :limit
    """)
    fun getRecent(limit: Int = 20): Flow<List<ExpenseWithCategory>>

    @Query("""
        SELECT e.*, c.name AS categoryName, sc.name AS subCategoryName, c.colorHex AS categoryColor
        FROM expenses e
        LEFT JOIN sub_categories sc ON e.subCategoryId = sc.id
        LEFT JOIN categories c ON sc.categoryId = c.id
        WHERE e.isConfirmed = 0
        ORDER BY e.createdAt DESC
    """)
    fun getPendingConfirmation(): Flow<List<ExpenseWithCategory>>

    @Query("SELECT SUM(amount) FROM expenses WHERE year = :year AND month = :month AND isConfirmed = 1")
    fun getMonthlyTotal(year: Int, month: Int): Flow<Double?>

    @Query("""
        SELECT c.id AS categoryId, c.name AS categoryName, c.colorHex, SUM(e.amount) AS total
        FROM expenses e
        JOIN sub_categories sc ON e.subCategoryId = sc.id
        JOIN categories c ON sc.categoryId = c.id
        WHERE e.year = :year AND e.month = :month AND e.isConfirmed = 1
        GROUP BY c.id
        ORDER BY total DESC
    """)
    fun getCategoryTotals(year: Int, month: Int): Flow<List<CategoryTotal>>

    @Query("""
        SELECT year, month, SUM(amount) AS total
        FROM expenses WHERE isConfirmed = 1
        GROUP BY year, month
        ORDER BY year DESC, month DESC
        LIMIT 12
    """)
    fun getMonthlyTotals(): Flow<List<MonthlyTotal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(expense: Expense): Long

    @Update
    suspend fun update(expense: Expense)

    @Delete
    suspend fun delete(expense: Expense)
}
