package com.masrafradar

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.masrafradar.ui.navigation.Screen
import com.masrafradar.ui.navigation.bottomNavItems
import com.masrafradar.ui.screens.*
import com.masrafradar.ui.theme.MasrafRadarTheme
import com.masrafradar.viewmodel.MainViewModel
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MasrafRadarTheme { MainApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(vm: MainViewModel = viewModel()) {
    val navController = rememberNavController()
    val navEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navEntry?.destination?.route

    val dashState by vm.dashboardState.collectAsState()
    val catsWithSubs by vm.allCategoriesWithSubs.collectAsState()
    val pending by vm.pendingExpenses.collectAsState()

    val context = LocalContext.current
    LaunchedEffect(Unit) {
        vm.toast.collectLatest { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(bottomNavItems.find { it.route == currentRoute }?.title ?: "Masraf Radar") },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            NavigationBar {
                bottomNavItems.forEach { screen ->
                    NavigationBarItem(
                        icon = {
                            if (screen == Screen.Expenses && pending.isNotEmpty()) {
                                BadgedBox(badge = { Badge { Text("${pending.size}") } }) {
                                    Icon(screen.icon, screen.title)
                                }
                            } else {
                                Icon(screen.icon, screen.title)
                            }
                        },
                        label = { Text(screen.title) },
                        selected = currentRoute == screen.route,
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.startDestinationId) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(navController, Screen.Dashboard.route, Modifier.padding(innerPadding)) {
            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    state = dashState,
                    categories = catsWithSubs,
                    onAddExpense = vm::addExpense,
                    onSetMonth = vm::setMonth
                )
            }
            composable(Screen.Expenses.route) {
                ExpensesScreen(
                    state = dashState,
                    pendingExpenses = pending,
                    onConfirm = vm::confirmExpense,
                    onDelete = { vm.deleteExpense(it) },
                    onUpdateAmount = vm::updateExpenseAmount
                )
            }
            composable(Screen.Categories.route) {
                CategoriesScreen(
                    categoriesWithSubs = catsWithSubs,
                    onAddCategory = vm::addCategory,
                    onDeleteCategory = vm::deleteCategory,
                    onAddSubCategory = vm::addSubCategory,
                    onDeleteSubCategory = vm::deleteSubCategory,
                    onAddKeyword = vm::addKeyword,
                    onDeleteKeyword = vm::deleteKeyword,
                    onToggleKeyword = vm::toggleKeyword
                )
            }
            composable(Screen.Settings.route) {
                SettingsScreen()
            }
        }
    }
}
