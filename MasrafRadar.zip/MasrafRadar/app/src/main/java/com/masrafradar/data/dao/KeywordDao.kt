package com.masrafradar.data.dao

import androidx.room.*
import com.masrafradar.data.entity.Keyword
import kotlinx.coroutines.flow.Flow

@Dao
interface KeywordDao {
    @Query("SELECT * FROM keywords WHERE isActive = 1 ORDER BY keyword ASC")
    suspend fun getAllActive(): List<Keyword>

    @Query("SELECT * FROM keywords WHERE subCategoryId = :subCategoryId ORDER BY keyword ASC")
    fun getBySubCategory(subCategoryId: Long): Flow<List<Keyword>>

    @Query("SELECT * FROM keywords ORDER BY keyword ASC")
    fun getAll(): Flow<List<Keyword>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(keyword: Keyword): Long

    @Update
    suspend fun update(keyword: Keyword)

    @Delete
    suspend fun delete(keyword: Keyword)
}
