package com.masrafradar.data.dao

import androidx.room.*
import com.masrafradar.data.entity.SubCategory
import com.masrafradar.data.entity.SubCategoryWithKeywords
import kotlinx.coroutines.flow.Flow

@Dao
interface SubCategoryDao {
    @Transaction
    @Query("SELECT * FROM sub_categories WHERE categoryId = :categoryId ORDER BY name ASC")
    fun getByCategoryWithKeywords(categoryId: Long): Flow<List<SubCategoryWithKeywords>>

    @Query("SELECT * FROM sub_categories WHERE categoryId = :categoryId ORDER BY name ASC")
    fun getByCategory(categoryId: Long): Flow<List<SubCategory>>

    @Query("SELECT * FROM sub_categories ORDER BY name ASC")
    suspend fun getAll(): List<SubCategory>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(subCategory: SubCategory): Long

    @Update
    suspend fun update(subCategory: SubCategory)

    @Delete
    suspend fun delete(subCategory: SubCategory)
}
