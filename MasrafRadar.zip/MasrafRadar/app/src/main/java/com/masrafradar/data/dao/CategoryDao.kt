package com.masrafradar.data.dao

import androidx.room.*
import com.masrafradar.data.entity.Category
import com.masrafradar.data.entity.CategoryWithSubs
import kotlinx.coroutines.flow.Flow

@Dao
interface CategoryDao {
    @Transaction
    @Query("SELECT * FROM categories ORDER BY sortOrder ASC, name ASC")
    fun getAllWithSubs(): Flow<List<CategoryWithSubs>>

    @Query("SELECT * FROM categories ORDER BY sortOrder ASC, name ASC")
    fun getAll(): Flow<List<Category>>

    @Query("SELECT * FROM categories WHERE id = :id")
    suspend fun getById(id: Long): Category?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: Category): Long

    @Update
    suspend fun update(category: Category)

    @Delete
    suspend fun delete(category: Category)
}
