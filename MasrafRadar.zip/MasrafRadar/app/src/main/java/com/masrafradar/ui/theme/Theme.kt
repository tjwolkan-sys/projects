package com.masrafradar.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

val Green600 = Color(0xFF43A047)
val Red600 = Color(0xFFE53935)
val Amber600 = Color(0xFFFFB300)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF1565C0),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD1E4FF),
    secondary = Color(0xFF43A047),
    tertiary = Color(0xFFFF9800),
    surface = Color(0xFFFDFBFF),
    background = Color(0xFFF5F5F5),
    error = Color(0xFFE53935),
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF90CAF9),
    onPrimary = Color(0xFF003258),
    primaryContainer = Color(0xFF1565C0),
    secondary = Color(0xFFA5D6A7),
    tertiary = Color(0xFFFFCC80),
    surface = Color(0xFF1A1C1E),
    background = Color(0xFF121212),
    error = Color(0xFFEF9A9A),
)

@Composable
fun MasrafRadarTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val colorScheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val ctx = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }
    MaterialTheme(colorScheme = colorScheme, typography = Typography(), content = content)
}
