package com.masrafradar.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.masrafradar.data.entity.*
import com.masrafradar.ui.components.AddCategoryDialog
import com.masrafradar.ui.components.SimpleInputDialog

@Composable
fun CategoriesScreen(
    categoriesWithSubs: List<CategoryWithSubs>,
    onAddCategory: (String, String) -> Unit,
    onDeleteCategory: (Category) -> Unit,
    onAddSubCategory: (Long, String) -> Unit,
    onDeleteSubCategory: (SubCategory) -> Unit,
    onAddKeyword: (Long, String) -> Unit,
    onDeleteKeyword: (Keyword) -> Unit,
    onToggleKeyword: (Keyword) -> Unit
) {
    var showAddCat by remember { mutableStateOf(false) }
    var addSubTarget by remember { mutableStateOf<Long?>(null) }
    var addKwTarget by remember { mutableStateOf<Long?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddCat = true }) {
                Icon(Icons.Default.Add, "Kategori Ekle")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            item {
                Text("Kategoriler ve Keyword'ler",
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text("Keyword'ler bildirimlerde otomatik eşleştirilir",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            items(categoriesWithSubs, key = { it.category.id }) { cws ->
                CategoryCard(
                    cws = cws,
                    onDeleteCategory = { onDeleteCategory(cws.category) },
                    onAddSubCategory = { addSubTarget = cws.category.id },
                    onDeleteSubCategory = onDeleteSubCategory,
                    onAddKeyword = { subId -> addKwTarget = subId },
                    onDeleteKeyword = onDeleteKeyword,
                    onToggleKeyword = onToggleKeyword
                )
            }

            if (categoriesWithSubs.isEmpty()) {
                item {
                    Card(modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            Text("Kategori yok — + ile ekleyin",
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    if (showAddCat) {
        AddCategoryDialog(
            onDismiss = { showAddCat = false },
            onConfirm = onAddCategory
        )
    }

    addSubTarget?.let { catId ->
        SimpleInputDialog(
            title = "Alt Kategori Ekle",
            label = "Ad",
            placeholder = "Örn: Elektrik",
            onDismiss = { addSubTarget = null },
            onConfirm = { name -> onAddSubCategory(catId, name) }
        )
    }

    addKwTarget?.let { subId ->
        SimpleInputDialog(
            title = "Keyword Ekle",
            label = "Keyword",
            placeholder = "Örn: AYEDAŞ",
            onDismiss = { addKwTarget = null },
            onConfirm = { kw -> onAddKeyword(subId, kw) }
        )
    }
}

@Composable
private fun CategoryCard(
    cws: CategoryWithSubs,
    onDeleteCategory: () -> Unit,
    onAddSubCategory: () -> Unit,
    onDeleteSubCategory: (SubCategory) -> Unit,
    onAddKeyword: (Long) -> Unit,
    onDeleteKeyword: (Keyword) -> Unit,
    onToggleKeyword: (Keyword) -> Unit
) {
    val cat = cws.category
    var expanded by remember { mutableStateOf(false) }
    var showDeleteCat by remember { mutableStateOf(false) }
    val color = try { Color(android.graphics.Color.parseColor(cat.colorHex)) } catch (_: Exception) { Color.Gray }

    ElevatedCard(modifier = Modifier.fillMaxWidth().animateContentSize()) {
        Column {
            // Category Header
            Row(
                modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(color))
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(cat.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    val kwCount = cws.subCategories.sumOf { it.keywords.size }
                    Text(
                        "${cws.subCategories.size} alt kategori · $kwCount keyword",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = { showDeleteCat = true }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, "Sil", modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.width(4.dp))
                Icon(
                    if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    "Aç/Kapat",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Expanded Content
            if (expanded) {
                HorizontalDivider()
                cws.subCategories.forEach { sws ->
                    SubCategorySection(
                        sws = sws,
                        color = color,
                        onDelete = { onDeleteSubCategory(sws.subCategory) },
                        onAddKeyword = { onAddKeyword(sws.subCategory.id) },
                        onDeleteKeyword = onDeleteKeyword,
                        onToggleKeyword = onToggleKeyword
                    )
                }
                // Add SubCategory button
                TextButton(
                    onClick = onAddSubCategory,
                    modifier = Modifier.padding(start = 16.dp, bottom = 8.dp)
                ) {
                    Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Alt Kategori Ekle")
                }
            }
        }
    }

    if (showDeleteCat) {
        AlertDialog(
            onDismissRequest = { showDeleteCat = false },
            title = { Text("Kategori Sil") },
            text = { Text("'${cat.name}' ve tüm alt kategorileri/keyword'leri silinecek.") },
            confirmButton = {
                Button(onClick = { onDeleteCategory(); showDeleteCat = false },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Sil") }
            },
            dismissButton = { TextButton(onClick = { showDeleteCat = false }) { Text("İptal") } }
        )
    }
}

@Composable
private fun SubCategorySection(
    sws: SubCategoryWithKeywords,
    color: Color,
    onDelete: () -> Unit,
    onAddKeyword: () -> Unit,
    onDeleteKeyword: (Keyword) -> Unit,
    onToggleKeyword: (Keyword) -> Unit
) {
    Column(modifier = Modifier.padding(start = 32.dp, end = 16.dp, top = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(sws.subCategory.name, style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            IconButton(onClick = onAddKeyword, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Add, "Keyword Ekle", modifier = Modifier.size(16.dp), tint = color)
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, "Sil", modifier = Modifier.size(14.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Keywords as chips
        if (sws.keywords.isNotEmpty()) {
            FlowRow(
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                sws.keywords.forEach { kw ->
                    FilterChip(
                        selected = kw.isActive,
                        onClick = { onToggleKeyword(kw) },
                        label = { Text(kw.keyword, style = MaterialTheme.typography.labelSmall) },
                        trailingIcon = {
                            Icon(
                                Icons.Default.Close, "Sil",
                                modifier = Modifier.size(14.dp).clickable { onDeleteKeyword(kw) }
                            )
                        },
                        modifier = Modifier.height(30.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FlowRow(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top,
    content: @Composable () -> Unit
) {
    androidx.compose.foundation.layout.FlowRow(
        modifier = modifier,
        horizontalArrangement = horizontalArrangement,
        verticalArrangement = verticalArrangement,
        content = { content() }
    )
}
