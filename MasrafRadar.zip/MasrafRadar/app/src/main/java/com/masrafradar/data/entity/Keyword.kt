package com.masrafradar.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "keywords",
    foreignKeys = [ForeignKey(
        entity = SubCategory::class,
        parentColumns = ["id"],
        childColumns = ["subCategoryId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("subCategoryId")]
)
data class Keyword(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subCategoryId: Long,
    val keyword: String,             // Bildirimde aranacak kelime (ör: "ZES", "Netflix")
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
