#!/bin/bash
# ╔══════════════════════════════════════════════════════════════════╗
# ║   Yatırım Takip - APK Derleme Scripti                          ║
# ║   Bu scripti bilgisayarınızda proje klasörünün içinde çalıştırın║
# ╚══════════════════════════════════════════════════════════════════╝

set -e

echo "========================================="
echo "  Yatırım Takip - APK Builder"
echo "========================================="
echo ""

# ── 1. Java kontrolü ──
if ! command -v java &> /dev/null; then
    echo "❌ Java bulunamadı. JDK 17+ kurulu olmalı."
    echo "   İndirin: https://adoptium.net/temurin/releases/"
    exit 1
fi

JAVA_VER=$(java -version 2>&1 | head -1 | cut -d'"' -f2 | cut -d'.' -f1)
echo "✅ Java $JAVA_VER bulundu"

# ── 2. Android SDK kontrolü ──
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
    # Yaygın konumları kontrol et
    if [ -d "$HOME/Android/Sdk" ]; then
        export ANDROID_HOME="$HOME/Android/Sdk"
    elif [ -d "$HOME/Library/Android/sdk" ]; then
        export ANDROID_HOME="$HOME/Library/Android/sdk"
    elif [ -d "/usr/local/lib/android/sdk" ]; then
        export ANDROID_HOME="/usr/local/lib/android/sdk"
    else
        echo "❌ Android SDK bulunamadı."
        echo "   Android Studio kurun: https://developer.android.com/studio"
        echo "   Veya ANDROID_HOME ortam değişkenini ayarlayın."
        exit 1
    fi
fi

SDK_PATH="${ANDROID_HOME:-$ANDROID_SDK_ROOT}"
echo "✅ Android SDK: $SDK_PATH"

# ── 3. local.properties oluştur ──
echo "sdk.dir=$SDK_PATH" > local.properties
echo "✅ local.properties oluşturuldu"

# ── 4. Gradle Wrapper kontrolü ──
if [ ! -f "gradlew" ]; then
    echo "📥 Gradle wrapper oluşturuluyor..."
    if command -v gradle &> /dev/null; then
        gradle wrapper --gradle-version 8.9
    else
        echo "❌ Gradle wrapper bulunamadı. Android Studio'dan projeyi açın."
        exit 1
    fi
fi

chmod +x gradlew

# ── 5. Derleme ──
echo ""
echo "🔨 APK derleniyor (bu biraz sürebilir)..."
echo ""
./gradlew assembleDebug --no-daemon

# ── 6. APK konumu ──
APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
    SIZE=$(du -h "$APK_PATH" | cut -f1)
    echo ""
    echo "========================================="
    echo "  ✅ APK BAŞARIYLA OLUŞTURULDU!"
    echo "========================================="
    echo "  📁 Konum: $APK_PATH"
    echo "  📦 Boyut: $SIZE"
    echo ""
    echo "  Telefonunuza kurmak için:"
    echo "  adb install $APK_PATH"
    echo ""
    echo "  Veya APK dosyasını telefonunuza"
    echo "  kopyalayıp doğrudan açın."
    echo "========================================="
else
    echo "❌ APK oluşturulamadı. Hata mesajlarını kontrol edin."
    exit 1
fi
