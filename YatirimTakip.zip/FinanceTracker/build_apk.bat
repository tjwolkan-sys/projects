@echo off
chcp 65001 >nul
echo =========================================
echo   Yatirim Takip - APK Builder (Windows)
echo =========================================
echo.

REM Java kontrolu
java -version 2>nul
if errorlevel 1 (
    echo [HATA] Java bulunamadi. JDK 17+ kurulu olmali.
    echo Indirin: https://adoptium.net/temurin/releases/
    pause
    exit /b 1
)
echo [OK] Java bulundu

REM Android SDK kontrolu
if "%ANDROID_HOME%"=="" (
    if exist "%LOCALAPPDATA%\Android\Sdk" (
        set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
    ) else if exist "%USERPROFILE%\AppData\Local\Android\Sdk" (
        set "ANDROID_HOME=%USERPROFILE%\AppData\Local\Android\Sdk"
    ) else (
        echo [HATA] Android SDK bulunamadi.
        echo ANDROID_HOME ortam degiskenini ayarlayin.
        pause
        exit /b 1
    )
)
echo [OK] Android SDK: %ANDROID_HOME%

REM local.properties olustur
echo sdk.dir=%ANDROID_HOME:\=/% > local.properties
echo [OK] local.properties olusturuldu

REM Derleme
echo.
echo Derleniyor... (bu biraz surebilir)
echo.
call gradlew.bat assembleDebug --no-daemon

if exist "app\build\outputs\apk\debug\app-debug.apk" (
    echo.
    echo =========================================
    echo   APK BASARIYLA OLUSTURULDU!
    echo =========================================
    echo   Konum: app\build\outputs\apk\debug\app-debug.apk
    echo.
    echo   Telefonunuza kurmak icin:
    echo   adb install app\build\outputs\apk\debug\app-debug.apk
    echo =========================================
) else (
    echo [HATA] APK olusturulamadi.
)
pause
