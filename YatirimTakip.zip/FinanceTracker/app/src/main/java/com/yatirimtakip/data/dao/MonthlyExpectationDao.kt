package com.yatirimtakip.data.dao

import androidx.room.*
import com.yatirimtakip.data.entity.MonthlyExpectation
import kotlinx.coroutines.flow.Flow

@Dao
interface MonthlyExpectationDao {
    @Query("SELECT * FROM monthly_expectations WHERE year = :year AND month = :month LIMIT 1")
    suspend fun getExpectation(year: Int, month: Int): MonthlyExpectation?

    @Query("SELECT * FROM monthly_expectations WHERE year = :year AND month = :month LIMIT 1")
    fun getExpectationFlow(year: Int, month: Int): Flow<MonthlyExpectation?>

    @Query("SELECT * FROM monthly_expectations ORDER BY year DESC, month DESC")
    fun getAllExpectations(): Flow<List<MonthlyExpectation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpectation(expectation: MonthlyExpectation): Long

    @Update
    suspend fun updateExpectation(expectation: MonthlyExpectation)
}
