package com.yatirimtakip.data.dao

import androidx.room.*
import com.yatirimtakip.data.entity.MonthlySnapshot
import kotlinx.coroutines.flow.Flow

@Dao
interface MonthlySnapshotDao {
    @Query("SELECT * FROM monthly_snapshots ORDER BY year DESC, month DESC")
    fun getAllSnapshots(): Flow<List<MonthlySnapshot>>

    @Query("SELECT * FROM monthly_snapshots WHERE year = :year AND month = :month LIMIT 1")
    suspend fun getSnapshot(year: Int, month: Int): MonthlySnapshot?

    @Query("SELECT * FROM monthly_snapshots ORDER BY year DESC, month DESC LIMIT 1")
    suspend fun getLatestSnapshot(): MonthlySnapshot?

    @Query("SELECT * FROM monthly_snapshots ORDER BY year DESC, month DESC LIMIT 1")
    fun getLatestSnapshotFlow(): Flow<MonthlySnapshot?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(snapshot: MonthlySnapshot): Long

    @Delete
    suspend fun deleteSnapshot(snapshot: MonthlySnapshot)
}
