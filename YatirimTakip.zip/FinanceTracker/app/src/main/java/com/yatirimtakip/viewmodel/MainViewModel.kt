package com.yatirimtakip.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yatirimtakip.App
import com.yatirimtakip.data.entity.Asset
import com.yatirimtakip.data.entity.MonthlyExpectation
import com.yatirimtakip.data.entity.MonthlySnapshot
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

data class DashboardState(
    val assets: List<Asset> = emptyList(),
    val totalBalance: Double = 0.0,
    val totalDeposited: Double = 0.0,
    val cumulativeProfit: Double = 0.0,
    val cumulativeProfitRate: Double = 0.0,
    val latestSnapshot: MonthlySnapshot? = null,
    val isLoading: Boolean = true
)

data class ClosingState(
    val snapshots: List<MonthlySnapshot> = emptyList(),
    val currentExpectation: MonthlyExpectation? = null,
    val currentYear: Int = Calendar.getInstance().get(Calendar.YEAR),
    val currentMonth: Int = Calendar.getInstance().get(Calendar.MONTH) + 1,
    val isLoading: Boolean = true
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as App).repository

    // ── Dashboard State ──
    private val _dashboardState = MutableStateFlow(DashboardState())
    val dashboardState: StateFlow<DashboardState> = _dashboardState.asStateFlow()

    // ── Closing State ──
    private val _closingState = MutableStateFlow(ClosingState())
    val closingState: StateFlow<ClosingState> = _closingState.asStateFlow()

    // ── UI Events ──
    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage: SharedFlow<String> = _toastMessage.asSharedFlow()

    init {
        observeDashboard()
        observeClosing()
    }

    private fun observeDashboard() {
        viewModelScope.launch {
            combine(
                repository.allAssets,
                repository.totalBalance,
                repository.totalDeposited,
                repository.latestSnapshot
            ) { assets, balance, deposited, snapshot ->
                val bal = balance ?: 0.0
                val dep = deposited ?: 0.0
                val profit = bal - dep
                val rate = if (dep > 0) (profit / dep) * 100 else 0.0
                DashboardState(
                    assets = assets,
                    totalBalance = bal,
                    totalDeposited = dep,
                    cumulativeProfit = profit,
                    cumulativeProfitRate = rate,
                    latestSnapshot = snapshot,
                    isLoading = false
                )
            }.collect { _dashboardState.value = it }
        }
    }

    private fun observeClosing() {
        viewModelScope.launch {
            repository.allSnapshots.collect { snapshots ->
                val cal = Calendar.getInstance()
                val year = cal.get(Calendar.YEAR)
                val month = cal.get(Calendar.MONTH) + 1
                val expectation = repository.getExpectation(year, month)
                _closingState.value = ClosingState(
                    snapshots = snapshots,
                    currentExpectation = expectation,
                    currentYear = year,
                    currentMonth = month,
                    isLoading = false
                )
            }
        }
    }

    // ── Asset Operations ──
    fun addAsset(institutionName: String, investmentType: String, amount: Double) {
        viewModelScope.launch {
            repository.insertAsset(
                Asset(
                    institutionName = institutionName.trim(),
                    investmentType = investmentType.trim(),
                    currentBalance = amount,
                    totalDeposited = amount
                )
            )
            _toastMessage.emit("Varlık eklendi")
        }
    }

    fun updateAssetBalance(asset: Asset, newBalance: Double, additionalDeposit: Double) {
        viewModelScope.launch {
            repository.updateAsset(
                asset.copy(
                    currentBalance = newBalance,
                    totalDeposited = asset.totalDeposited + additionalDeposit
                )
            )
            _toastMessage.emit("Bakiye güncellendi")
        }
    }

    fun deleteAsset(asset: Asset) {
        viewModelScope.launch {
            repository.deleteAsset(asset)
            _toastMessage.emit("Varlık silindi")
        }
    }

    // ── Expectation Operations ──
    fun setExpectation(year: Int, month: Int, expectedProfit: Double, expectedRate: Double) {
        viewModelScope.launch {
            val currentBalance = _dashboardState.value.totalBalance
            repository.insertExpectation(
                MonthlyExpectation(
                    year = year,
                    month = month,
                    expectedProfit = expectedProfit,
                    expectedRate = expectedRate,
                    startingBalance = currentBalance
                )
            )
            // Refresh closing state
            _closingState.value = _closingState.value.copy(
                currentExpectation = repository.getExpectation(year, month)
            )
            _toastMessage.emit("Beklenti kaydedildi")
        }
    }

    // ── Monthly Closing ──
    fun closeMonth(year: Int, month: Int, newDeposit: Double) {
        viewModelScope.launch {
            val currentTotalBalance = _dashboardState.value.totalBalance
            val currentTotalDeposited = _dashboardState.value.totalDeposited

            // Önceki snapshot'tan bilgi al
            val previousSnapshot = repository.getLatestSnapshot()
            val previousBalance = previousSnapshot?.totalBalance ?: currentTotalDeposited

            // Aylık net kar = Mevcut bakiye - Önceki bakiye - Bu ay eklenen yeni para
            val monthlyProfit = currentTotalBalance - previousBalance - newDeposit

            // Önceki bakiye üzerinden aylık kar oranı
            val monthlyProfitRate = if (previousBalance > 0) {
                (monthlyProfit / previousBalance) * 100
            } else 0.0

            // Kümülatif kar
            val cumulativeProfit = currentTotalBalance - currentTotalDeposited

            // Beklenti karşılaştırması
            val expectation = repository.getExpectation(year, month)
            val expectedProfit = expectation?.expectedProfit ?: 0.0
            val expectedRate = expectation?.expectedRate ?: 0.0
            val achievementRate = if (expectedProfit > 0) {
                (monthlyProfit / expectedProfit) * 100
            } else if (monthlyProfit > 0) 100.0 else 0.0

            val snapshot = MonthlySnapshot(
                year = year,
                month = month,
                totalBalance = currentTotalBalance,
                totalDeposited = currentTotalDeposited,
                cumulativeProfit = cumulativeProfit,
                monthlyProfit = monthlyProfit,
                monthlyProfitRate = monthlyProfitRate,
                expectedProfit = expectedProfit,
                expectedRate = expectedRate,
                achievementRate = achievementRate,
                newDeposit = newDeposit
            )

            repository.insertSnapshot(snapshot)
            _toastMessage.emit("$month/$year dönemi kapatıldı")
        }
    }

    fun deleteSnapshot(snapshot: MonthlySnapshot) {
        viewModelScope.launch {
            repository.deleteSnapshot(snapshot)
            _toastMessage.emit("Dönem kaydı silindi")
        }
    }
}
