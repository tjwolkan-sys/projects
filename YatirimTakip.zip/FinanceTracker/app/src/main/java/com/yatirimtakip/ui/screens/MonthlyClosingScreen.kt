package com.yatirimtakip.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.yatirimtakip.ui.components.Formatter
import com.yatirimtakip.ui.theme.Green600
import com.yatirimtakip.ui.theme.Red600
import com.yatirimtakip.ui.theme.Amber700
import com.yatirimtakip.viewmodel.ClosingState
import com.yatirimtakip.viewmodel.DashboardState

@Composable
fun MonthlyClosingScreen(
    closingState: ClosingState,
    dashboardState: DashboardState,
    onSetExpectation: (Int, Int, Double, Double) -> Unit,
    onCloseMonth: (Int, Int, Double) -> Unit
) {
    var showExpectationDialog by remember { mutableStateOf(false) }
    var showClosingDialog by remember { mutableStateOf(false) }

    val year = closingState.currentYear
    val month = closingState.currentMonth
    val monthName = Formatter.monthName(month)
    val expectation = closingState.currentExpectation

    // En son snapshot varsa, beklenti ile karşılaştırma bilgileri
    val latestSnapshot = closingState.snapshots.firstOrNull()
    val isCurrentMonthClosed = latestSnapshot != null &&
            latestSnapshot.year == year && latestSnapshot.month == month

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // ── Current Period Header ──
        item {
            Text(
                "$monthName $year",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }

        // ── Expectation Card ──
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.elevatedCardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Flag,
                                contentDescription = null,
                                tint = Amber700,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Ay Başı Beklenti",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        if (expectation == null) {
                            FilledTonalButton(onClick = { showExpectationDialog = true }) {
                                Text("Belirle", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    if (expectation != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            InfoColumn("Hedef Kar", Formatter.currency(expectation.expectedProfit))
                            InfoColumn("Hedef Oran", Formatter.percent(expectation.expectedRate))
                            InfoColumn("Başlangıç", Formatter.currency(expectation.startingBalance))
                        }
                    } else {
                        Text(
                            "Henüz bu ay için beklenti belirlenmedi.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // ── Current Status Card ──
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Güncel Durum",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        InfoColumn(
                            "Toplam Bakiye",
                            Formatter.currency(dashboardState.totalBalance),
                            MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        InfoColumn(
                            "Ana Para",
                            Formatter.currency(dashboardState.totalDeposited),
                            MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        InfoColumn(
                            "Kümülatif Kar",
                            Formatter.currency(dashboardState.cumulativeProfit),
                            if (dashboardState.cumulativeProfit >= 0) Green600 else Red600
                        )
                    }
                }
            }
        }

        // ── Close Month Button ──
        item {
            if (!isCurrentMonthClosed) {
                Button(
                    onClick = { showClosingDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = dashboardState.assets.isNotEmpty()
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("$monthName Ayını Kapat")
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Green600
                        )
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                "$monthName ayı kapatıldı",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                "Aylık Kar: ${Formatter.currency(latestSnapshot!!.monthlyProfit)} (${Formatter.percent(latestSnapshot.monthlyProfitRate)})",
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (latestSnapshot.expectedProfit > 0) {
                                Text(
                                    "Hedefe Ulaşma: ${Formatter.percent(latestSnapshot.achievementRate)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (latestSnapshot.achievementRate >= 100) Green600 else Amber700
                                )
                            }
                        }
                    }
                }
            }
        }

        // ── Last 3 Snapshots ──
        if (closingState.snapshots.isNotEmpty()) {
            item {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Son Dönemler",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
            val recentSnapshots = closingState.snapshots.take(3)
            recentSnapshots.forEach { snap ->
                item {
                    SnapshotMiniCard(snap)
                }
            }
        }
    }

    // ── Expectation Dialog ──
    if (showExpectationDialog) {
        ExpectationDialog(
            monthName = monthName,
            year = year,
            currentBalance = dashboardState.totalBalance,
            onDismiss = { showExpectationDialog = false },
            onConfirm = { profit, rate ->
                onSetExpectation(year, month, profit, rate)
            }
        )
    }

    // ── Closing Dialog ──
    if (showClosingDialog) {
        ClosingDialog(
            monthName = monthName,
            year = year,
            onDismiss = { showClosingDialog = false },
            onConfirm = { newDeposit ->
                onCloseMonth(year, month, newDeposit)
            }
        )
    }
}

@Composable
private fun SnapshotMiniCard(snap: com.yatirimtakip.data.entity.MonthlySnapshot) {
    val profitColor = if (snap.monthlyProfit >= 0) Green600 else Red600
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    "${Formatter.monthName(snap.month)} ${snap.year}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    "Bakiye: ${Formatter.currency(snap.totalBalance)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    "${if (snap.monthlyProfit >= 0) "+" else ""}${Formatter.currency(snap.monthlyProfit)}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = profitColor
                )
                Text(
                    Formatter.percent(snap.monthlyProfitRate),
                    style = MaterialTheme.typography.bodySmall,
                    color = profitColor
                )
            }
        }
    }
}

@Composable
fun InfoColumn(label: String, value: String, valueColor: androidx.compose.ui.graphics.Color? = null) {
    Column {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color = valueColor ?: MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun ExpectationDialog(
    monthName: String,
    year: Int,
    currentBalance: Double,
    onDismiss: () -> Unit,
    onConfirm: (Double, Double) -> Unit
) {
    var profitStr by remember { mutableStateOf("") }
    var rateStr by remember { mutableStateOf("") }

    // Rate girildiğinde profit'i otomatik hesapla
    val autoProfit = rateStr.toDoubleOrNull()?.let { currentBalance * it / 100.0 }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("$monthName $year Beklentisi") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Mevcut bakiye: ${Formatter.currency(currentBalance)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = rateStr,
                    onValueChange = {
                        rateStr = it.filter { c -> c.isDigit() || c == '.' }
                        // Oran girildikçe miktarı güncelle
                        val rate = rateStr.toDoubleOrNull()
                        if (rate != null) {
                            profitStr = "%.0f".format(currentBalance * rate / 100.0)
                        }
                    },
                    label = { Text("Beklenen Kar Oranı (%)") },
                    placeholder = { Text("Örn: 3.5") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = profitStr,
                    onValueChange = { profitStr = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Beklenen Kar Miktarı (TL)") },
                    placeholder = { Text("Örn: 5000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val profit = profitStr.toDoubleOrNull() ?: 0.0
                val rate = rateStr.toDoubleOrNull() ?: 0.0
                if (profit > 0 || rate > 0) {
                    onConfirm(profit, rate)
                    onDismiss()
                }
            }) { Text("Kaydet") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}

@Composable
private fun ClosingDialog(
    monthName: String,
    year: Int,
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    var newDeposit by remember { mutableStateOf("0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.Lock, contentDescription = null) },
        title = { Text("$monthName $year Kapanışı") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Bu ay hesaplarınıza eklediğiniz toplam yeni para miktarını girin. Bakiyeler zaten varlık kartlarından güncel olmalı.",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = newDeposit,
                    onValueChange = { newDeposit = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Bu Ay Eklenen Yeni Para (TL)") },
                    supportingText = { Text("Yoksa 0 bırakın") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                onConfirm(newDeposit.toDoubleOrNull() ?: 0.0)
                onDismiss()
            }) { Text("Ayı Kapat") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}
