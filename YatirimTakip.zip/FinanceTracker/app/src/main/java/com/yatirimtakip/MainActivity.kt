package com.yatirimtakip

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.yatirimtakip.ui.navigation.Screen
import com.yatirimtakip.ui.navigation.bottomNavItems
import com.yatirimtakip.ui.screens.DashboardScreen
import com.yatirimtakip.ui.screens.HistoryScreen
import com.yatirimtakip.ui.screens.MonthlyClosingScreen
import com.yatirimtakip.ui.theme.YatirimTakipTheme
import com.yatirimtakip.viewmodel.MainViewModel
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            YatirimTakipTheme {
                MainApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(viewModel: MainViewModel = viewModel()) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val dashboardState by viewModel.dashboardState.collectAsState()
    val closingState by viewModel.closingState.collectAsState()

    // Toast messages
    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) {
        viewModel.toastMessage.collectLatest { message ->
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        bottomNavItems.find { it.route == currentRoute }?.title ?: "Yatırım Takip"
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar {
                bottomNavItems.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        selected = currentRoute == screen.route,
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.startDestinationId) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    state = dashboardState,
                    onAddAsset = viewModel::addAsset,
                    onUpdateBalance = viewModel::updateAssetBalance,
                    onDeleteAsset = viewModel::deleteAsset
                )
            }
            composable(Screen.MonthlyClosing.route) {
                MonthlyClosingScreen(
                    closingState = closingState,
                    dashboardState = dashboardState,
                    onSetExpectation = viewModel::setExpectation,
                    onCloseMonth = viewModel::closeMonth
                )
            }
            composable(Screen.History.route) {
                HistoryScreen(
                    closingState = closingState,
                    onDeleteSnapshot = viewModel::deleteSnapshot
                )
            }
        }
    }
}
