package com.yatirimtakip.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.yatirimtakip.data.entity.MonthlySnapshot
import com.yatirimtakip.ui.components.Formatter
import com.yatirimtakip.ui.theme.Amber700
import com.yatirimtakip.ui.theme.Green600
import com.yatirimtakip.ui.theme.Red600
import com.yatirimtakip.viewmodel.ClosingState

@Composable
fun HistoryScreen(
    closingState: ClosingState,
    onDeleteSnapshot: (MonthlySnapshot) -> Unit
) {
    val snapshots = closingState.snapshots

    if (snapshots.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.History,
                    contentDescription = null,
                    modifier = Modifier.size(64.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    "Henüz dönem kaydı yok",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Aylık kapanış yaptığınızda burada görünür",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item {
            Text(
                "Dönem Geçmişi",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }

        // ── Summary across all time ──
        item {
            val totalProfit = snapshots.sumOf { it.monthlyProfit }
            val avgRate = if (snapshots.isNotEmpty()) snapshots.map { it.monthlyProfitRate }.average() else 0.0
            val totalNewDeposits = snapshots.sumOf { it.newDeposit }

            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.elevatedCardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "Tüm Zamanlar Özeti",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        InfoColumn(
                            "Toplam Kar",
                            "${if (totalProfit >= 0) "+" else ""}${Formatter.currency(totalProfit)}",
                            if (totalProfit >= 0) Green600 else Red600
                        )
                        InfoColumn(
                            "Ort. Aylık Oran",
                            Formatter.percent(avgRate),
                            if (avgRate >= 0) Green600 else Red600
                        )
                        InfoColumn(
                            "Toplam Ek Yatırım",
                            Formatter.currency(totalNewDeposits)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "${snapshots.size} dönem kaydı",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // ── Snapshot Cards ──
        items(snapshots, key = { it.id }) { snapshot ->
            SnapshotDetailCard(
                snapshot = snapshot,
                onDelete = { onDeleteSnapshot(snapshot) }
            )
        }

        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun SnapshotDetailCard(
    snapshot: MonthlySnapshot,
    onDelete: () -> Unit
) {
    val profitColor = if (snapshot.monthlyProfit >= 0) Green600 else Red600
    var showDeleteDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${Formatter.monthName(snapshot.month)} ${snapshot.year}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = { showDeleteDialog = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Sil",
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Row 1: Bakiye ve Kar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                InfoColumn("Bakiye", Formatter.currency(snapshot.totalBalance))
                InfoColumn("Ana Para", Formatter.currency(snapshot.totalDeposited))
                InfoColumn(
                    "Aylık Kar",
                    "${if (snapshot.monthlyProfit >= 0) "+" else ""}${Formatter.currency(snapshot.monthlyProfit)}",
                    profitColor
                )
            }

            Spacer(Modifier.height(8.dp))

            // Row 2: Oranlar ve Beklenti
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                InfoColumn(
                    "Aylık Oran",
                    Formatter.percent(snapshot.monthlyProfitRate),
                    profitColor
                )
                InfoColumn(
                    "Kümülatif Kar",
                    "${if (snapshot.cumulativeProfit >= 0) "+" else ""}${Formatter.currency(snapshot.cumulativeProfit)}",
                    if (snapshot.cumulativeProfit >= 0) Green600 else Red600
                )
                if (snapshot.expectedProfit > 0) {
                    InfoColumn(
                        "Hedefe Ulaşma",
                        Formatter.percent(snapshot.achievementRate),
                        when {
                            snapshot.achievementRate >= 100 -> Green600
                            snapshot.achievementRate >= 75 -> Amber700
                            else -> Red600
                        }
                    )
                } else {
                    InfoColumn("Ek Yatırım", Formatter.currency(snapshot.newDeposit))
                }
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Dönem Kaydını Sil") },
            text = {
                Text("${Formatter.monthName(snapshot.month)} ${snapshot.year} dönemi silinecek. Emin misiniz?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDelete()
                        showDeleteDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Sil") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("İptal") }
            }
        )
    }
}
