package com.yatirimtakip.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "monthly_snapshots")
data class MonthlySnapshot(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val year: Int,
    val month: Int,                     // 1-12
    val totalBalance: Double,           // Ay sonu toplam bakiye
    val totalDeposited: Double,         // O ana kadar yatırılan toplam ana para
    val cumulativeProfit: Double,       // Kümülatif kar = totalBalance - totalDeposited
    val monthlyProfit: Double,          // Bu aya ait net kar
    val monthlyProfitRate: Double,      // Aylık kar oranı (%)
    val expectedProfit: Double,         // Ay başı beklenti (hedef kar)
    val expectedRate: Double,           // Beklenen oran (%)
    val achievementRate: Double,        // Hedefe ulaşma oranı (%)
    val newDeposit: Double,             // Bu ay eklenen yeni para
    val createdAt: Long = System.currentTimeMillis()
)
