package com.yatirimtakip.data.repository

import com.yatirimtakip.data.dao.AssetDao
import com.yatirimtakip.data.dao.MonthlyExpectationDao
import com.yatirimtakip.data.dao.MonthlySnapshotDao
import com.yatirimtakip.data.entity.Asset
import com.yatirimtakip.data.entity.MonthlyExpectation
import com.yatirimtakip.data.entity.MonthlySnapshot
import kotlinx.coroutines.flow.Flow

class FinanceRepository(
    private val assetDao: AssetDao,
    private val snapshotDao: MonthlySnapshotDao,
    private val expectationDao: MonthlyExpectationDao
) {
    // ── Assets ──
    val allAssets: Flow<List<Asset>> = assetDao.getAllAssets()
    val totalBalance: Flow<Double?> = assetDao.getTotalBalance()
    val totalDeposited: Flow<Double?> = assetDao.getTotalDeposited()

    suspend fun getAssetById(id: Long): Asset? = assetDao.getAssetById(id)

    suspend fun insertAsset(asset: Asset): Long = assetDao.insertAsset(asset)

    suspend fun updateAsset(asset: Asset) = assetDao.updateAsset(
        asset.copy(updatedAt = System.currentTimeMillis())
    )

    suspend fun deleteAsset(asset: Asset) = assetDao.deleteAsset(asset)

    // ── Snapshots ──
    val allSnapshots: Flow<List<MonthlySnapshot>> = snapshotDao.getAllSnapshots()
    val latestSnapshot: Flow<MonthlySnapshot?> = snapshotDao.getLatestSnapshotFlow()

    suspend fun getSnapshot(year: Int, month: Int): MonthlySnapshot? =
        snapshotDao.getSnapshot(year, month)

    suspend fun getLatestSnapshot(): MonthlySnapshot? =
        snapshotDao.getLatestSnapshot()

    suspend fun insertSnapshot(snapshot: MonthlySnapshot): Long =
        snapshotDao.insertSnapshot(snapshot)

    suspend fun deleteSnapshot(snapshot: MonthlySnapshot) =
        snapshotDao.deleteSnapshot(snapshot)

    // ── Expectations ──
    suspend fun getExpectation(year: Int, month: Int): MonthlyExpectation? =
        expectationDao.getExpectation(year, month)

    fun getExpectationFlow(year: Int, month: Int): Flow<MonthlyExpectation?> =
        expectationDao.getExpectationFlow(year, month)

    val allExpectations: Flow<List<MonthlyExpectation>> =
        expectationDao.getAllExpectations()

    suspend fun insertExpectation(expectation: MonthlyExpectation): Long =
        expectationDao.insertExpectation(expectation)

    suspend fun updateExpectation(expectation: MonthlyExpectation) =
        expectationDao.updateExpectation(expectation)
}
