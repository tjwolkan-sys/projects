package com.yatirimtakip.data.dao

import androidx.room.*
import com.yatirimtakip.data.entity.Asset
import kotlinx.coroutines.flow.Flow

@Dao
interface AssetDao {
    @Query("SELECT * FROM assets ORDER BY institutionName ASC")
    fun getAllAssets(): Flow<List<Asset>>

    @Query("SELECT SUM(currentBalance) FROM assets")
    fun getTotalBalance(): Flow<Double?>

    @Query("SELECT SUM(totalDeposited) FROM assets")
    fun getTotalDeposited(): Flow<Double?>

    @Query("SELECT * FROM assets WHERE id = :id")
    suspend fun getAssetById(id: Long): Asset?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAsset(asset: Asset): Long

    @Update
    suspend fun updateAsset(asset: Asset)

    @Delete
    suspend fun deleteAsset(asset: Asset)
}
