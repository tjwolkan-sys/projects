package com.yatirimtakip.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "monthly_expectations")
data class MonthlyExpectation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val year: Int,
    val month: Int,
    val expectedProfit: Double,      // Beklenen kar miktarı (TL)
    val expectedRate: Double,        // Beklenen kar oranı (%)
    val startingBalance: Double,     // Ay başı toplam bakiye
    val createdAt: Long = System.currentTimeMillis()
)
