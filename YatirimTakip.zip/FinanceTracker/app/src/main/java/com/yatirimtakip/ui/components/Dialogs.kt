package com.yatirimtakip.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.yatirimtakip.data.entity.Asset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddAssetDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, Double) -> Unit,
    editAsset: Asset? = null
) {
    var institution by remember { mutableStateOf(editAsset?.institutionName ?: "") }
    var type by remember { mutableStateOf(editAsset?.investmentType ?: "") }
    var amount by remember { mutableStateOf(editAsset?.currentBalance?.let { "%.0f".format(it) } ?: "") }
    var typeExpanded by remember { mutableStateOf(false) }
    val investmentTypes = listOf("Fon", "Mevduat", "BES", "Hisse", "Altın", "Döviz", "Kripto", "Diğer")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (editAsset == null) "Yeni Varlık Ekle" else "Varlık Düzenle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = institution,
                    onValueChange = { institution = it },
                    label = { Text("Banka / Kurum") },
                    placeholder = { Text("Örn: Denizbank") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                ExposedDropdownMenuBox(
                    expanded = typeExpanded,
                    onExpandedChange = { typeExpanded = it }
                ) {
                    OutlinedTextField(
                        value = type,
                        onValueChange = { type = it },
                        label = { Text("Yatırım Tipi") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        singleLine = true
                    )
                    ExposedDropdownMenu(
                        expanded = typeExpanded,
                        onDismissRequest = { typeExpanded = false }
                    ) {
                        investmentTypes.forEach { item ->
                            DropdownMenuItem(
                                text = { Text(item) },
                                onClick = {
                                    type = item
                                    typeExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Miktar (TL)") },
                    placeholder = { Text("Örn: 50000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amountVal = amount.toDoubleOrNull() ?: 0.0
                    if (institution.isNotBlank() && type.isNotBlank() && amountVal > 0) {
                        onConfirm(institution, type, amountVal)
                        onDismiss()
                    }
                }
            ) { Text("Kaydet") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}

@Composable
fun UpdateBalanceDialog(
    asset: Asset,
    onDismiss: () -> Unit,
    onConfirm: (Double, Double) -> Unit
) {
    var newBalance by remember { mutableStateOf("%.0f".format(asset.currentBalance)) }
    var additionalDeposit by remember { mutableStateOf("0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Bakiye Güncelle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "${asset.institutionName} - ${asset.investmentType}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = newBalance,
                    onValueChange = { newBalance = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Yeni Bakiye (TL)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = additionalDeposit,
                    onValueChange = { additionalDeposit = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Ek Yatırım (TL)") },
                    supportingText = { Text("Bu ay hesaba eklediğiniz yeni para") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val bal = newBalance.toDoubleOrNull() ?: 0.0
                val dep = additionalDeposit.toDoubleOrNull() ?: 0.0
                if (bal > 0) {
                    onConfirm(bal, dep)
                    onDismiss()
                }
            }) { Text("Güncelle") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}
