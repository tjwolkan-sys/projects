package com.yatirimtakip.ui.components

import java.text.NumberFormat
import java.util.Locale

object Formatter {
    private val trLocale = Locale("tr", "TR")
    private val currencyFormat = NumberFormat.getCurrencyInstance(trLocale).apply {
        maximumFractionDigits = 0
    }
    private val percentFormat = NumberFormat.getPercentInstance(trLocale).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
    }
    private val decimalFormat = NumberFormat.getNumberInstance(trLocale).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
    }

    fun currency(value: Double): String = currencyFormat.format(value)

    fun percent(value: Double): String = percentFormat.format(value / 100.0)

    fun decimal(value: Double): String = decimalFormat.format(value)

    fun monthName(month: Int): String = when (month) {
        1 -> "Ocak"; 2 -> "Şubat"; 3 -> "Mart"; 4 -> "Nisan"
        5 -> "Mayıs"; 6 -> "Haziran"; 7 -> "Temmuz"; 8 -> "Ağustos"
        9 -> "Eylül"; 10 -> "Ekim"; 11 -> "Kasım"; 12 -> "Aralık"
        else -> ""
    }
}
