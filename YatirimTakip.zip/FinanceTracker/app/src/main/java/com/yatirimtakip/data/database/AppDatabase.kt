package com.yatirimtakip.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.yatirimtakip.data.dao.AssetDao
import com.yatirimtakip.data.dao.MonthlyExpectationDao
import com.yatirimtakip.data.dao.MonthlySnapshotDao
import com.yatirimtakip.data.entity.Asset
import com.yatirimtakip.data.entity.MonthlyExpectation
import com.yatirimtakip.data.entity.MonthlySnapshot

@Database(
    entities = [Asset::class, MonthlySnapshot::class, MonthlyExpectation::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun assetDao(): AssetDao
    abstract fun monthlySnapshotDao(): MonthlySnapshotDao
    abstract fun monthlyExpectationDao(): MonthlyExpectationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "yatirim_takip_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
