package com.yatirimtakip.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    data object Dashboard : Screen("dashboard", "Özet", Icons.Default.Dashboard)
    data object MonthlyClosing : Screen("monthly_closing", "Aylık Kapanış", Icons.Default.Assessment)
    data object History : Screen("history", "Geçmiş", Icons.Default.History)
}

val bottomNavItems = listOf(Screen.Dashboard, Screen.MonthlyClosing, Screen.History)
