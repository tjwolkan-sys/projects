package com.yatirimtakip

import android.app.Application
import com.yatirimtakip.data.database.AppDatabase
import com.yatirimtakip.data.repository.FinanceRepository

class App : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy {
        FinanceRepository(
            database.assetDao(),
            database.monthlySnapshotDao(),
            database.monthlyExpectationDao()
        )
    }
}
