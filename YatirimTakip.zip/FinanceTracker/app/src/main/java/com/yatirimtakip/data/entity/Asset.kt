package com.yatirimtakip.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "assets")
data class Asset(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val institutionName: String,       // Banka/Kurum adı
    val investmentType: String,        // Fon, Mevduat, BES
    val currentBalance: Double,        // Güncel bakiye
    val totalDeposited: Double,        // Toplam yatırılan ana para
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
