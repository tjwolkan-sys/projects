# Yatırım Takip - Kişisel Finans ve Yatırım Takip Uygulaması

Tamamen offline çalışan, Room veritabanı kullanan, Jetpack Compose ile yazılmış bir Android uygulamasıdır.

## Özellikler

- **Varlık Yönetimi**: Banka/kurum, yatırım tipi ve miktar bazında varlık takibi
- **Aylık Beklenti**: Her ay başı hedef kar/oran belirleyebilme
- **Aylık Kapanış**: Ay sonu bakiye güncelleyip dönem kapatma, beklenti vs gerçekleşen kıyaslama
- **Kümülatif Takip**: Ana para ve kâr ayrımı, ek yatırım takibi
- **Dönem Geçmişi**: Tüm aylık snapshot'lar ve özet istatistikler
- **100% Offline**: İnternete hiçbir istek atılmaz, veriler cihazda kalır

## APK Oluşturma (3 Yöntem)

### Yöntem 1: Android Studio (Önerilen)

1. [Android Studio](https://developer.android.com/studio) kurun
2. Bu proje klasörünü Android Studio ile açın (`File > Open`)
3. Gradle sync tamamlanmasını bekleyin
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seçin
5. APK dosyası `app/build/outputs/apk/debug/` altında oluşur

### Yöntem 2: Komut Satırı (Mac/Linux)

```bash
cd YatirimTakip
chmod +x build_apk.sh
./build_apk.sh
```

### Yöntem 3: Komut Satırı (Windows)

```cmd
cd YatirimTakip
build_apk.bat
```

## Gereksinimler

- JDK 17+
- Android SDK (API 34)
- Android Build Tools 34.x

## Mimari

```
MVVM Pattern
├── data/
│   ├── entity/     → Room Entity'leri (Asset, MonthlySnapshot, MonthlyExpectation)
│   ├── dao/        → Data Access Objects
│   ├── database/   → Room Database singleton
│   └── repository/ → Single source of truth
├── viewmodel/      → MainViewModel (StateFlow + Coroutines)
└── ui/
    ├── theme/      → Material 3 tema
    ├── screens/    → Dashboard, MonthlyClosing, History
    ├── components/ → Dialogs, Formatter
    └── navigation/ → Bottom navigation setup
```

## Kullanım

1. **Dashboard**: + butonuyla varlık ekleyin. Kartlara tıklayarak bakiye güncelleyin, uzun basarak silin.
2. **Aylık Kapanış**: Ay başında beklenti belirleyin, ay sonunda "Ayı Kapat" ile dönemi kaydedin.
3. **Geçmiş**: Tüm dönem kayıtlarını ve özet istatistikleri görüntüleyin.
