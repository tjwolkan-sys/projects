package com.acilkart.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun SingleFieldDialog(title: String, label: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var value by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = { OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text(label) },
            singleLine = true, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { Button(onClick = { if (value.isNotBlank()) { onConfirm(value.trim()); onDismiss() } }) { Text("Ekle") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Iptal") } })
}

@Composable
fun AllergyDialog(onDismiss: () -> Unit, onConfirm: (String, Boolean) -> Unit) {
    var name by remember { mutableStateOf("") }
    var critical by remember { mutableStateOf(true) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Alerji Ekle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Alerji Adi") },
                    placeholder = { Text("Orn: Penisilin") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Checkbox(checked = critical, onCheckedChange = { critical = it })
                    Text("Kritik alerji (kirmizi vurgulu gosterilir)")
                }
            }
        },
        confirmButton = { Button(onClick = { if (name.isNotBlank()) { onConfirm(name.trim(), critical); onDismiss() } }) { Text("Ekle") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Iptal") } })
}

@Composable
fun MedicationDialog(onDismiss: () -> Unit, onConfirm: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var dosage by remember { mutableStateOf("") }
    var freq by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Ilac Ekle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Ilac Adi") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = dosage, onValueChange = { dosage = it }, label = { Text("Doz") },
                        placeholder = { Text("500mg") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = freq, onValueChange = { freq = it }, label = { Text("Siklik") },
                        placeholder = { Text("2x1") }, singleLine = true, modifier = Modifier.weight(1f))
                }
            }
        },
        confirmButton = { Button(onClick = { if (name.isNotBlank()) { onConfirm(name.trim(), dosage.trim(), freq.trim()); onDismiss() } }) { Text("Ekle") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Iptal") } })
}

@Composable
fun ContactDialog(onDismiss: () -> Unit, onConfirm: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var relation by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Acil Kisi Ekle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Ad Soyad") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Telefon") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = relation, onValueChange = { relation = it }, label = { Text("Yakinlik") },
                    placeholder = { Text("Orn: Es, Anne, Kardes") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { Button(onClick = { if (name.isNotBlank() && phone.isNotBlank()) { onConfirm(name.trim(), phone.trim(), relation.trim()); onDismiss() } }) { Text("Ekle") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Iptal") } })
}

@Composable
fun DoctorDialog(onDismiss: () -> Unit, onConfirm: (String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var spec by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var hospital by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Doktor Ekle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Ad Soyad") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = spec, onValueChange = { spec = it }, label = { Text("Uzmanlik") },
                    placeholder = { Text("Aile Hekimi, Kardiyolog") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Telefon") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = hospital, onValueChange = { hospital = it }, label = { Text("Hastane") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { Button(onClick = { if (name.isNotBlank()) { onConfirm(name.trim(), spec.trim(), phone.trim(), hospital.trim()); onDismiss() } }) { Text("Ekle") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Iptal") } })
}
