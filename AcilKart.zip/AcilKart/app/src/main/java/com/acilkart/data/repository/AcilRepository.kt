package com.acilkart.data.repository

import com.acilkart.data.dao.*
import com.acilkart.data.entity.*
import kotlinx.coroutines.flow.Flow

class AcilRepository(
    private val personDao: PersonDao,
    private val allergyDao: AllergyDao,
    private val conditionDao: ConditionDao,
    private val medicationDao: MedicationDao,
    private val surgeryDao: SurgeryDao,
    private val contactDao: EmergencyContactDao,
    private val doctorDao: DoctorDao,
    private val insuranceDao: InsuranceDao
) {
    // Person
    val owner: Flow<Person?> = personDao.getOwner()
    val familyMembers: Flow<List<Person>> = personDao.getFamilyMembers()
    val allPersons: Flow<List<Person>> = personDao.getAll()
    suspend fun getOwnerSync() = personDao.getOwnerSync()
    suspend fun getPersonById(id: Long) = personDao.getById(id)
    suspend fun savePerson(p: Person) = personDao.insert(p)
    suspend fun updatePerson(p: Person) = personDao.update(p.copy(updatedAt = System.currentTimeMillis()))
    suspend fun deletePerson(p: Person) = personDao.delete(p)

    // Medical
    fun getAllergies(pid: Long) = allergyDao.getByPerson(pid)
    suspend fun getAllergiesSync(pid: Long) = allergyDao.getByPersonSync(pid)
    suspend fun addAllergy(a: Allergy) = allergyDao.insert(a)
    suspend fun deleteAllergy(a: Allergy) = allergyDao.delete(a)

    fun getConditions(pid: Long) = conditionDao.getByPerson(pid)
    suspend fun getConditionsSync(pid: Long) = conditionDao.getByPersonSync(pid)
    suspend fun addCondition(c: Condition) = conditionDao.insert(c)
    suspend fun deleteCondition(c: Condition) = conditionDao.delete(c)

    fun getMedications(pid: Long) = medicationDao.getByPerson(pid)
    suspend fun getMedicationsSync(pid: Long) = medicationDao.getByPersonSync(pid)
    suspend fun addMedication(m: Medication) = medicationDao.insert(m)
    suspend fun deleteMedication(m: Medication) = medicationDao.delete(m)

    fun getSurgeries(pid: Long) = surgeryDao.getByPerson(pid)
    suspend fun getSurgeriesSync(pid: Long) = surgeryDao.getByPersonSync(pid)
    suspend fun addSurgery(s: Surgery) = surgeryDao.insert(s)
    suspend fun deleteSurgery(s: Surgery) = surgeryDao.delete(s)

    // Contacts
    fun getContacts(pid: Long) = contactDao.getByPerson(pid)
    suspend fun getContactsSync(pid: Long) = contactDao.getByPersonSync(pid)
    suspend fun addContact(c: EmergencyContact) = contactDao.insert(c)
    suspend fun updateContact(c: EmergencyContact) = contactDao.update(c)
    suspend fun deleteContact(c: EmergencyContact) = contactDao.delete(c)

    // Doctor
    fun getDoctors(pid: Long) = doctorDao.getByPerson(pid)
    suspend fun getDoctorsSync(pid: Long) = doctorDao.getByPersonSync(pid)
    suspend fun addDoctor(d: Doctor) = doctorDao.insert(d)
    suspend fun deleteDoctor(d: Doctor) = doctorDao.delete(d)

    // Insurance
    fun getInsurance(pid: Long) = insuranceDao.getByPerson(pid)
    suspend fun getInsuranceSync(pid: Long) = insuranceDao.getByPersonSync(pid)
    suspend fun saveInsurance(i: InsuranceInfo) = insuranceDao.insert(i)
    suspend fun deleteInsurance(i: InsuranceInfo) = insuranceDao.delete(i)

    // Full profile
    suspend fun getFullProfile(personId: Long): FullProfile? {
        val person = personDao.getById(personId) ?: return null
        return FullProfile(
            person = person,
            allergies = allergyDao.getByPersonSync(personId),
            conditions = conditionDao.getByPersonSync(personId),
            medications = medicationDao.getByPersonSync(personId),
            surgeries = surgeryDao.getByPersonSync(personId),
            emergencyContacts = contactDao.getByPersonSync(personId),
            doctors = doctorDao.getByPersonSync(personId),
            insurance = insuranceDao.getByPersonSync(personId)
        )
    }
}
