package com.acilkart.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "persons")
data class Person(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String = "",
    val birthDate: String = "",           // DD.MM.YYYY
    val tcKimlik: String = "",
    val bloodType: String = "",           // A+, A-, B+, B-, AB+, AB-, 0+, 0-
    val height: String = "",              // cm
    val weight: String = "",              // kg
    val isOrganDonor: Boolean = false,
    val isOwner: Boolean = true,          // true = kendi kartı, false = aile üyesi
    val relationship: String = "",        // Eş, Çocuk, Anne, Baba, vb.
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
