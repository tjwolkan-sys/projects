package com.acilkart

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.acilkart.data.entity.*
import com.acilkart.ui.navigation.Screen
import com.acilkart.ui.navigation.bottomNavItems
import com.acilkart.ui.screens.*
import com.acilkart.ui.theme.AcilKartTheme
import com.acilkart.viewmodel.MainViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AcilKartTheme { AcilKartApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AcilKartApp(vm: MainViewModel = viewModel()) {
    val navController = rememberNavController()
    val navEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navEntry?.destination?.route

    val owner by vm.owner.collectAsState()
    val familyMembers by vm.familyMembers.collectAsState()
    val fullProfile by vm.fullProfile.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showAddFamily by remember { mutableStateOf(false) }

    // Load owner profile
    LaunchedEffect(owner) {
        owner?.let { vm.loadProfile(it.id) }
    }

    LaunchedEffect(Unit) {
        vm.toast.collectLatest { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
    }

    // Check if we're on an edit route (hide bottom nav)
    val isEditRoute = currentRoute?.startsWith("edit/") == true

    Scaffold(
        topBar = {
            if (!isEditRoute) {
                CenterAlignedTopAppBar(
                    title = { Text(bottomNavItems.find { it.route == currentRoute }?.title ?: "Acil Kart") },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        },
        bottomBar = {
            if (!isEditRoute) {
                NavigationBar {
                    bottomNavItems.forEach { screen ->
                        NavigationBarItem(
                            icon = { Icon(screen.icon, screen.title) },
                            label = { Text(screen.title) },
                            selected = currentRoute == screen.route,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(navController, Screen.Card.route, Modifier.padding(innerPadding)) {

            composable(Screen.Card.route) {
                CardScreen(
                    profile = fullProfile,
                    onSetup = {
                        // Create owner person and navigate to edit
                        vm.savePerson(Person(isOwner = true, fullName = "")) { id ->
                            navController.navigate(Screen.Edit.create(id))
                        }
                    },
                    onEdit = { personId ->
                        navController.navigate(Screen.Edit.create(personId))
                    }
                )
            }

            composable(
                Screen.Edit.route,
                arguments = listOf(navArgument("personId") { type = NavType.LongType })
            ) { entry ->
                val personId = entry.arguments?.getLong("personId") ?: return@composable

                var person by remember { mutableStateOf<Person?>(null) }
                val allergies by vm.getAllergies(personId).collectAsState()
                val conditions by vm.getConditions(personId).collectAsState()
                val medications by vm.getMedications(personId).collectAsState()
                val surgeries by vm.getSurgeries(personId).collectAsState()
                val contacts by vm.getContacts(personId).collectAsState()
                val doctors by vm.getDoctors(personId).collectAsState()
                val insurance by vm.getInsurance(personId).collectAsState()

                LaunchedEffect(personId) {
                    person = vm.getPersonById(personId)
                }

                EditScreen(
                    person = person,
                    allergies = allergies,
                    conditions = conditions,
                    medications = medications,
                    surgeries = surgeries,
                    contacts = contacts,
                    doctors = doctors,
                    insurance = insurance,
                    onSavePerson = { p ->
                        if (p.id == 0L) {
                            vm.savePerson(p) { newId ->
                                person = p.copy(id = newId)
                            }
                        } else {
                            vm.updatePerson(p)
                            person = p
                        }
                        // Refresh profile
                        scope.launch {
                            vm.loadProfile(if (p.id > 0) p.id else personId)
                        }
                    },
                    onAddAllergy = vm::addAllergy,
                    onDeleteAllergy = vm::deleteAllergy,
                    onAddCondition = vm::addCondition,
                    onDeleteCondition = vm::deleteCondition,
                    onAddMedication = vm::addMedication,
                    onDeleteMedication = vm::deleteMedication,
                    onAddSurgery = vm::addSurgery,
                    onDeleteSurgery = vm::deleteSurgery,
                    onAddContact = vm::addContact,
                    onDeleteContact = vm::deleteContact,
                    onAddDoctor = vm::addDoctor,
                    onDeleteDoctor = vm::deleteDoctor,
                    onSaveInsurance = vm::saveInsurance,
                    onBack = {
                        // Refresh owner profile before going back
                        vm.refreshOwnerProfile()
                        navController.popBackStack()
                    }
                )
            }

            composable(Screen.Family.route) {
                FamilyScreen(
                    familyMembers = familyMembers,
                    onMemberClick = { navController.navigate(Screen.Edit.create(it)) },
                    onAddMember = { showAddFamily = true },
                    onDeleteMember = vm::deletePerson
                )
            }

            composable(Screen.Settings.route) {
                SettingsScreen()
            }
        }
    }

    // Add family member dialog
    if (showAddFamily) {
        AddFamilyDialog(
            onDismiss = { showAddFamily = false },
            onConfirm = { name, relation ->
                vm.savePerson(Person(isOwner = false, fullName = name, relationship = relation)) { id ->
                    navController.navigate(Screen.Edit.create(id))
                }
            }
        )
    }
}
