package com.acilkart.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.acilkart.data.dao.*
import com.acilkart.data.entity.*

@Database(
    entities = [Person::class, Allergy::class, Condition::class, Medication::class,
        Surgery::class, EmergencyContact::class, Doctor::class, InsuranceInfo::class],
    version = 1, exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun personDao(): PersonDao
    abstract fun allergyDao(): AllergyDao
    abstract fun conditionDao(): ConditionDao
    abstract fun medicationDao(): MedicationDao
    abstract fun surgeryDao(): SurgeryDao
    abstract fun emergencyContactDao(): EmergencyContactDao
    abstract fun doctorDao(): DoctorDao
    abstract fun insuranceDao(): InsuranceDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "acil_kart_db")
                .build().also { INSTANCE = it }
        }
    }
}
