package com.acilkart

import android.app.Application
import com.acilkart.data.database.AppDatabase
import com.acilkart.data.repository.AcilRepository

class App : Application() {
    val db by lazy { AppDatabase.get(this) }
    val repo by lazy {
        AcilRepository(db.personDao(), db.allergyDao(), db.conditionDao(), db.medicationDao(),
            db.surgeryDao(), db.emergencyContactDao(), db.doctorDao(), db.insuranceDao())
    }
}
