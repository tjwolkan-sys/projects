package com.acilkart.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "emergency_contacts",
    foreignKeys = [ForeignKey(entity = Person::class, parentColumns = ["id"], childColumns = ["personId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("personId")]
)
data class EmergencyContact(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personId: Long,
    val name: String,
    val phone: String,
    val relationship: String = "",    // Eş, Anne, Baba, Kardeş, Arkadaş, İş
    val priority: Int = 0,            // 0 = en yüksek öncelik
    val notes: String = ""
)

@Entity(
    tableName = "doctors",
    foreignKeys = [ForeignKey(entity = Person::class, parentColumns = ["id"], childColumns = ["personId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("personId")]
)
data class Doctor(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personId: Long,
    val name: String,
    val specialty: String = "",       // Aile Hekimi, Kardiyolog, vb.
    val phone: String = "",
    val hospital: String = "",
    val notes: String = ""
)

@Entity(
    tableName = "insurance_info",
    foreignKeys = [ForeignKey(entity = Person::class, parentColumns = ["id"], childColumns = ["personId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("personId")]
)
data class InsuranceInfo(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personId: Long,
    val company: String = "",
    val policyNumber: String = "",
    val sgkNumber: String = "",
    val expiryDate: String = "",
    val notes: String = ""
)

// Full profile for display
data class FullProfile(
    val person: Person,
    val allergies: List<Allergy>,
    val conditions: List<Condition>,
    val medications: List<Medication>,
    val surgeries: List<Surgery>,
    val emergencyContacts: List<EmergencyContact>,
    val doctors: List<Doctor>,
    val insurance: InsuranceInfo?
)
