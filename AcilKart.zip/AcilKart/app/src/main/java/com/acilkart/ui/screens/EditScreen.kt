package com.acilkart.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.acilkart.data.entity.*
import com.acilkart.ui.components.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EditScreen(
    person: Person?,
    allergies: List<Allergy>,
    conditions: List<Condition>,
    medications: List<Medication>,
    surgeries: List<Surgery>,
    contacts: List<EmergencyContact>,
    doctors: List<Doctor>,
    insurance: InsuranceInfo?,
    onSavePerson: (Person) -> Unit,
    onAddAllergy: (Allergy) -> Unit, onDeleteAllergy: (Allergy) -> Unit,
    onAddCondition: (Condition) -> Unit, onDeleteCondition: (Condition) -> Unit,
    onAddMedication: (Medication) -> Unit, onDeleteMedication: (Medication) -> Unit,
    onAddSurgery: (Surgery) -> Unit, onDeleteSurgery: (Surgery) -> Unit,
    onAddContact: (EmergencyContact) -> Unit, onDeleteContact: (EmergencyContact) -> Unit,
    onAddDoctor: (Doctor) -> Unit, onDeleteDoctor: (Doctor) -> Unit,
    onSaveInsurance: (InsuranceInfo) -> Unit,
    onBack: () -> Unit
) {
    val pid = person?.id ?: 0L
    var name by remember(person) { mutableStateOf(person?.fullName ?: "") }
    var birth by remember(person) { mutableStateOf(person?.birthDate ?: "") }
    var tc by remember(person) { mutableStateOf(person?.tcKimlik ?: "") }
    var bloodType by remember(person) { mutableStateOf(person?.bloodType ?: "") }
    var height by remember(person) { mutableStateOf(person?.height ?: "") }
    var weight by remember(person) { mutableStateOf(person?.weight ?: "") }
    var donor by remember(person) { mutableStateOf(person?.isOrganDonor ?: false) }

    // Dialog states
    var showAllergy by remember { mutableStateOf(false) }
    var showCondition by remember { mutableStateOf(false) }
    var showMedication by remember { mutableStateOf(false) }
    var showSurgery by remember { mutableStateOf(false) }
    var showContact by remember { mutableStateOf(false) }
    var showDoctor by remember { mutableStateOf(false) }
    var showInsurance by remember { mutableStateOf(false) }
    var btExpanded by remember { mutableStateOf(false) }
    val bloodTypes = listOf("A+","A-","B+","B-","AB+","AB-","0+","0-")

    Scaffold(topBar = {
        TopAppBar(title = { Text(if (person == null) "Kart Olustur" else "Karti Duzenle") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri") } },
            actions = {
                TextButton(onClick = {
                    val p = (person ?: Person(isOwner = true)).copy(
                        fullName = name, birthDate = birth, tcKimlik = tc,
                        bloodType = bloodType, height = height, weight = weight, isOrganDonor = donor)
                    onSavePerson(p)
                }) { Text("Kaydet", fontWeight = FontWeight.Bold, color = Color(0xFFD32F2F)) }
            })
    }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 12.dp)) {

            // ── BASIC INFO ──
            item { SectionHeader("Kisisel Bilgiler", Icons.Default.Person) }
            item {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Ad Soyad") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = birth, onValueChange = { birth = it }, label = { Text("Dogum Tarihi") },
                        placeholder = { Text("GG.AA.YYYY") }, singleLine = true, modifier = Modifier.weight(1f))
                    ExposedDropdownMenuBox(expanded = btExpanded, onExpandedChange = { btExpanded = it }, modifier = Modifier.weight(1f)) {
                        OutlinedTextField(value = bloodType, onValueChange = {}, readOnly = true, label = { Text("Kan Grubu") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(btExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = btExpanded, onDismissRequest = { btExpanded = false }) {
                            bloodTypes.forEach { bt -> DropdownMenuItem(text = { Text(bt) }, onClick = { bloodType = bt; btExpanded = false }) }
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = height, onValueChange = { height = it }, label = { Text("Boy (cm)") },
                        singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = weight, onValueChange = { weight = it }, label = { Text("Kilo (kg)") },
                        singleLine = true, modifier = Modifier.weight(1f))
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = donor, onCheckedChange = { donor = it })
                    Text("Organ Bagiscisiyim")
                }
            }

            // ── ALLERGIES ──
            item { EditSection("Alerjiler", Icons.Default.Warning, allergies.size) { showAllergy = true } }
            if (allergies.isNotEmpty()) {
                item {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        allergies.forEach { a ->
                            InputChip(selected = false, onClick = { onDeleteAllergy(a) },
                                label = { Text(a.name) },
                                trailingIcon = { Icon(Icons.Default.Close, "Sil", modifier = Modifier.size(14.dp)) })
                        }
                    }
                }
            }

            // ── CONDITIONS ──
            item { EditSection("Kronik Hastaliklar", Icons.Default.MonitorHeart, conditions.size) { showCondition = true } }
            if (conditions.isNotEmpty()) {
                item {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        conditions.forEach { c ->
                            InputChip(selected = false, onClick = { onDeleteCondition(c) },
                                label = { Text(c.name) },
                                trailingIcon = { Icon(Icons.Default.Close, "Sil", modifier = Modifier.size(14.dp)) })
                        }
                    }
                }
            }

            // ── MEDICATIONS ──
            item { EditSection("Ilaclar", Icons.Default.Medication, medications.size) { showMedication = true } }
            items(medications) { m ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(m.name, fontWeight = FontWeight.Medium)
                            Text("${m.dosage} ${m.frequency}".trim(), style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { onDeleteMedication(m) }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, "Sil", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // ── CONTACTS ──
            item { EditSection("Acil Kisiler", Icons.Default.Phone, contacts.size) { showContact = true } }
            items(contacts) { c ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${c.name} ${if (c.relationship.isNotBlank()) "(${c.relationship})" else ""}", fontWeight = FontWeight.Medium)
                            Text(c.phone, style = MaterialTheme.typography.bodySmall, color = Color(0xFFD32F2F))
                        }
                        IconButton(onClick = { onDeleteContact(c) }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, "Sil", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // ── DOCTORS ──
            item { EditSection("Doktorlar", Icons.Default.LocalHospital, doctors.size) { showDoctor = true } }
            items(doctors) { d ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(d.name, fontWeight = FontWeight.Medium)
                            Text("${d.specialty} ${if (d.hospital.isNotBlank()) "— ${d.hospital}" else ""}".trim(),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { onDeleteDoctor(d) }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, "Sil", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // ── INSURANCE ──
            item { EditSection("Sigorta", Icons.Default.HealthAndSafety, if (insurance != null) 1 else 0) { showInsurance = true } }
            insurance?.let { ins ->
                item {
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${ins.company} — ${ins.policyNumber}", fontWeight = FontWeight.Medium)
                            if (ins.sgkNumber.isNotBlank()) Text("SGK: ${ins.sgkNumber}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(40.dp)) }
        }
    }

    // ── DIALOGS ──
    if (showAllergy) AllergyDialog(onDismiss = { showAllergy = false },
        onConfirm = { name2, critical -> onAddAllergy(Allergy(personId = pid, name = name2, isCritical = critical)) })
    if (showCondition) SingleFieldDialog("Hastalik Ekle", "Hastalik Adi", onDismiss = { showCondition = false },
        onConfirm = { onAddCondition(Condition(personId = pid, name = it)) })
    if (showMedication) MedicationDialog(onDismiss = { showMedication = false },
        onConfirm = { n, d, f -> onAddMedication(Medication(personId = pid, name = n, dosage = d, frequency = f)) })
    if (showSurgery) SingleFieldDialog("Ameliyat Ekle", "Ameliyat", onDismiss = { showSurgery = false },
        onConfirm = { onAddSurgery(Surgery(personId = pid, name = it)) })
    if (showContact) ContactDialog(onDismiss = { showContact = false },
        onConfirm = { n, ph, r -> onAddContact(EmergencyContact(personId = pid, name = n, phone = ph, relationship = r, priority = contacts.size)) })
    if (showDoctor) DoctorDialog(onDismiss = { showDoctor = false },
        onConfirm = { n, s, ph, h -> onAddDoctor(Doctor(personId = pid, name = n, specialty = s, phone = ph, hospital = h)) })
    if (showInsurance) InsuranceDialog(insurance, pid, onDismiss = { showInsurance = false }, onSave = onSaveInsurance)
}

@Composable
private fun EditSection(title: String, icon: ImageVector, count: Int, onAdd: () -> Unit) {
    Spacer(Modifier.height(4.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        SectionHeader(title, icon)
        TextButton(onClick = onAdd) { Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Ekle") }
    }
}

@Composable
fun InsuranceDialog(current: InsuranceInfo?, personId: Long, onDismiss: () -> Unit, onSave: (InsuranceInfo) -> Unit) {
    var company by remember { mutableStateOf(current?.company ?: "") }
    var policy by remember { mutableStateOf(current?.policyNumber ?: "") }
    var sgk by remember { mutableStateOf(current?.sgkNumber ?: "") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Sigorta Bilgileri") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = company, onValueChange = { company = it }, label = { Text("Sigorta Sirketi") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = policy, onValueChange = { policy = it }, label = { Text("Police No") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = sgk, onValueChange = { sgk = it }, label = { Text("SGK No") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { Button(onClick = {
            onSave(InsuranceInfo(id = current?.id ?: 0, personId = personId, company = company, policyNumber = policy, sgkNumber = sgk))
            onDismiss()
        }) { Text("Kaydet") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Iptal") } })
}
