package com.acilkart.data.dao

import androidx.room.*
import com.acilkart.data.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PersonDao {
    @Query("SELECT * FROM persons WHERE isOwner = 1 LIMIT 1")
    fun getOwner(): Flow<Person?>

    @Query("SELECT * FROM persons WHERE isOwner = 1 LIMIT 1")
    suspend fun getOwnerSync(): Person?

    @Query("SELECT * FROM persons WHERE isOwner = 0 ORDER BY fullName ASC")
    fun getFamilyMembers(): Flow<List<Person>>

    @Query("SELECT * FROM persons WHERE id = :id")
    suspend fun getById(id: Long): Person?

    @Query("SELECT * FROM persons ORDER BY isOwner DESC, fullName ASC")
    fun getAll(): Flow<List<Person>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(person: Person): Long

    @Update
    suspend fun update(person: Person)

    @Delete
    suspend fun delete(person: Person)
}

@Dao
interface AllergyDao {
    @Query("SELECT * FROM allergies WHERE personId = :personId ORDER BY isCritical DESC, name ASC")
    fun getByPerson(personId: Long): Flow<List<Allergy>>

    @Query("SELECT * FROM allergies WHERE personId = :personId ORDER BY isCritical DESC, name ASC")
    suspend fun getByPersonSync(personId: Long): List<Allergy>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(allergy: Allergy): Long

    @Delete
    suspend fun delete(allergy: Allergy)
}

@Dao
interface ConditionDao {
    @Query("SELECT * FROM conditions WHERE personId = :personId ORDER BY name ASC")
    fun getByPerson(personId: Long): Flow<List<Condition>>

    @Query("SELECT * FROM conditions WHERE personId = :personId ORDER BY name ASC")
    suspend fun getByPersonSync(personId: Long): List<Condition>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(condition: Condition): Long

    @Delete
    suspend fun delete(condition: Condition)
}

@Dao
interface MedicationDao {
    @Query("SELECT * FROM medications WHERE personId = :personId ORDER BY name ASC")
    fun getByPerson(personId: Long): Flow<List<Medication>>

    @Query("SELECT * FROM medications WHERE personId = :personId ORDER BY name ASC")
    suspend fun getByPersonSync(personId: Long): List<Medication>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(medication: Medication): Long

    @Delete
    suspend fun delete(medication: Medication)
}

@Dao
interface SurgeryDao {
    @Query("SELECT * FROM surgeries WHERE personId = :personId ORDER BY date DESC")
    fun getByPerson(personId: Long): Flow<List<Surgery>>

    @Query("SELECT * FROM surgeries WHERE personId = :personId ORDER BY date DESC")
    suspend fun getByPersonSync(personId: Long): List<Surgery>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(surgery: Surgery): Long

    @Delete
    suspend fun delete(surgery: Surgery)
}

@Dao
interface EmergencyContactDao {
    @Query("SELECT * FROM emergency_contacts WHERE personId = :personId ORDER BY priority ASC")
    fun getByPerson(personId: Long): Flow<List<EmergencyContact>>

    @Query("SELECT * FROM emergency_contacts WHERE personId = :personId ORDER BY priority ASC")
    suspend fun getByPersonSync(personId: Long): List<EmergencyContact>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(contact: EmergencyContact): Long

    @Update
    suspend fun update(contact: EmergencyContact)

    @Delete
    suspend fun delete(contact: EmergencyContact)
}

@Dao
interface DoctorDao {
    @Query("SELECT * FROM doctors WHERE personId = :personId ORDER BY specialty ASC")
    fun getByPerson(personId: Long): Flow<List<Doctor>>

    @Query("SELECT * FROM doctors WHERE personId = :personId ORDER BY specialty ASC")
    suspend fun getByPersonSync(personId: Long): List<Doctor>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(doctor: Doctor): Long

    @Delete
    suspend fun delete(doctor: Doctor)
}

@Dao
interface InsuranceDao {
    @Query("SELECT * FROM insurance_info WHERE personId = :personId LIMIT 1")
    fun getByPerson(personId: Long): Flow<InsuranceInfo?>

    @Query("SELECT * FROM insurance_info WHERE personId = :personId LIMIT 1")
    suspend fun getByPersonSync(personId: Long): InsuranceInfo?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(insurance: InsuranceInfo): Long

    @Delete
    suspend fun delete(insurance: InsuranceInfo)
}
