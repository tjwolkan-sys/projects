package com.acilkart.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.acilkart.App
import com.acilkart.data.entity.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = (application as App).repo

    val owner = repo.owner.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val familyMembers = repo.familyMembers.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _toast = MutableSharedFlow<String>()
    val toast: SharedFlow<String> = _toast.asSharedFlow()

    private val _fullProfile = MutableStateFlow<FullProfile?>(null)
    val fullProfile: StateFlow<FullProfile?> = _fullProfile.asStateFlow()

    fun loadProfile(personId: Long) {
        viewModelScope.launch { _fullProfile.value = repo.getFullProfile(personId) }
    }

    fun refreshOwnerProfile() {
        viewModelScope.launch {
            repo.getOwnerSync()?.let { _fullProfile.value = repo.getFullProfile(it.id) }
        }
    }

    // Person
    fun savePerson(person: Person, onDone: ((Long) -> Unit)? = null) {
        viewModelScope.launch {
            val id = repo.savePerson(person)
            _toast.emit("Kaydedildi")
            onDone?.invoke(id)
        }
    }

    fun updatePerson(person: Person) {
        viewModelScope.launch { repo.updatePerson(person); _toast.emit("Guncellendi") }
    }

    fun deletePerson(person: Person) {
        viewModelScope.launch { repo.deletePerson(person); _toast.emit("Silindi") }
    }

    // Medical
    fun getAllergies(pid: Long) = repo.getAllergies(pid).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun getConditions(pid: Long) = repo.getConditions(pid).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun getMedications(pid: Long) = repo.getMedications(pid).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun getSurgeries(pid: Long) = repo.getSurgeries(pid).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun getContacts(pid: Long) = repo.getContacts(pid).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun getDoctors(pid: Long) = repo.getDoctors(pid).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun getInsurance(pid: Long) = repo.getInsurance(pid).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun addAllergy(a: Allergy) { viewModelScope.launch { repo.addAllergy(a); _toast.emit("Alerji eklendi") } }
    fun deleteAllergy(a: Allergy) { viewModelScope.launch { repo.deleteAllergy(a) } }
    fun addCondition(c: Condition) { viewModelScope.launch { repo.addCondition(c); _toast.emit("Hastalik eklendi") } }
    fun deleteCondition(c: Condition) { viewModelScope.launch { repo.deleteCondition(c) } }
    fun addMedication(m: Medication) { viewModelScope.launch { repo.addMedication(m); _toast.emit("Ilac eklendi") } }
    fun deleteMedication(m: Medication) { viewModelScope.launch { repo.deleteMedication(m) } }
    fun addSurgery(s: Surgery) { viewModelScope.launch { repo.addSurgery(s); _toast.emit("Ameliyat eklendi") } }
    fun deleteSurgery(s: Surgery) { viewModelScope.launch { repo.deleteSurgery(s) } }
    fun addContact(c: EmergencyContact) { viewModelScope.launch { repo.addContact(c); _toast.emit("Kisi eklendi") } }
    fun deleteContact(c: EmergencyContact) { viewModelScope.launch { repo.deleteContact(c) } }
    fun addDoctor(d: Doctor) { viewModelScope.launch { repo.addDoctor(d); _toast.emit("Doktor eklendi") } }
    fun deleteDoctor(d: Doctor) { viewModelScope.launch { repo.deleteDoctor(d) } }
    fun saveInsurance(i: InsuranceInfo) { viewModelScope.launch { repo.saveInsurance(i); _toast.emit("Sigorta kaydedildi") } }

    suspend fun getPersonById(id: Long) = repo.getPersonById(id)
    suspend fun getFullProfile(id: Long) = repo.getFullProfile(id)
}
