package com.acilkart.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.acilkart.data.entity.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CardScreen(
    profile: FullProfile?,
    onSetup: () -> Unit,
    onEdit: (Long) -> Unit
) {
    if (profile == null) {
        // First time - setup prompt
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                Icon(Icons.Default.MedicalServices, null, modifier = Modifier.size(72.dp),
                    tint = Color(0xFFD32F2F))
                Spacer(Modifier.height(16.dp))
                Text("Acil Durum Kartiniz", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Hayati bilgilerinizi kaydedin. Acil durumda hayat kurtarir.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(24.dp))
                Button(onClick = onSetup, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Kartimi Olustur")
                }
            }
        }
        return
    }

    val p = profile.person
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // ── RED EMERGENCY HEADER ──
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFD32F2F))
            ) {
                Column(Modifier.padding(20.dp)) {
                    // Top row: cross icon + name + blood type
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.MedicalServices, null, tint = Color.White, modifier = Modifier.size(24.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("ACIL DURUM KARTI", style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.8f), letterSpacing = 1.sp)
                            Text(p.fullName, style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        if (p.bloodType.isNotBlank()) {
                            Card(shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.2f))) {
                                Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(p.bloodType, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    Text("KAN GRUBU", style = MaterialTheme.typography.labelSmall,
                                        color = Color.White.copy(alpha = 0.7f), fontSize = 9.sp)
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    // Info chips row
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (p.birthDate.isNotBlank()) InfoChip("Dogum", p.birthDate)
                        if (p.height.isNotBlank()) InfoChip("Boy", "${p.height} cm")
                        if (p.weight.isNotBlank()) InfoChip("Kilo", "${p.weight} kg")
                        if (p.isOrganDonor) InfoChip("Organ", "Bagisci")
                    }
                }
            }
        }

        // ── ALLERGIES (critical first!) ──
        if (profile.allergies.isNotEmpty()) {
            item {
                SectionHeader("Alerjiler", Icons.Default.Warning)
                Spacer(Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    profile.allergies.forEach { a ->
                        val bg = if (a.isCritical) Color(0xFFFF8A80) else Color(0xFFFFCC80)
                        val fg = if (a.isCritical) Color(0xFFB71C1C) else Color(0xFFE65100)
                        AssistChip(onClick = {},
                            label = { Text(a.name, fontWeight = if (a.isCritical) FontWeight.Bold else FontWeight.Normal, color = fg) },
                            leadingIcon = { if (a.isCritical) Icon(Icons.Default.Error, null, tint = fg, modifier = Modifier.size(16.dp)) },
                            colors = AssistChipDefaults.assistChipColors(containerColor = bg))
                    }
                }
            }
        }

        // ── CONDITIONS ──
        if (profile.conditions.isNotEmpty()) {
            item {
                SectionHeader("Kronik Hastaliklar", Icons.Default.MonitorHeart)
                Spacer(Modifier.height(6.dp))
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(14.dp)) {
                        profile.conditions.forEach { c ->
                            Text("• ${c.name}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }

        // ── MEDICATIONS ──
        if (profile.medications.isNotEmpty()) {
            item {
                SectionHeader("Ilaclar", Icons.Default.Medication)
                Spacer(Modifier.height(6.dp))
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        profile.medications.forEach { m ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(m.name, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                                Text("${m.dosage} ${m.frequency}".trim(),
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        // ── INSURANCE ──
        profile.insurance?.let { ins ->
            if (ins.company.isNotBlank()) {
                item {
                    SectionHeader("Sigorta", Icons.Default.HealthAndSafety)
                    Spacer(Modifier.height(6.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.padding(14.dp)) {
                            Text("${ins.company} — Police: ${ins.policyNumber}", style = MaterialTheme.typography.bodyMedium)
                            if (ins.sgkNumber.isNotBlank()) Text("SGK: ${ins.sgkNumber}", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        // ── EMERGENCY CONTACTS ──
        if (profile.emergencyContacts.isNotEmpty()) {
            item {
                Spacer(Modifier.height(4.dp))
                SectionHeader("ACIL ARAYIN", Icons.Default.Phone)
            }
            items(profile.emergencyContacts) { c ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${c.phone}"))
                        context.startActivity(intent)
                    },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFD32F2F).copy(alpha = 0.08f))
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${c.name}${if (c.relationship.isNotBlank()) " (${c.relationship})" else ""}",
                                fontWeight = FontWeight.Medium)
                            Text(c.phone, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFD32F2F))
                        }
                        Box(Modifier.size(40.dp).clip(CircleShape).background(Color(0xFFD32F2F).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Call, null, tint = Color(0xFFD32F2F), modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }

        // ── DOCTORS ──
        if (profile.doctors.isNotEmpty()) {
            item { SectionHeader("Doktorlar", Icons.Default.LocalHospital) }
            items(profile.doctors) { d ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.padding(14.dp).clickable {
                        if (d.phone.isNotBlank()) context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${d.phone}")))
                    }, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(d.name, fontWeight = FontWeight.Medium)
                            if (d.specialty.isNotBlank()) Text(d.specialty, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (d.hospital.isNotBlank()) Text(d.hospital, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (d.phone.isNotBlank()) {
                            Icon(Icons.Default.Call, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }

        // ── EDIT BUTTON ──
        item {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { onEdit(p.id) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Edit, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Karti Duzenle")
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun InfoChip(label: String, value: String) {
    Card(shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.12f))) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f), fontSize = 9.sp)
            Text(value, style = MaterialTheme.typography.bodySmall, color = Color.White, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun SectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color(0xFFD32F2F), modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
    }
}
