package com.acilkart.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.acilkart.data.entity.Person

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FamilyScreen(
    familyMembers: List<Person>,
    onMemberClick: (Long) -> Unit,
    onAddMember: () -> Unit,
    onDeleteMember: (Person) -> Unit
) {
    var deleteTarget by remember { mutableStateOf<Person?>(null) }

    Scaffold(floatingActionButton = {
        FloatingActionButton(onClick = onAddMember, containerColor = Color(0xFFD32F2F)) {
            Icon(Icons.Default.PersonAdd, "Aile Uyesi Ekle", tint = Color.White)
        }
    }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 16.dp)) {

            item { Text("Aile Uyeleri", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
            item { Text("Her uye icin ayri acil kart olusturabilirsiniz",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }

            if (familyMembers.isEmpty()) {
                item {
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.FamilyRestroom, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(8.dp))
                            Text("Henuz aile uyesi eklenmedi", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(4.dp))
                            Text("+ butonuyla ekleyin", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            items(familyMembers, key = { it.id }) { member ->
                Card(Modifier.fillMaxWidth().clickable { onMemberClick(member.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Person, null, tint = Color(0xFFD32F2F), modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(member.fullName.ifBlank { "Isimsiz" }, fontWeight = FontWeight.Medium)
                            Text(member.relationship.ifBlank { "Aile uyesi" },
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (member.bloodType.isNotBlank()) {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFD32F2F).copy(alpha = 0.1f))) {
                                Text(member.bloodType, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    fontWeight = FontWeight.Bold, color = Color(0xFFD32F2F))
                            }
                            Spacer(Modifier.width(8.dp))
                        }
                        IconButton(onClick = { deleteTarget = member }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Delete, "Sil", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    deleteTarget?.let { member ->
        AlertDialog(onDismissRequest = { deleteTarget = null },
            title = { Text("Uye Sil") },
            text = { Text("${member.fullName} ve tum bilgileri silinecek.") },
            confirmButton = { Button(onClick = { onDeleteMember(member); deleteTarget = null },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("Sil") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Iptal") } })
    }
}

@Composable
fun AddFamilyDialog(onDismiss: () -> Unit, onConfirm: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var relation by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Aile Uyesi Ekle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Ad Soyad") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = relation, onValueChange = { relation = it }, label = { Text("Yakinlik") },
                    placeholder = { Text("Es, Cocuk, Anne, Baba") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { Button(onClick = { if (name.isNotBlank()) { onConfirm(name.trim(), relation.trim()); onDismiss() } }) { Text("Ekle") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Iptal") } })
}

// ══ SETTINGS ══
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen() {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 16.dp)) {
        item { Text("Ayarlar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }

        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFD32F2F).copy(alpha = 0.08f))) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, null, tint = Color(0xFFD32F2F))
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("Nasil Calisir?", fontWeight = FontWeight.Medium)
                        Text("Acil durum kartiniz telefonunuzda saklanir. Acil durumda yaninizda olan kisi veya saglik ekibi bu uygulamayi acarak hayati bilgilerinize ulasir. Acil kisi numaralarina tek dokunusla arama yapar.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("Gizlilik", fontWeight = FontWeight.Medium)
                        Text("Tum verileriniz sadece cihazinizda saklanir. Hicbir bilgi internete gonderilmez.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Acil Kart v1.0", fontWeight = FontWeight.Medium)
                    Text("Acil durumda hayat kurtaran kisisel saglik karti",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
