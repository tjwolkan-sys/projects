package com.acilkart.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

val EmergencyRed = Color(0xFFD32F2F)
val EmergencyRedDark = Color(0xFFB71C1C)
val EmergencyRedLight = Color(0xFFFF6659)
val CriticalOrange = Color(0xFFFF6D00)
val SafeGreen = Color(0xFF2E7D32)

private val LightScheme = lightColorScheme(
    primary = EmergencyRed, onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDAD6), onPrimaryContainer = Color(0xFF410002),
    secondary = Color(0xFF00897B), tertiary = CriticalOrange,
    surface = Color(0xFFFFFBFF), background = Color(0xFFF5F5F5), error = EmergencyRedDark,
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFFFB4AB), onPrimary = Color(0xFF690005),
    primaryContainer = EmergencyRed, onPrimaryContainer = Color(0xFFFFDAD6),
    secondary = Color(0xFF80CBC4), tertiary = Color(0xFFFFAB40),
    surface = Color(0xFF1A1A1A), background = Color(0xFF121212), error = Color(0xFFFF8A80),
)

@Composable
fun AcilKartTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val ctx = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        }
        darkTheme -> DarkScheme
        else -> LightScheme
    }
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
