package com.acilkart.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    data object Card : Screen("card", "Acil Kart", Icons.Default.CreditCard)
    data object Edit : Screen("edit/{personId}") {
        fun create(pid: Long) = "edit/$pid"
        val title = "Duzenle"; val icon = Icons.Default.Edit
    }
    data object Family : Screen("family", "Aile", Icons.Default.FamilyRestroom)
    data object Settings : Screen("settings", "Ayarlar", Icons.Default.Settings)
}

val bottomNavItems = listOf(Screen.Card, Screen.Family, Screen.Settings)
